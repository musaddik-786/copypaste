"""
handler.py — SLM (Smart Loss Management) Triage
─────────────────────────────────────────────────
Real pipeline steps:
  1. Read file_url from the documents table (written by Document Submission Agent)
  2. Generate a short-lived SAS token so the private blob is accessible
  3. Download the actual file from Azure Blob Storage (or local fallback)
  4. Prepare the document in the format a real SLM model would receive:
       Image    → PIL Image object (width × height, mode, thumbnail preview)
       Document → extracted plain-text (via pdfplumber for PDF, python-docx for DOCX)
       Video    → first-frame PIL Image extracted via OpenCV / imageio
  5. *** MOCK *** — pass prepared document to "SLM": logs real document details,
                    returns a randomly-weighted triage verdict
"""

import io
import logging
import os
import random
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "common"))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from db import get_db_connection, row_to_dict  # noqa: E402
from dotenv import load_dotenv, find_dotenv

load_dotenv(find_dotenv())

log = logging.getLogger(__name__)

AZURE_STORAGE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING", "")
AZURE_STORAGE_CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "claims-evidence")
_SAS_TTL = timedelta(minutes=10)


# ── Triage vocabulary ────────────────────────────────────────────────────────

TRIAGE_VERDICTS = [
    "STP Eligible",
    "Human Review Required",
    "Investigation / SIU Triage",
    "Surveyor / Damage Assessment Required",
    "Coverage Review Required",
    "Liability Assessment Required",
    "Total Loss Triage",
    "Third-Party / Injury Triage",
    "Legal Triage",
    "Document Deficiency / More Information Required",
    "Catastrophe / Event Triage",
    "High-Severity / Escalation Triage",
]

_WEIGHTS = [15, 20, 8, 12, 8, 8, 6, 6, 5, 5, 4, 3]

_RATIONALE = {
    "STP Eligible": "All required documents present and no anomalies detected. Claim can proceed straight-through.",
    "Human Review Required": "Documents received but one or more fields require manual adjuster review before processing.",
    "Investigation / SIU Triage": "Submission pattern is consistent with indicators that warrant SIU review.",
    "Surveyor / Damage Assessment Required": "Physical damage evident in uploaded evidence; an on-site survey is recommended.",
    "Coverage Review Required": "Policy coverage applicability for the reported loss type needs underwriter verification.",
    "Liability Assessment Required": "Third-party involvement noted; liability split must be established before settlement.",
    "Total Loss Triage": "Damage indicators suggest vehicle or property may be a total loss; specialist assessment required.",
    "Third-Party / Injury Triage": "Evidence references bodily injury or third-party property damage; injury team to review.",
    "Legal Triage": "Documentation contains indicators of potential litigation or legal obligation.",
    "Document Deficiency / More Information Required": "One or more mandatory evidence files are missing or unreadable.",
    "Catastrophe / Event Triage": "Loss date aligns with a registered catastrophe event; CAT-desk routing applied.",
    "High-Severity / Escalation Triage": "High estimated loss value or complex circumstances; senior adjuster escalation required.",
}


def _pick_verdict() -> str:
    return random.choices(TRIAGE_VERDICTS, weights=_WEIGHTS, k=1)[0]


def _mock_confidence() -> float:
    return round(random.uniform(0.60, 0.99), 2)


# ── Step 2: SAS token ─────────────────────────────────────────────────────────

def _connection_string_field(conn_str: str, field: str) -> Optional[str]:
    prefix = f"{field}="
    for part in conn_str.split(";"):
        if part.startswith(prefix):
            return part[len(prefix):]
    return None


def _with_read_sas(file_url: Optional[str]) -> Optional[str]:
    if not file_url or "blob.core.windows.net" not in file_url or "?" in file_url:
        return file_url
    try:
        from azure.storage.blob import generate_blob_sas, BlobSasPermissions
        from urllib.parse import unquote

        marker = f"/{AZURE_STORAGE_CONTAINER_NAME}/"
        idx = file_url.find(marker)
        if idx == -1:
            return file_url

        blob_name = unquote(file_url[idx + len(marker):])
        account_name = _connection_string_field(AZURE_STORAGE_CONNECTION_STRING, "AccountName")
        account_key = _connection_string_field(AZURE_STORAGE_CONNECTION_STRING, "AccountKey")
        if not account_name or not account_key:
            log.warning("Cannot generate SAS — AccountName/AccountKey missing")
            return file_url

        sas_token = generate_blob_sas(
            account_name=account_name,
            container_name=AZURE_STORAGE_CONTAINER_NAME,
            blob_name=blob_name,
            account_key=account_key,
            permission=BlobSasPermissions(read=True),
            expiry=datetime.now(timezone.utc) + _SAS_TTL,
        )
        return f"{file_url}?{sas_token}"
    except Exception as e:
        log.warning("SAS generation failed for %s: %s", file_url, e)
        return file_url


# ── Step 3: Download file ─────────────────────────────────────────────────────

def _download_bytes(file_url: str) -> tuple:
    """
    Download raw bytes. Returns (bytes, source_label).
    source_label: 'azure_blob' | 'local_file' | 'unavailable'
    """
    if not file_url:
        return b"", "unavailable"

    if not file_url.startswith("http"):
        if os.path.exists(file_url):
            with open(file_url, "rb") as f:
                data = f.read()
            log.info("Read %d bytes from local path: %s", len(data), file_url)
            return data, "local_file"
        log.warning("Local file not found: %s", file_url)
        return b"", "unavailable"

    sas_url = _with_read_sas(file_url)
    try:
        import httpx
        resp = httpx.get(sas_url, timeout=30, follow_redirects=True)
        resp.raise_for_status()
        log.info("Downloaded %d bytes from Azure Blob: %s", len(resp.content), file_url)
        return resp.content, "azure_blob"
    except Exception as e:
        log.warning("Blob download failed for %s: %s", file_url, e)
        return b"", "unavailable"


# ── Step 4a: Prepare document in SLM-ready format ────────────────────────────

def _prepare_image(raw_bytes: bytes, file_name: str) -> dict:
    """
    Open image bytes as a PIL Image — exactly what a vision model receives.
    Returns document payload dict with the PIL Image and its properties.
    """
    try:
        from PIL import Image

        img = Image.open(io.BytesIO(raw_bytes))
        img.load()  # force decode so we confirm the bytes are a valid image

        # Produce a small thumbnail for logging (does not modify original img)
        thumb = img.copy()
        thumb.thumbnail((128, 128))

        log.info(
            "[SLM PREP] Image '%s' → size=%s mode=%s — PIL Image ready for model",
            file_name, img.size, img.mode,
        )

        return {
            "payload_type": "image",
            "pil_image": img,           # ← what goes to the real SLM
            "width": img.size[0],
            "height": img.size[1],
            "mode": img.mode,
            "format": img.format or "unknown",
            "thumbnail_size": thumb.size,
        }
    except Exception as e:
        log.warning("[SLM PREP] Could not open image '%s': %s", file_name, e)
        return {"payload_type": "image", "pil_image": None, "error": str(e)}


def _prepare_document(raw_bytes: bytes, file_name: str, content_type: str) -> dict:
    """
    Extract plain text from a PDF or DOCX so a text model can read it.
    Falls back to raw UTF-8 decode for plain text files.
    Returns document payload dict with the extracted text.
    """
    ext = os.path.splitext(file_name)[1].lower()
    text = ""
    method = "unknown"

    # PDF
    if ext == ".pdf" or "pdf" in content_type:
        try:
            import pdfplumber
            with pdfplumber.open(io.BytesIO(raw_bytes)) as pdf:
                pages_text = [p.extract_text() or "" for p in pdf.pages]
                text = "\n".join(pages_text).strip()
                page_count = len(pdf.pages)
            method = "pdfplumber"
            log.info(
                "[SLM PREP] PDF '%s' → %d pages, %d chars extracted — text ready for model",
                file_name, page_count, len(text),
            )
            return {
                "payload_type": "document",
                "text": text,           # ← what goes to the real SLM
                "page_count": page_count,
                "char_count": len(text),
                "extraction_method": method,
                "preview": text[:300] + ("..." if len(text) > 300 else ""),
            }
        except Exception as e:
            log.warning("[SLM PREP] pdfplumber failed for '%s': %s", file_name, e)

    # DOCX
    if ext in (".docx", ".doc") or "word" in content_type:
        try:
            import docx
            document = docx.Document(io.BytesIO(raw_bytes))
            text = "\n".join(p.text for p in document.paragraphs).strip()
            method = "python-docx"
            log.info(
                "[SLM PREP] DOCX '%s' → %d chars extracted — text ready for model",
                file_name, len(text),
            )
            return {
                "payload_type": "document",
                "text": text,
                "page_count": None,
                "char_count": len(text),
                "extraction_method": method,
                "preview": text[:300] + ("..." if len(text) > 300 else ""),
            }
        except Exception as e:
            log.warning("[SLM PREP] python-docx failed for '%s': %s", file_name, e)

    # Plain text fallback
    try:
        text = raw_bytes.decode("utf-8", errors="replace").strip()
        method = "utf8_decode"
        log.info("[SLM PREP] Text '%s' → %d chars — ready for model", file_name, len(text))
    except Exception as e:
        log.warning("[SLM PREP] Text decode failed for '%s': %s", file_name, e)
        text = ""

    return {
        "payload_type": "document",
        "text": text,
        "page_count": None,
        "char_count": len(text),
        "extraction_method": method,
        "preview": text[:300] + ("..." if len(text) > 300 else ""),
    }


def _prepare_video(raw_bytes: bytes, file_name: str) -> dict:
    """
    Extract the first frame from a video as a PIL Image.
    Uses imageio (lightweight). Falls back to metadata-only if unavailable.
    """
    try:
        import imageio.v3 as iio
        import numpy as np

        # Write bytes to a temp buffer imageio can seek over
        buf = io.BytesIO(raw_bytes)
        # Read only the first frame
        frame_array = iio.imread(buf, index=0, plugin="pyav")
        from PIL import Image as PILImage
        frame_img = PILImage.fromarray(frame_array.astype("uint8"))

        log.info(
            "[SLM PREP] Video '%s' → first frame extracted, size=%s — PIL Image ready for model",
            file_name, frame_img.size,
        )

        return {
            "payload_type": "video",
            "first_frame": frame_img,   # ← what goes to the real SLM (first-frame vision pass)
            "frame_width": frame_img.size[0],
            "frame_height": frame_img.size[1],
            "file_size_bytes": len(raw_bytes),
        }
    except Exception as e:
        log.warning("[SLM PREP] Video frame extraction failed for '%s': %s", file_name, e)
        return {
            "payload_type": "video",
            "first_frame": None,
            "file_size_bytes": len(raw_bytes),
            "error": str(e),
        }


def _prepare_for_slm(raw_bytes: bytes, file_name: str, document_type: str, content_type: str) -> dict:
    """
    Route to the correct preparation function based on document_type.
    document_type is 'Image' | 'Video' | 'Document' (set by Document Submission Agent).
    """
    if document_type == "Image":
        return _prepare_image(raw_bytes, file_name)
    if document_type == "Video":
        return _prepare_video(raw_bytes, file_name)
    return _prepare_document(raw_bytes, file_name, content_type)


# ── Step 4b (MOCK): SLM inference ────────────────────────────────────────────

def _mock_slm_inference(payload: dict, file_name: str, source: str) -> dict:
    """
    MOCK SLM inference.

    Receives the real prepared document payload:
      - Image    : payload['pil_image']  (PIL.Image.Image)
      - Document : payload['text']       (str)
      - Video    : payload['first_frame'] (PIL.Image.Image of first frame)

    In production: pass the payload to the real SLM model and parse its output.
    For now: confirm receipt of the real document content and return random verdict.
    """
    payload_type = payload.get("payload_type", "unknown")

    if payload_type == "image":
        img = payload.get("pil_image")
        if img:
            log.info(
                "[SLM MOCK] Running inference on Image '%s' — %dx%d px, mode=%s (source=%s)",
                file_name, payload.get("width", 0), payload.get("height", 0),
                payload.get("mode", "?"), source,
            )
        else:
            log.warning("[SLM MOCK] Image '%s' could not be decoded — inference on empty payload", file_name)

    elif payload_type == "document":
        text = payload.get("text", "")
        log.info(
            "[SLM MOCK] Running inference on Document '%s' — %d chars, method=%s (source=%s)\n  Preview: %s",
            file_name, len(text), payload.get("extraction_method", "?"),
            source, payload.get("preview", "")[:120],
        )

    elif payload_type == "video":
        frame = payload.get("first_frame")
        if frame:
            log.info(
                "[SLM MOCK] Running inference on Video '%s' — first frame %dx%d px (source=%s)",
                file_name, payload.get("frame_width", 0), payload.get("frame_height", 0), source,
            )
        else:
            log.warning(
                "[SLM MOCK] Video '%s' — frame extraction failed, inference on metadata only (source=%s)",
                file_name, source,
            )

    verdict = _pick_verdict()
    confidence = _mock_confidence()

    # Build per-type summary to include in the response
    document_summary: dict = {"payload_type": payload_type}
    if payload_type == "image":
        document_summary.update({
            "width": payload.get("width"),
            "height": payload.get("height"),
            "mode": payload.get("mode"),
        })
    elif payload_type == "document":
        document_summary.update({
            "char_count": payload.get("char_count"),
            "page_count": payload.get("page_count"),
            "extraction_method": payload.get("extraction_method"),
            "text_preview": payload.get("preview"),
        })
    elif payload_type == "video":
        document_summary.update({
            "frame_width": payload.get("frame_width"),
            "frame_height": payload.get("frame_height"),
            "file_size_bytes": payload.get("file_size_bytes"),
        })

    return {
        "slm_verdict": verdict,
        "slm_confidence": confidence,
        "slm_rationale": _RATIONALE[verdict],
        "download_source": source,
        "document_summary": document_summary,
        "inference_mode": "mock",
    }


# ── Shared triage runner ──────────────────────────────────────────────────────

def _run_triage_on_docs(docs: list) -> tuple:
    document_verdicts = []

    for doc in docs:
        file_url = doc.get("file_url") or ""
        file_name = doc.get("file_name", "unknown")
        document_type = doc.get("document_type", "Document")
        content_type = doc.get("content_type", "application/octet-stream")

        # Step 3: download the actual file
        raw_bytes, source = _download_bytes(file_url)

        # Step 4a: prepare in SLM-ready format (PIL Image / text / first-frame)
        payload = _prepare_for_slm(raw_bytes, file_name, document_type, content_type)

        # Step 4b: mock SLM inference on the real document
        inference = _mock_slm_inference(payload, file_name, source)

        document_verdicts.append({
            "document_id": doc.get("document_id"),
            "file_name": file_name,
            "document_type": document_type,
            "status": doc.get("status"),
            "file_url": _with_read_sas(file_url),
            **inference,
        })

    overall_verdict = _pick_verdict()
    overall = {
        "overall_verdict": overall_verdict,
        "confidence": _mock_confidence(),
        "rationale": _RATIONALE[overall_verdict],
    }
    return document_verdicts, overall


# ── Public handler functions ──────────────────────────────────────────────────

def triage_claim(claim_number: str) -> dict:
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT document_id, file_name, file_url, content_type, document_type, status, uploaded_at "
            "FROM documents WHERE claim_number = %s ORDER BY uploaded_at DESC",
            (claim_number,),
        )
        docs = row_to_dict(cur.fetchall()) or []
    finally:
        conn.close()

    if not docs:
        return {
            "claim_number": claim_number,
            "overall_verdict": "Document Deficiency / More Information Required",
            "confidence": 0.95,
            "rationale": "No documents have been submitted for this claim yet.",
            "document_count": 0,
            "document_verdicts": [],
            "triaged_at": datetime.utcnow().isoformat(),
        }

    document_verdicts, overall = _run_triage_on_docs(docs)

    return {
        "claim_number": claim_number,
        **overall,
        "document_count": len(document_verdicts),
        "document_verdicts": document_verdicts,
        "triaged_at": datetime.utcnow().isoformat(),
    }


def triage_documents(document_ids: list) -> dict:
    if not document_ids:
        return {
            "overall_verdict": "Document Deficiency / More Information Required",
            "confidence": 0.95,
            "rationale": "No document IDs were provided for triage.",
            "document_count": 0,
            "document_verdicts": [],
            "triaged_at": datetime.utcnow().isoformat(),
        }

    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT document_id, claim_number, file_name, file_url, content_type, document_type, status, uploaded_at "
            "FROM documents WHERE document_id = ANY(%s)",
            (document_ids,),
        )
        docs = row_to_dict(cur.fetchall()) or []
    finally:
        conn.close()

    document_verdicts, overall = _run_triage_on_docs(docs)

    return {
        **overall,
        "document_count": len(document_verdicts),
        "document_verdicts": document_verdicts,
        "triaged_at": datetime.utcnow().isoformat(),
    }
