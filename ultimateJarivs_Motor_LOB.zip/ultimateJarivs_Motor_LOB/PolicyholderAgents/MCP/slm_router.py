"""
slm_router.py — SLM (Smart Loss Management) Triage
────────────────────────────────────────────────────
Endpoints:
  POST /api/slm/triage/claim/{claim_number}   — triage all docs for a claim
  POST /api/slm/triage/documents              — triage a specific list of document_ids
"""

import logging
from typing import List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from slm_mcp import handler

log = logging.getLogger(__name__)

router = APIRouter()


@router.post(
    "/api/slm/triage/claim/{claim_number}",
    operation_id="triage_claim",
    summary="Run SLM mock triage on all documents submitted for a claim",
    tags=["SLM Triage"],
)
def triage_claim(claim_number: str):
    """
    Fetches all evidence documents stored by the Document Submission Agent for
    the given claim_number, runs a mock SLM triage pass, and returns:
    - overall_verdict: one of the 12 triage categories
    - confidence: mock confidence score
    - rationale: brief explanation
    - document_verdicts: per-document mock triage results
    """
    try:
        return handler.triage_claim(claim_number)
    except Exception as e:
        log.exception("triage_claim error")
        raise HTTPException(status_code=500, detail=str(e))


class TriageDocumentsRequest(BaseModel):
    document_ids: List[str]


@router.post(
    "/api/slm/triage/documents",
    operation_id="triage_documents",
    summary="Run SLM mock triage on a specific list of document IDs",
    tags=["SLM Triage"],
)
def triage_documents(payload: TriageDocumentsRequest):
    """
    Accepts an explicit list of document_ids (as returned by the Document
    Submission Agent upload response) and runs a mock SLM triage pass on them.
    Useful for triaging a freshly-uploaded batch without re-fetching all claim docs.
    """
    try:
        return handler.triage_documents(payload.document_ids)
    except Exception as e:
        log.exception("triage_documents error")
        raise HTTPException(status_code=500, detail=str(e))
