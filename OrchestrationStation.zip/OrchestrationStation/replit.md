# Overview

This is a full-stack web application built with React, TypeScript, and Node.js that provides an agent management dashboard. The system manages three types of agents (data extraction, eligibility, and risk assessment) with real-time status monitoring, execution logging, and configuration management. The application features a modern UI built with shadcn/ui components and uses PostgreSQL with Drizzle ORM for data persistence.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and real-time polling
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build System**: Vite with custom configuration for monorepo structure

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Agent System**: Abstract base class pattern with pluggable agent implementations
- **Real-time Updates**: Polling-based approach (1-second intervals) for status updates
- **Error Handling**: Centralized error middleware with structured error responses

## Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema Management**: Code-first approach with TypeScript schema definitions
- **Migrations**: Drizzle Kit for database migrations and schema synchronization

## Data Models
The system uses five core entities:
- **Agents**: Core agent instances with status and progress tracking
- **Execution Logs**: Detailed logging with levels and structured data
- **Agent Configurations**: Flexible JSON-based configuration system
- **Execution History**: Historical execution tracking with metrics
- **Agent Health Metrics**: Performance and health monitoring data

## Shared Code Architecture
- **Schema Sharing**: Common TypeScript interfaces and Zod validation schemas
- **Type Safety**: End-to-end TypeScript with strict type checking
- **Code Organization**: Monorepo structure with client, server, and shared directories

## Development Environment
- **Replit Integration**: Custom plugins for development mode and error handling
- **Hot Reloading**: Vite dev server with Express middleware integration
- **TypeScript**: Incremental compilation with path mapping for clean imports

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **@neondatabase/serverless**: Neon-specific database driver with WebSocket support

## UI and Styling
- **Radix UI**: Comprehensive set of unstyled, accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Lucide React**: Modern icon library with React components
- **Class Variance Authority**: Type-safe variant API for component styling

## Development Tools
- **Vite**: Fast build tool with React plugin and runtime error overlay
- **Drizzle Kit**: Database toolkit for migrations and schema management
- **ESBuild**: Fast JavaScript bundler for production builds
- **TypeScript**: Static type checking and compilation

## Form and Data Management
- **React Hook Form**: Performant forms with minimal re-renders
- **Zod**: TypeScript-first schema validation library
- **TanStack Query**: Powerful data synchronization for React applications

## Additional Utilities
- **date-fns**: Modern JavaScript date utility library
- **clsx**: Utility for constructing className strings conditionally
- **nanoid**: Secure, URL-friendly unique string ID generator