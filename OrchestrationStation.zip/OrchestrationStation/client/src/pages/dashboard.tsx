import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Play, 
  Share, 
  Database, 
  CheckCircle, 
  Shield, 
  Settings,
  RefreshCw,
  Download,
  ClipboardCheck,
  AlertTriangle
} from "lucide-react";
import type { Agent, ExecutionLog } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Polling for real-time updates
  const { data: statusData, isLoading } = useQuery<{agents: Agent[], logs: ExecutionLog[]}>({
    queryKey: ["/api/agents/status"],
    refetchInterval: 1000, // Poll every second
  });

  const agents: Agent[] = statusData?.agents ?? [];
  const logs: ExecutionLog[] = statusData?.logs ?? [];

  // Mutations
  const initializeMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/system/initialize"),
    onSuccess: async () => {
      toast({
        variant: "success",
        title: "Success!",
        description: "All FastAPI servers initialized successfully!"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/agents/status"] });
    },
    onError: () => {
      toast({
        variant: "destructive", 
        title: "Error",
        description: "Failed to initialize servers"
      });
    }
  });

  const orchestrationMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/orchestration"),
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Orchestration Started",
        description: "Sequential workflow initiated successfully"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/agents/status"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error", 
        description: "Failed to start orchestration"
      });
    }
  });

  const executeAgentMutation = useMutation({
    mutationFn: (agentType: string) => 
      apiRequest("POST", `/api/agents/${agentType}/execute`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agents/status"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to execute agent"
      });
    }
  });

  const getAgentIcon = (type: string) => {
    switch (type) {
      case 'data_extraction':
        return <Database className="text-2xl" />;
      case 'eligibility':
        return <CheckCircle className="text-2xl" />;
      case 'risk_assessment':
        return <Shield className="text-2xl" />;
      default:
        return <Settings className="text-2xl" />;
    }
  };

  const getAgentButtonIcon = (type: string) => {
    switch (type) {
      case 'data_extraction':
        return <Download className="w-4 h-4" />;
      case 'eligibility':
        return <ClipboardCheck className="w-4 h-4" />;
      case 'risk_assessment':
        return <AlertTriangle className="w-4 h-4" />;
      default:
        return <Settings className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
        return 'text-blue-600 font-semibold';
      case 'complete':
        return 'text-cyan-600 font-semibold';
      case 'error':
        return 'text-purple-600 font-semibold';
      default:
        return 'text-blue-400 font-medium';
    }
  };

  const formatTime = (timestamp: string | Date) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  return (
    <div className="bg-gradient-blue min-h-screen font-sans">
      {/* Header */}
      <header className="header-gradient shadow-lg border-b border-blue-300 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 relative z-10">
              <div className="bg-white/20 backdrop-blur-sm text-white p-3 rounded-xl shadow-lg border border-white/20">
                <Settings className="text-xl" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white drop-shadow-lg">Agent Orchestration Dashboard</h1>
                <p className="text-sm text-blue-100 drop-shadow">FastAPI Backend Services Management</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 relative z-10">
              <div className="flex items-center space-x-2 text-sm text-blue-100 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20">
                <span className="status-indicator status-complete"></span>
                <span className="font-medium">System Status: Online</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Primary Actions Card */}
        <div className="grid gap-6 mb-8">
          <Card className="agent-card shadow-xl border-2 border-blue-200/50 bg-gradient-to-br from-blue-50 to-white">
            <CardContent className="pt-6">
              <div className="text-center space-y-6">
                <div>
                  <h2 className="text-xl font-semibold text-blue-900 mb-2">System Controls</h2>
                  <p className="text-blue-600">Initialize and orchestrate your FastAPI backend services</p>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  {/* Start & Execute Button */}
                  <Button 
                    data-testid="button-start-execute"
                    onClick={() => initializeMutation.mutate()}
                    disabled={initializeMutation.isPending}
                    className="btn-primary text-white px-8 py-4 text-lg shadow-lg hover:shadow-xl transition-all duration-300 min-w-[200px] h-auto transform hover:scale-105"
                  >
                    <Play className="mr-3 h-5 w-5" />
                    {initializeMutation.isPending ? "Initializing..." : "Start & Execute"}
                  </Button>

                  {/* Orchestration Button */}
                  <Button 
                    data-testid="button-orchestration"
                    onClick={() => orchestrationMutation.mutate()}
                    disabled={orchestrationMutation.isPending}
                    className="btn-success text-white px-8 py-4 text-lg shadow-lg hover:shadow-xl transition-all duration-300 min-w-[200px] h-auto transform hover:scale-105"
                  >
                    <Share className="mr-3 h-5 w-5" />
                    {orchestrationMutation.isPending ? "Starting..." : "Orchestration"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Agent Dashboard */}
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {agents.map((agent) => (
            <Card key={agent.id} className="agent-card shadow-xl border-2 border-blue-200/50">
              <CardContent className="p-6">
                <div className="text-center space-y-5">
                  <div className={`p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto transition-all duration-300 ${
                    agent.type === 'data_extraction' ? 'agent-icon-data' :
                    agent.type === 'eligibility' ? 'agent-icon-eligibility' :
                    'agent-icon-risk'
                  }`}>
                    {getAgentIcon(agent.type)}
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-blue-900 mb-1">{agent.name}</h3>
                    <p className="text-sm text-blue-600 font-medium">FastAPI Service</p>
                    <div className="flex items-center justify-center mt-3 bg-blue-50 rounded-full px-4 py-2 border border-blue-200">
                      <span className={`status-indicator status-${agent.status}`}></span>
                      <span className={`text-sm font-medium ${getStatusColor(agent.status)} capitalize`}>
                        {agent.status}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    data-testid={`button-${agent.type.replace('_', '-')}`}
                    onClick={() => executeAgentMutation.mutate(agent.type)}
                    disabled={executeAgentMutation.isPending || agent.status === 'running'}
                    className="w-full btn-accent text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 py-3"
                  >
                    {getAgentButtonIcon(agent.type)}
                    <span className="ml-2 font-medium">
                      {agent.status === 'running' ? 'Running...' : 'Execute'}
                    </span>
                  </Button>

                  {/* Progress Bar */}
                  <div className="w-full bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-sm font-medium text-blue-700">Progress</span>
                      <span className="text-sm font-bold text-blue-800 bg-blue-100 px-2 py-1 rounded-full">{agent.progress}%</span>
                    </div>
                    <Progress value={agent.progress} className="h-3 bg-blue-200" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Execution Log */}
        <Card className="shadow-xl border-2 border-blue-200/50 bg-gradient-to-br from-blue-50 to-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-blue-900 flex items-center">
                <div className="w-2 h-2 bg-blue-500 rounded-full mr-3 animate-pulse"></div>
                Execution Log
              </h3>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/agents/status"] })}
                data-testid="button-refresh-logs"
                className="text-blue-600 hover:text-blue-800 hover:bg-blue-100 transition-all duration-200"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-3 max-h-80 overflow-y-auto bg-gradient-to-b from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
              {logs.length === 0 ? (
                <div className="flex items-center space-x-4 py-3 text-sm text-blue-600 bg-blue-100 rounded-lg px-4">
                  <span className="text-xs w-20 font-mono bg-blue-200 px-2 py-1 rounded">--:--:--</span>
                  <span className="status-indicator status-idle"></span>
                  <span className="font-medium">No execution logs yet...</span>
                </div>
              ) : (
                logs.map((log, index) => (
                  <div 
                    key={log.id || index}
                    className="flex items-center space-x-4 py-3 text-sm bg-white/70 backdrop-blur-sm rounded-lg px-4 border border-blue-100 hover:bg-white/90 transition-all duration-200"
                    data-testid={`log-entry-${index}`}
                  >
                    <span className="text-xs text-blue-600 w-20 font-mono bg-blue-100 px-2 py-1 rounded">
                      {formatTime(log.timestamp)}
                    </span>
                    <span className={`status-indicator status-${log.status}`}></span>
                    <span className={`${getStatusColor(log.status)} font-medium flex-1`}>{log.message}</span>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

      </main>
    </div>
  );
}
