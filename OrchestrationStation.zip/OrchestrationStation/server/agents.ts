import { storage } from "./storage";
import { type AgentType, type AgentConfiguration } from "@shared/schema";

export interface AgentExecutionResult {
  success: boolean;
  data: any;
  processingTime: number;
  recordsProcessed?: number;
  errorDetails?: string;
}

export interface AgentExecutionContext {
  agentId: string;
  agentName: string;
  executionId: string;
  configuration: AgentConfiguration | null;
}

export abstract class BaseAgent {
  protected agentType: AgentType;
  protected agentName: string;
  
  constructor(agentType: AgentType, agentName: string) {
    this.agentType = agentType;
    this.agentName = agentName;
  }

  abstract execute(context: AgentExecutionContext): Promise<AgentExecutionResult>;

  protected async updateProgress(agentId: string, progress: number, message: string) {
    await storage.updateAgentStatus(agentId, 'running', progress);
    await storage.addExecutionLog({
      agentId,
      message,
      level: 'info',
      status: 'running'
    });
  }

  protected async logError(agentId: string, error: string) {
    await storage.addExecutionLog({
      agentId,
      message: error,
      level: 'error',
      status: 'error'
    });
  }

  protected async logSuccess(agentId: string, message: string) {
    await storage.addExecutionLog({
      agentId,
      message,
      level: 'info',
      status: 'complete'
    });
  }
}

export class DataExtractionAgent extends BaseAgent {
  constructor() {
    super('data_extraction', 'Data Extraction Agent');
  }

  async execute(context: AgentExecutionContext): Promise<AgentExecutionResult> {
    const startTime = Date.now();
    const { agentId, executionId } = context;
    
    try {
      await this.updateProgress(agentId, 0, "Initializing data extraction process");
      await this.delay(800);

      // Simulate connecting to data sources
      await this.updateProgress(agentId, 15, "Connecting to database sources");
      await this.delay(1000);
      
      const extractedData = {
        databases: await this.extractFromDatabase(),
        apis: await this.extractFromAPIs(agentId),
        files: await this.extractFromFiles(agentId)
      };

      await this.updateProgress(agentId, 85, "Consolidating extracted data");
      await this.delay(600);

      // Data validation and cleanup
      const cleanedData = await this.validateAndCleanData(agentId, extractedData);
      
      await this.updateProgress(agentId, 100, "Data extraction completed successfully");
      
      const processingTime = Date.now() - startTime;
      const totalRecords = cleanedData.totalRecords;

      await this.logSuccess(agentId, `Successfully extracted ${totalRecords} records in ${processingTime}ms`);

      return {
        success: true,
        data: cleanedData,
        processingTime,
        recordsProcessed: totalRecords
      };

    } catch (error) {
      const errorMessage = `Data extraction failed: ${error instanceof Error ? error.message : 'Unknown error'}`;
      await this.logError(agentId, errorMessage);
      
      return {
        success: false,
        data: null,
        processingTime: Date.now() - startTime,
        errorDetails: errorMessage
      };
    }
  }

  private async extractFromDatabase(): Promise<any> {
    await this.delay(800);
    // Simulate database extraction
    return {
      users: Array.from({ length: 150 }, (_, i) => ({
        id: i + 1,
        name: `User ${i + 1}`,
        email: `user${i + 1}@example.com`,
        createdAt: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000)
      })),
      transactions: Array.from({ length: 300 }, (_, i) => ({
        id: i + 1,
        userId: Math.floor(Math.random() * 150) + 1,
        amount: Math.random() * 1000,
        timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000)
      }))
    };
  }

  private async extractFromAPIs(agentId: string): Promise<any> {
    await this.updateProgress(agentId, 45, "Fetching data from external APIs");
    await this.delay(1200);
    
    // Simulate API calls with potential failures
    const apiResults = [];
    for (let i = 0; i < 3; i++) {
      try {
        // Simulate occasional API failures
        if (Math.random() < 0.1) {
          throw new Error(`API endpoint ${i + 1} temporarily unavailable`);
        }
        
        apiResults.push({
          endpoint: `api_${i + 1}`,
          data: Array.from({ length: 50 }, (_, j) => ({
            id: j + 1,
            value: Math.random() * 100,
            category: `Category ${Math.floor(Math.random() * 5) + 1}`
          })),
          responseTime: Math.floor(Math.random() * 500) + 100
        });
      } catch (error) {
        await storage.addExecutionLog({
          agentId,
          message: `API extraction warning: ${error instanceof Error ? error.message : 'Unknown error'}`,
          level: 'warning',
          status: 'running'
        });
      }
    }
    
    return apiResults;
  }

  private async extractFromFiles(agentId: string): Promise<any> {
    await this.updateProgress(agentId, 65, "Processing file sources");
    await this.delay(700);
    
    // Simulate file processing
    return {
      csvFiles: [
        { filename: "customers.csv", records: 200, size: "1.2MB" },
        { filename: "products.csv", records: 350, size: "2.1MB" }
      ],
      jsonFiles: [
        { filename: "config.json", records: 1, size: "15KB" },
        { filename: "metadata.json", records: 25, size: "45KB" }
      ]
    };
  }

  private async validateAndCleanData(agentId: string, data: any): Promise<any> {
    await this.delay(500);
    
    const totalRecords = (data.databases?.users?.length || 0) + 
                        (data.databases?.transactions?.length || 0) +
                        (data.apis?.reduce((sum: number, api: any) => sum + (api.data?.length || 0), 0) || 0) +
                        550; // CSV records

    return {
      ...data,
      totalRecords,
      validationResult: {
        duplicatesRemoved: 12,
        invalidRecordsFiltered: 3,
        dataQualityScore: 0.97
      }
    };
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export class EligibilityAgent extends BaseAgent {
  constructor() {
    super('eligibility', 'Eligibility Verification Agent');
  }

  async execute(context: AgentExecutionContext): Promise<AgentExecutionResult> {
    const startTime = Date.now();
    const { agentId, configuration } = context;
    
    try {
      await this.updateProgress(agentId, 0, "Starting eligibility verification process");
      await this.delay(600);

      // Get eligibility rules from configuration
      const params = configuration?.parameters as any || {};
      const rules = params.rules || ['age_verification', 'income_check', 'credit_score'];
      const strictMode = params.strictMode !== undefined ? params.strictMode : true;

      await this.updateProgress(agentId, 20, `Applying ${rules.length} eligibility rules`);
      
      const verificationResults = [];
      for (let i = 0; i < rules.length; i++) {
        const rule = rules[i];
        const progress = 20 + ((i + 1) / rules.length) * 60;
        
        await this.updateProgress(agentId, Math.floor(progress), `Verifying: ${rule.replace('_', ' ')}`);
        const result = await this.verifyRule(agentId, rule, strictMode);
        verificationResults.push(result);
        await this.delay(800);
      }

      await this.updateProgress(agentId, 85, "Calculating final eligibility score");
      const finalResult = await this.calculateFinalEligibility(agentId, verificationResults, strictMode);
      await this.delay(400);

      await this.updateProgress(agentId, 100, "Eligibility verification completed");
      
      const processingTime = Date.now() - startTime;
      const eligibleCount = verificationResults.filter(r => r.passed).length;
      
      await this.logSuccess(agentId, `Eligibility check completed. ${eligibleCount}/${verificationResults.length} criteria passed`);

      return {
        success: true,
        data: finalResult,
        processingTime,
        recordsProcessed: verificationResults.length
      };

    } catch (error) {
      const errorMessage = `Eligibility verification failed: ${error instanceof Error ? error.message : 'Unknown error'}`;
      await this.logError(agentId, errorMessage);
      
      return {
        success: false,
        data: null,
        processingTime: Date.now() - startTime,
        errorDetails: errorMessage
      };
    }
  }

  private async verifyRule(agentId: string, rule: string, strictMode: boolean): Promise<any> {
    // Simulate rule verification with realistic scenarios
    switch (rule) {
      case 'age_verification':
        const ageValid = Math.random() > 0.15; // 85% pass rate
        if (!ageValid && strictMode) {
          await storage.addExecutionLog({
            agentId,
            message: 'Age verification failed - applicant under minimum age requirement',
            level: 'warning',
            status: 'running'
          });
        }
        return {
          rule: 'age_verification',
          passed: ageValid,
          score: ageValid ? 100 : 0,
          details: { minimumAge: 18, applicantAge: ageValid ? 25 : 16 }
        };

      case 'income_check':
        const incomeValid = Math.random() > 0.25; // 75% pass rate
        const income = Math.floor(Math.random() * 100000) + 20000;
        if (!incomeValid && strictMode) {
          await storage.addExecutionLog({
            agentId,
            message: 'Income verification failed - insufficient income level',
            level: 'warning',
            status: 'running'
          });
        }
        return {
          rule: 'income_check',
          passed: incomeValid,
          score: Math.min(100, (income / 50000) * 100),
          details: { requiredIncome: 50000, reportedIncome: income }
        };

      case 'credit_score':
        const creditScore = Math.floor(Math.random() * 400) + 400; // 400-800
        const creditValid = creditScore >= 650;
        if (!creditValid && strictMode) {
          await storage.addExecutionLog({
            agentId,
            message: `Credit score ${creditScore} below minimum requirement`,
            level: 'warning',
            status: 'running'
          });
        }
        return {
          rule: 'credit_score',
          passed: creditValid,
          score: Math.min(100, ((creditScore - 400) / 400) * 100),
          details: { minimumScore: 650, actualScore: creditScore }
        };

      default:
        return {
          rule,
          passed: true,
          score: 100,
          details: { status: 'default_pass' }
        };
    }
  }

  private async calculateFinalEligibility(agentId: string, results: any[], strictMode: boolean): Promise<any> {
    const totalScore = results.reduce((sum, result) => sum + result.score, 0);
    const averageScore = totalScore / results.length;
    const allPassed = results.every(result => result.passed);
    
    const eligible = strictMode ? allPassed : averageScore >= 70;
    
    return {
      eligible,
      overallScore: Math.round(averageScore),
      ruleResults: results,
      strictMode,
      summary: {
        totalRules: results.length,
        passedRules: results.filter(r => r.passed).length,
        averageScore: Math.round(averageScore)
      }
    };
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export class RiskAssessmentAgent extends BaseAgent {
  constructor() {
    super('risk_assessment', 'Risk Assessment Agent');
  }

  async execute(context: AgentExecutionContext): Promise<AgentExecutionResult> {
    const startTime = Date.now();
    const { agentId, configuration } = context;
    
    try {
      await this.updateProgress(agentId, 0, "Initializing risk assessment analysis");
      await this.delay(700);

      const params = configuration?.parameters as any || {};
      const factors = params.factors || ['financial', 'behavioral', 'historical'];
      const riskThreshold = params.riskThreshold || 0.7;

      await this.updateProgress(agentId, 15, `Analyzing ${factors.length} risk factors`);
      
      const riskAnalysis = [];
      for (let i = 0; i < factors.length; i++) {
        const factor = factors[i];
        const progress = 15 + ((i + 1) / factors.length) * 60;
        
        await this.updateProgress(agentId, Math.floor(progress), `Assessing ${factor} risk`);
        const analysis = await this.analyzeFactor(agentId, factor);
        riskAnalysis.push(analysis);
        await this.delay(1000);
      }

      await this.updateProgress(agentId, 80, "Calculating composite risk score");
      const finalAssessment = await this.calculateRiskScore(agentId, riskAnalysis, riskThreshold);
      await this.delay(600);

      await this.updateProgress(agentId, 100, "Risk assessment completed");
      
      const processingTime = Date.now() - startTime;
      
      const riskLevel = finalAssessment.riskScore > riskThreshold ? 'HIGH' : 
                       finalAssessment.riskScore > 0.4 ? 'MEDIUM' : 'LOW';
      
      await this.logSuccess(agentId, `Risk assessment completed. Risk Level: ${riskLevel} (${Math.round(finalAssessment.riskScore * 100)}%)`);

      return {
        success: true,
        data: finalAssessment,
        processingTime,
        recordsProcessed: riskAnalysis.length
      };

    } catch (error) {
      const errorMessage = `Risk assessment failed: ${error instanceof Error ? error.message : 'Unknown error'}`;
      await this.logError(agentId, errorMessage);
      
      return {
        success: false,
        data: null,
        processingTime: Date.now() - startTime,
        errorDetails: errorMessage
      };
    }
  }

  private async analyzeFactor(agentId: string, factor: string): Promise<any> {
    // Simulate comprehensive risk factor analysis
    switch (factor) {
      case 'financial':
        const debtToIncomeRatio = Math.random() * 0.8; // 0-80%
        const liquidAssets = Math.random() * 100000; // $0-$100k
        const financialScore = Math.max(0, 1 - (debtToIncomeRatio * 0.7 + (100000 - liquidAssets) / 100000 * 0.3));
        
        if (financialScore < 0.3) {
          await storage.addExecutionLog({
            agentId,
            message: `High financial risk detected - Debt ratio: ${Math.round(debtToIncomeRatio * 100)}%`,
            level: 'warning',
            status: 'running'
          });
        }
        
        return {
          factor: 'financial',
          riskScore: Math.max(0, 1 - financialScore), // Invert for risk (higher = more risky)
          details: {
            debtToIncomeRatio: Math.round(debtToIncomeRatio * 100),
            liquidAssets: Math.round(liquidAssets),
            creditUtilization: Math.round(Math.random() * 100)
          }
        };

      case 'behavioral':
        const transactionPatterns = Math.random();
        const spendingVolatility = Math.random() * 0.6;
        const behavioralRisk = (spendingVolatility * 0.6 + (1 - transactionPatterns) * 0.4);
        
        if (behavioralRisk > 0.6) {
          await storage.addExecutionLog({
            agentId,
            message: 'Concerning behavioral patterns detected in transaction history',
            level: 'warning',
            status: 'running'
          });
        }
        
        return {
          factor: 'behavioral',
          riskScore: behavioralRisk,
          details: {
            spendingVolatility: Math.round(spendingVolatility * 100),
            unusualTransactions: Math.floor(Math.random() * 10),
            consistencyScore: Math.round(transactionPatterns * 100)
          }
        };

      case 'historical':
        const pastDefaults = Math.random() > 0.8 ? Math.floor(Math.random() * 3) + 1 : 0;
        const latePayments = Math.floor(Math.random() * 8);
        const historicalRisk = (pastDefaults * 0.4 + latePayments * 0.1) / 2;
        
        if (pastDefaults > 0) {
          await storage.addExecutionLog({
            agentId,
            message: `Historical risk factors found: ${pastDefaults} past defaults, ${latePayments} late payments`,
            level: 'warning',
            status: 'running'
          });
        }
        
        return {
          factor: 'historical',
          riskScore: Math.min(1, historicalRisk),
          details: {
            pastDefaults,
            latePayments,
            accountAge: Math.floor(Math.random() * 120) + 12 // 1-10 years
          }
        };

      default:
        return {
          factor,
          riskScore: Math.random() * 0.5, // Default to lower risk
          details: { analyzed: true }
        };
    }
  }

  private async calculateRiskScore(agentId: string, analysis: any[], threshold: number): Promise<any> {
    // Weighted composite risk score
    const weights = { financial: 0.4, behavioral: 0.35, historical: 0.25 };
    
    let totalScore = 0;
    let totalWeight = 0;
    
    analysis.forEach(item => {
      const weight = weights[item.factor as keyof typeof weights] || 1 / analysis.length;
      totalScore += item.riskScore * weight;
      totalWeight += weight;
    });
    
    const riskScore = totalScore / (totalWeight || 1);
    const riskLevel = riskScore > threshold ? 'HIGH' : riskScore > 0.4 ? 'MEDIUM' : 'LOW';
    
    // Generate recommendations based on risk level
    const recommendations = this.generateRecommendations(riskLevel, analysis);
    
    return {
      riskScore: Math.round(riskScore * 1000) / 1000, // Round to 3 decimals
      riskLevel,
      threshold,
      factorAnalysis: analysis,
      recommendations,
      summary: {
        totalFactors: analysis.length,
        highRiskFactors: analysis.filter(a => a.riskScore > 0.6).length,
        averageFactorRisk: Math.round((analysis.reduce((sum, a) => sum + a.riskScore, 0) / analysis.length) * 100)
      }
    };
  }

  private generateRecommendations(riskLevel: string, analysis: any[]): string[] {
    const recommendations = [];
    
    switch (riskLevel) {
      case 'HIGH':
        recommendations.push('Require additional verification documents');
        recommendations.push('Consider manual underwriting review');
        recommendations.push('Implement enhanced monitoring');
        break;
      case 'MEDIUM':
        recommendations.push('Request additional financial statements');
        recommendations.push('Consider reduced initial limits');
        break;
      case 'LOW':
        recommendations.push('Standard approval process recommended');
        recommendations.push('Regular periodic review sufficient');
        break;
    }
    
    // Factor-specific recommendations
    analysis.forEach(factor => {
      if (factor.riskScore > 0.7) {
        switch (factor.factor) {
          case 'financial':
            recommendations.push('Verify income sources independently');
            break;
          case 'behavioral':
            recommendations.push('Monitor transaction patterns closely');
            break;
          case 'historical':
            recommendations.push('Review historical payment behavior details');
            break;
        }
      }
    });
    
    return Array.from(new Set(recommendations)); // Remove duplicates
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Agent factory
export class AgentFactory {
  private static agents = new Map<AgentType, BaseAgent>();

  static getAgent(type: AgentType): BaseAgent {
    if (!this.agents.has(type)) {
      switch (type) {
        case 'data_extraction':
          this.agents.set(type, new DataExtractionAgent());
          break;
        case 'eligibility':
          this.agents.set(type, new EligibilityAgent());
          break;
        case 'risk_assessment':
          this.agents.set(type, new RiskAssessmentAgent());
          break;
        default:
          throw new Error(`Unknown agent type: ${type}`);
      }
    }
    
    return this.agents.get(type)!;
  }

  static async executeAgent(agentType: AgentType): Promise<AgentExecutionResult> {
    const agent = this.getAgent(agentType);
    const dbAgent = await storage.getAgentByType(agentType);
    
    if (!dbAgent) {
      throw new Error(`Agent of type ${agentType} not found in database`);
    }

    // Get active configuration for this agent  
    const configuration = await storage.getActiveConfiguration(dbAgent.id) || null;
    
    // Create execution context
    const executionId = `exec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const context: AgentExecutionContext = {
      agentId: dbAgent.id,
      agentName: dbAgent.name,
      executionId,
      configuration
    };

    // Log execution start
    await storage.createExecutionHistory({
      executionId,
      agentId: dbAgent.id,
      agentType,
      status: 'running',
      configurationId: configuration?.id || null
    });

    // Execute the agent
    const result = await agent.execute(context);
    
    // Update execution history with results
    const historyRecords = await storage.getExecutionHistory(1);
    const currentExecution = historyRecords.find(h => h.executionId === executionId);
    
    if (currentExecution) {
      await storage.updateExecutionHistory(currentExecution.id, {
        status: result.success ? 'success' : 'failed',
        endTime: new Date(),
        duration: result.processingTime,
        result: result.data,
        errorMessage: result.errorDetails || null
      });
    }

    // Update agent status
    if (result.success) {
      await storage.updateAgentStatus(dbAgent.id, 'complete', 100);
    } else {
      await storage.updateAgentStatus(dbAgent.id, 'error', 0);
    }

    return result;
  }
}