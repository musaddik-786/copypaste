import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertExecutionLogSchema } from "@shared/schema";
import { AgentFactory } from "./agents";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all agents
  app.get("/api/agents", async (req, res) => {
    try {
      const agents = await storage.getAgents();
      res.json(agents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch agents", error });
    }
  });

  // Initialize all FastAPI servers
  app.post("/api/system/initialize", async (req, res) => {
    try {
      await storage.addExecutionLog({
        message: "FastAPI servers initialization started",
        status: "running"
      });

      // Simulate server startup delays
      setTimeout(async () => {
        await storage.addExecutionLog({
          message: "Data Extraction service online",
          status: "complete"
        });
      }, 1000);

      setTimeout(async () => {
        await storage.addExecutionLog({
          message: "Eligibility service online", 
          status: "complete"
        });
      }, 1500);

      setTimeout(async () => {
        await storage.addExecutionLog({
          message: "Risk Assessment service online",
          status: "complete"
        });
      }, 2000);

      const agents = await storage.getAgents();
      res.json({
        success: true,
        message: "All FastAPI servers initialized successfully!",
        agents
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to initialize system", error });
    }
  });

  // Execute orchestration workflow
  app.post("/api/orchestration", async (req, res) => {
    try {
      const executionId = `exec_${Date.now()}`;
      
      await storage.addExecutionLog({
        message: "Sequential orchestration workflow initiated",
        status: "running"
      });

      // Reset all agents
      await storage.resetAllAgents();

      res.json({
        success: true,
        message: "Orchestration workflow started",
        executionId
      });

      // Execute sequential workflow in background
      executeSequentialWorkflowReal();
      
    } catch (error) {
      res.status(500).json({ message: "Failed to start orchestration", error });
    }
  });

  // Execute individual agent
  app.post("/api/agents/:type/execute", async (req, res) => {
    try {
      const { type } = req.params;
      const agent = await storage.getAgentByType(type as any);
      
      if (!agent) {
        return res.status(404).json({ message: `Agent of type ${type} not found` });
      }

      await storage.addExecutionLog({
        agentId: agent.id,
        message: `${agent.name} execution started`,
        status: "running",
        level: "info"
      });

      // Execute the real agent
      executeRealAgent(type as any);

      res.json({
        success: true,
        message: `${agent.name} execution started`,
        agent
      });

    } catch (error) {
      res.status(500).json({ message: "Failed to execute agent", error });
    }
  });

  // Get execution logs
  app.get("/api/logs", async (req, res) => {
    try {
      const logs = await storage.getExecutionLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch logs", error });
    }
  });

  // WebSocket-like endpoint for real-time updates (using polling)
  app.get("/api/agents/status", async (req, res) => {
    try {
      const agents = await storage.getAgents();
      const logs = await storage.getExecutionLogs();
      res.json({ agents, logs });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch status", error });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to execute real agent logic
async function executeRealAgent(agentType: 'data_extraction' | 'eligibility' | 'risk_assessment') {
  try {
    const result = await AgentFactory.executeAgent(agentType);
    
    if (!result.success) {
      console.error(`Agent ${agentType} execution failed:`, result.errorDetails);
    }
  } catch (error) {
    console.error(`Error executing agent ${agentType}:`, error);
    
    // Update agent status to error
    const agent = await storage.getAgentByType(agentType);
    if (agent) {
      await storage.updateAgentStatus(agent.id, 'error', 0);
      await storage.addExecutionLog({
        agentId: agent.id,
        message: `${agent.name} execution failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        status: "error",
        level: "error"
      });
    }
  }
}

// Helper function for sequential workflow execution with real agents
async function executeSequentialWorkflowReal() {
  const agentTypes = ['data_extraction', 'eligibility', 'risk_assessment'] as const;
  
  await storage.addExecutionLog({
    message: "Starting sequential orchestration workflow",
    status: "running",
    level: "info"
  });
  
  for (const type of agentTypes) {
    try {
      const agent = await storage.getAgentByType(type);
      if (agent) {
        await storage.addExecutionLog({
          agentId: agent.id,
          message: `Starting ${agent.name} in orchestration sequence`,
          status: "running",
          level: "info"
        });
        
        const result = await AgentFactory.executeAgent(type);
        
        if (result.success) {
          await storage.addExecutionLog({
            agentId: agent.id,
            message: `${agent.name} completed successfully in ${result.processingTime}ms`,
            status: "complete",
            level: "info"
          });
        } else {
          await storage.addExecutionLog({
            agentId: agent.id,
            message: `${agent.name} failed: ${result.errorDetails}`,
            status: "error",
            level: "error"
          });
          // Continue with other agents even if one fails
        }
        
        // Brief pause between agents
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    } catch (error) {
      await storage.addExecutionLog({
        message: `Error in orchestration workflow for ${type}: ${error instanceof Error ? error.message : 'Unknown error'}`,
        status: "error",
        level: "error"
      });
    }
  }
  
  await storage.addExecutionLog({
    message: "Orchestration workflow sequence completed",
    status: "complete",
    level: "info"
  });
}
