import { 
  type Agent, 
  type InsertAgent, 
  type ExecutionLog, 
  type InsertExecutionLog, 
  type AgentConfiguration,
  type InsertAgentConfiguration,
  type ExecutionHistory,
  type InsertExecutionHistory,
  type AgentHealthMetrics,
  type InsertAgentHealthMetrics,
  type AgentStatus, 
  type AgentType,
  DEFAULT_AGENT_CONFIGS,
  agents,
  executionLogs,
  agentConfigurations,
  executionHistory,
  agentHealthMetrics
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // Agent operations
  getAgents(): Promise<Agent[]>;
  getAgent(id: string): Promise<Agent | undefined>;
  getAgentByType(type: AgentType): Promise<Agent | undefined>;
  createAgent(agent: InsertAgent): Promise<Agent>;
  updateAgentStatus(id: string, status: AgentStatus, progress?: number): Promise<Agent>;
  resetAllAgents(): Promise<Agent[]>;
  
  // Execution log operations
  getExecutionLogs(): Promise<ExecutionLog[]>;
  addExecutionLog(log: InsertExecutionLog): Promise<ExecutionLog>;
  clearExecutionLogs(): Promise<void>;
  
  // Agent configuration operations
  getAgentConfigurations(agentId: string): Promise<AgentConfiguration[]>;
  createAgentConfiguration(config: InsertAgentConfiguration): Promise<AgentConfiguration>;
  updateAgentConfiguration(id: string, config: Partial<InsertAgentConfiguration>): Promise<AgentConfiguration>;
  getActiveConfiguration(agentId: string): Promise<AgentConfiguration | undefined>;
  
  // Execution history operations
  getExecutionHistory(limit?: number): Promise<ExecutionHistory[]>;
  createExecutionHistory(history: InsertExecutionHistory): Promise<ExecutionHistory>;
  updateExecutionHistory(id: string, updates: Partial<ExecutionHistory>): Promise<ExecutionHistory>;
  getExecutionHistoryByAgent(agentId: string, limit?: number): Promise<ExecutionHistory[]>;
  
  // Health monitoring operations
  getLatestAgentHealthMetrics(agentId: string): Promise<AgentHealthMetrics | undefined>;
  addAgentHealthMetrics(agentId: string, metrics: InsertAgentHealthMetrics): Promise<AgentHealthMetrics>;
  getAllHealthMetrics(): Promise<AgentHealthMetrics[]>;
  getAgentHealthHistory(agentId: string, limit?: number): Promise<AgentHealthMetrics[]>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeDefaultAgents();
  }

  private async initializeDefaultAgents() {
    // Check if agents already exist
    const existingAgents = await db.select().from(agents);
    
    if (existingAgents.length === 0) {
      const defaultAgents: InsertAgent[] = [
        {
          name: "Data Extraction",
          type: "data_extraction",
          status: "idle",
          progress: 0,
        },
        {
          name: "Eligibility",
          type: "eligibility", 
          status: "idle",
          progress: 0,
        },
        {
          name: "Risk Assessment",
          type: "risk_assessment",
          status: "idle",
          progress: 0,
        }
      ];

      // Create default agents and configurations
      for (const agentData of defaultAgents) {
        const agent = await this.createAgent(agentData);
        
        // Create default configuration for each agent
        const defaultConfig = DEFAULT_AGENT_CONFIGS[agentData.type as keyof typeof DEFAULT_AGENT_CONFIGS];
        await this.createAgentConfiguration({
          agentId: agent.id,
          name: "Default Configuration",
          parameters: defaultConfig as any,
          isActive: true
        });
      }

      await this.addExecutionLog({
        message: "System initialized successfully",
        status: "complete"
      });
    }
  }

  async getAgents(): Promise<Agent[]> {
    return await db.select().from(agents);
  }

  async getAgent(id: string): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent || undefined;
  }

  async getAgentByType(type: AgentType): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.type, type));
    return agent || undefined;
  }

  async createAgent(insertAgent: InsertAgent): Promise<Agent> {
    const [agent] = await db
      .insert(agents)
      .values(insertAgent)
      .returning();
    return agent;
  }

  async updateAgentStatus(id: string, status: AgentStatus, progress = 0): Promise<Agent> {
    // Build the update object conditionally to avoid overwriting lastExecuted
    const updateData: any = { status, progress };
    if (status === 'complete') {
      updateData.lastExecuted = new Date();
    }
    
    const [agent] = await db
      .update(agents)
      .set(updateData)
      .where(eq(agents.id, id))
      .returning();
    
    if (!agent) {
      throw new Error(`Agent with id ${id} not found`);
    }
    
    return agent;
  }

  async resetAllAgents(): Promise<Agent[]> {
    await db
      .update(agents)
      .set({
        status: 'idle',
        progress: 0
      });
    
    return this.getAgents();
  }

  async getExecutionLogs(): Promise<ExecutionLog[]> {
    return await db
      .select()
      .from(executionLogs)
      .orderBy(desc(executionLogs.timestamp))
      .limit(50);
  }

  async addExecutionLog(insertLog: InsertExecutionLog): Promise<ExecutionLog> {
    const [log] = await db
      .insert(executionLogs)
      .values(insertLog)
      .returning();
    return log;
  }

  async clearExecutionLogs(): Promise<void> {
    await db.delete(executionLogs);
  }

  // Agent configuration operations
  async getAgentConfigurations(agentId: string): Promise<AgentConfiguration[]> {
    return await db
      .select()
      .from(agentConfigurations)
      .where(eq(agentConfigurations.agentId, agentId))
      .orderBy(desc(agentConfigurations.createdAt));
  }

  async createAgentConfiguration(config: InsertAgentConfiguration): Promise<AgentConfiguration> {
    // If creating an active configuration, deactivate all other active configs for this agent
    if (config.isActive) {
      await db
        .update(agentConfigurations)
        .set({ isActive: false, updatedAt: new Date() })
        .where(and(
          eq(agentConfigurations.agentId, config.agentId),
          eq(agentConfigurations.isActive, true)
        ));
    }
    
    const [configuration] = await db
      .insert(agentConfigurations)
      .values(config)
      .returning();
    return configuration;
  }

  async updateAgentConfiguration(id: string, config: Partial<InsertAgentConfiguration>): Promise<AgentConfiguration> {
    // If setting this configuration to active, first deactivate all other active configs for this agent
    if (config.isActive === true) {
      // Get the configuration to find its agentId
      const [existingConfig] = await db
        .select({ agentId: agentConfigurations.agentId })
        .from(agentConfigurations)
        .where(eq(agentConfigurations.id, id));
      
      if (existingConfig) {
        await db
          .update(agentConfigurations)
          .set({ isActive: false, updatedAt: new Date() })
          .where(and(
            eq(agentConfigurations.agentId, existingConfig.agentId),
            eq(agentConfigurations.isActive, true)
          ));
      }
    }
    
    const [configuration] = await db
      .update(agentConfigurations)
      .set({ ...config, updatedAt: new Date() })
      .where(eq(agentConfigurations.id, id))
      .returning();
    
    if (!configuration) {
      throw new Error(`Configuration with id ${id} not found`);
    }
    
    return configuration;
  }

  async getActiveConfiguration(agentId: string): Promise<AgentConfiguration | undefined> {
    const [config] = await db
      .select()
      .from(agentConfigurations)
      .where(and(
        eq(agentConfigurations.agentId, agentId),
        eq(agentConfigurations.isActive, true)
      ))
      .orderBy(desc(agentConfigurations.createdAt))
      .limit(1);
    
    return config || undefined;
  }

  // Execution history operations
  async getExecutionHistory(limit = 50): Promise<ExecutionHistory[]> {
    return await db
      .select()
      .from(executionHistory)
      .orderBy(desc(executionHistory.startTime))
      .limit(limit);
  }

  async createExecutionHistory(history: InsertExecutionHistory): Promise<ExecutionHistory> {
    const [record] = await db
      .insert(executionHistory)
      .values(history)
      .returning();
    return record;
  }

  async updateExecutionHistory(id: string, updates: Partial<ExecutionHistory>): Promise<ExecutionHistory> {
    const [record] = await db
      .update(executionHistory)
      .set(updates)
      .where(eq(executionHistory.id, id))
      .returning();
    
    if (!record) {
      throw new Error(`Execution history with id ${id} not found`);
    }
    
    return record;
  }

  async getExecutionHistoryByAgent(agentId: string, limit = 20): Promise<ExecutionHistory[]> {
    return await db
      .select()
      .from(executionHistory)
      .where(eq(executionHistory.agentId, agentId))
      .orderBy(desc(executionHistory.startTime))
      .limit(limit);
  }

  // Health monitoring operations
  async getLatestAgentHealthMetrics(agentId: string): Promise<AgentHealthMetrics | undefined> {
    const [metrics] = await db
      .select()
      .from(agentHealthMetrics)
      .where(eq(agentHealthMetrics.agentId, agentId))
      .orderBy(desc(agentHealthMetrics.lastHealthCheck))
      .limit(1);
    
    return metrics || undefined;
  }

  async addAgentHealthMetrics(agentId: string, metrics: InsertAgentHealthMetrics): Promise<AgentHealthMetrics> {
    // Always insert new records for time-series data - never update existing ones
    const [created] = await db
      .insert(agentHealthMetrics)
      .values({ ...metrics, agentId })
      .returning();
    return created;
  }

  async getAgentHealthHistory(agentId: string, limit = 50): Promise<AgentHealthMetrics[]> {
    return await db
      .select()
      .from(agentHealthMetrics)
      .where(eq(agentHealthMetrics.agentId, agentId))
      .orderBy(desc(agentHealthMetrics.lastHealthCheck))
      .limit(limit);
  }

  async getAllHealthMetrics(): Promise<AgentHealthMetrics[]> {
    return await db
      .select()
      .from(agentHealthMetrics)
      .orderBy(desc(agentHealthMetrics.lastHealthCheck));
  }
}

// In-memory storage implementation for when database is unavailable
export class MemStorage implements IStorage {
  private agents: Agent[] = [];
  private executionLogs: ExecutionLog[] = [];
  private agentConfigurations: AgentConfiguration[] = [];
  private executionHistoryRecords: ExecutionHistory[] = [];
  private healthMetrics: AgentHealthMetrics[] = [];
  private idCounter = 1;

  constructor() {
    this.initializeDefaultAgents();
  }

  private async initializeDefaultAgents() {
    const defaultAgents: InsertAgent[] = [
      {
        name: "Data Extraction",
        type: "data_extraction",
        status: "idle",
        progress: 0,
      },
      {
        name: "Eligibility",
        type: "eligibility", 
        status: "idle",
        progress: 0,
      },
      {
        name: "Risk Assessment",
        type: "risk_assessment",
        status: "idle",
        progress: 0,
      }
    ];

    // Create default agents and configurations
    for (const agentData of defaultAgents) {
      const agent = await this.createAgent(agentData);
      
      // Create default configuration for each agent
      const defaultConfig = DEFAULT_AGENT_CONFIGS[agentData.type as keyof typeof DEFAULT_AGENT_CONFIGS];
      await this.createAgentConfiguration({
        agentId: agent.id,
        name: "Default Configuration",
        parameters: defaultConfig as any,
        isActive: true
      });
    }

    await this.addExecutionLog({
      message: "System initialized successfully with in-memory storage",
      status: "complete",
      level: "info"
    });
  }

  private generateId(): string {
    return `id_${this.idCounter++}_${Date.now()}`;
  }

  async getAgents(): Promise<Agent[]> {
    return [...this.agents];
  }

  async getAgent(id: string): Promise<Agent | undefined> {
    return this.agents.find(agent => agent.id === id);
  }

  async getAgentByType(type: AgentType): Promise<Agent | undefined> {
    return this.agents.find(agent => agent.type === type);
  }

  async createAgent(insertAgent: InsertAgent): Promise<Agent> {
    const agent: Agent = {
      id: this.generateId(),
      name: insertAgent.name,
      type: insertAgent.type,
      status: insertAgent.status || 'idle',
      progress: insertAgent.progress || 0,
      lastExecuted: null
    };
    this.agents.push(agent);
    return agent;
  }

  async updateAgentStatus(id: string, status: AgentStatus, progress = 0): Promise<Agent> {
    const agent = this.agents.find(a => a.id === id);
    if (!agent) {
      throw new Error(`Agent with id ${id} not found`);
    }
    
    agent.status = status;
    agent.progress = progress;
    
    if (status === 'complete') {
      agent.lastExecuted = new Date();
    }
    
    return agent;
  }

  async resetAllAgents(): Promise<Agent[]> {
    this.agents.forEach(agent => {
      agent.status = 'idle';
      agent.progress = 0;
    });
    return [...this.agents];
  }

  async getExecutionLogs(): Promise<ExecutionLog[]> {
    return [...this.executionLogs]
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, 50);
  }

  async addExecutionLog(insertLog: InsertExecutionLog): Promise<ExecutionLog> {
    const log: ExecutionLog = {
      id: this.generateId(),
      agentId: insertLog.agentId || null,
      message: insertLog.message,
      level: insertLog.level || 'info',
      status: insertLog.status,
      executionId: null,
      details: null,
      timestamp: new Date()
    };
    this.executionLogs.push(log);
    
    // Keep only last 100 logs to prevent memory bloat
    if (this.executionLogs.length > 100) {
      this.executionLogs = this.executionLogs.slice(-100);
    }
    
    return log;
  }

  async clearExecutionLogs(): Promise<void> {
    this.executionLogs = [];
  }

  async getAgentConfigurations(agentId: string): Promise<AgentConfiguration[]> {
    return this.agentConfigurations
      .filter(config => config.agentId === agentId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createAgentConfiguration(config: InsertAgentConfiguration): Promise<AgentConfiguration> {
    // If creating an active configuration, deactivate all other active configs for this agent
    if (config.isActive) {
      this.agentConfigurations
        .filter(c => c.agentId === config.agentId && c.isActive)
        .forEach(c => {
          c.isActive = false;
          c.updatedAt = new Date();
        });
    }
    
    const configuration: AgentConfiguration = {
      id: this.generateId(),
      ...config,
      isActive: config.isActive ?? false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.agentConfigurations.push(configuration);
    return configuration;
  }

  async updateAgentConfiguration(id: string, config: Partial<InsertAgentConfiguration>): Promise<AgentConfiguration> {
    const configuration = this.agentConfigurations.find(c => c.id === id);
    if (!configuration) {
      throw new Error(`Configuration with id ${id} not found`);
    }
    
    // If setting this configuration to active, first deactivate all other active configs for this agent
    if (config.isActive === true) {
      this.agentConfigurations
        .filter(c => c.agentId === configuration.agentId && c.isActive && c.id !== id)
        .forEach(c => {
          c.isActive = false;
          c.updatedAt = new Date();
        });
    }
    
    Object.assign(configuration, config, { updatedAt: new Date() });
    return configuration;
  }

  async getActiveConfiguration(agentId: string): Promise<AgentConfiguration | undefined> {
    return this.agentConfigurations
      .filter(c => c.agentId === agentId && c.isActive)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0];
  }

  async getExecutionHistory(limit = 50): Promise<ExecutionHistory[]> {
    return [...this.executionHistoryRecords]
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime())
      .slice(0, limit);
  }

  async createExecutionHistory(history: InsertExecutionHistory): Promise<ExecutionHistory> {
    const record: ExecutionHistory = {
      id: this.generateId(),
      ...history,
      agentId: history.agentId || null,
      configurationId: history.configurationId || null,
      startTime: new Date(),
      endTime: null,
      duration: null,
      result: null,
      errorMessage: null
    };
    
    this.executionHistoryRecords.push(record);
    return record;
  }

  async updateExecutionHistory(id: string, updates: Partial<ExecutionHistory>): Promise<ExecutionHistory> {
    const record = this.executionHistoryRecords.find(r => r.id === id);
    if (!record) {
      throw new Error(`Execution history with id ${id} not found`);
    }
    
    Object.assign(record, updates);
    return record;
  }

  async getExecutionHistoryByAgent(agentId: string, limit = 20): Promise<ExecutionHistory[]> {
    return this.executionHistoryRecords
      .filter(r => r.agentId === agentId)
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime())
      .slice(0, limit);
  }

  async getLatestAgentHealthMetrics(agentId: string): Promise<AgentHealthMetrics | undefined> {
    return this.healthMetrics
      .filter(m => m.agentId === agentId)
      .sort((a, b) => b.lastHealthCheck.getTime() - a.lastHealthCheck.getTime())[0];
  }

  async addAgentHealthMetrics(agentId: string, metrics: InsertAgentHealthMetrics): Promise<AgentHealthMetrics> {
    const created: AgentHealthMetrics = {
      id: this.generateId(),
      agentId,
      cpuUsage: metrics.cpuUsage ?? null,
      memoryUsage: metrics.memoryUsage ?? null,
      responseTime: metrics.responseTime ?? null,
      errorRate: metrics.errorRate ?? null,
      uptime: metrics.uptime ?? null,
      isHealthy: metrics.isHealthy ?? true,
      lastHealthCheck: new Date(),
      metrics: metrics.metrics ?? null
    };
    
    this.healthMetrics.push(created);
    
    // Keep only last 100 health records per agent to prevent memory bloat
    const agentMetrics = this.healthMetrics.filter(m => m.agentId === agentId);
    if (agentMetrics.length > 100) {
      const toRemove = agentMetrics.slice(0, -100);
      this.healthMetrics = this.healthMetrics.filter(m => !toRemove.includes(m));
    }
    
    return created;
  }

  async getAgentHealthHistory(agentId: string, limit = 50): Promise<AgentHealthMetrics[]> {
    return this.healthMetrics
      .filter(m => m.agentId === agentId)
      .sort((a, b) => b.lastHealthCheck.getTime() - a.lastHealthCheck.getTime())
      .slice(0, limit);
  }

  async getAllHealthMetrics(): Promise<AgentHealthMetrics[]> {
    return [...this.healthMetrics]
      .sort((a, b) => b.lastHealthCheck.getTime() - a.lastHealthCheck.getTime());
  }
}

// Use in-memory storage to avoid database connection issues
export const storage = new MemStorage();

// Keep DatabaseStorage available for when database is working
// export const storage = new DatabaseStorage();
