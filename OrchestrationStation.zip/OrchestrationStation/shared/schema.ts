import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, boolean, real, unique, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const agents = pgTable("agents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'data_extraction', 'eligibility', 'risk_assessment'
  status: text("status").notNull().default("idle"), // 'idle', 'running', 'complete', 'error'
  progress: integer("progress").notNull().default(0),
  lastExecuted: timestamp("last_executed"),
}, (table) => ({
  // Ensure only one agent per type exists
  uniqueAgentType: unique().on(table.type),
}));

export const executionLogs = pgTable("execution_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  agentId: varchar("agent_id").references(() => agents.id),
  executionId: varchar("execution_id"),
  message: text("message").notNull(),
  level: text("level").notNull().default("info"), // 'info', 'warning', 'error', 'debug'
  status: text("status").notNull(), // 'complete', 'running', 'error', 'idle'
  details: jsonb("details"), // Additional structured log data
  timestamp: timestamp("timestamp").notNull().default(sql`now()`),
}, (table) => ({
  // Indexes for performance
  agentIdIdx: index().on(table.agentId),
  executionIdIdx: index().on(table.executionId),
  timestampIdx: index().on(table.timestamp),
}));

export const agentConfigurations = pgTable("agent_configurations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  agentId: varchar("agent_id").notNull().references(() => agents.id),
  name: text("name").notNull(),
  parameters: jsonb("parameters").notNull(), // JSON object with configuration parameters
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
}, (table) => ({
  // Indexes for performance
  agentIdIdx: index().on(table.agentId),
  createdAtIdx: index().on(table.createdAt),
  // Index for active configurations per agent (constraint will be enforced in storage logic)
  activeConfigIdx: index().on(table.agentId, table.isActive),
}));

export const executionHistory = pgTable("execution_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  executionId: varchar("execution_id").notNull(),
  agentId: varchar("agent_id").references(() => agents.id),
  agentType: text("agent_type").notNull(),
  status: text("status").notNull(), // 'success', 'failed', 'cancelled', 'running'
  startTime: timestamp("start_time").notNull().default(sql`now()`),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // Duration in milliseconds
  result: jsonb("result"), // Execution result data
  errorMessage: text("error_message"),
  configurationId: varchar("configuration_id").references(() => agentConfigurations.id),
}, (table) => ({
  // Indexes for performance
  executionIdIdx: index().on(table.executionId),
  agentIdIdx: index().on(table.agentId),
  startTimeIdx: index().on(table.startTime),
  configurationIdIdx: index().on(table.configurationId),
}));

export const agentHealthMetrics = pgTable("agent_health_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  agentId: varchar("agent_id").notNull().references(() => agents.id),
  cpuUsage: real("cpu_usage"),
  memoryUsage: real("memory_usage"),
  responseTime: integer("response_time"), // in milliseconds
  errorRate: real("error_rate"), // percentage
  uptime: integer("uptime"), // in seconds
  isHealthy: boolean("is_healthy").notNull().default(true),
  lastHealthCheck: timestamp("last_health_check").notNull().default(sql`now()`),
  metrics: jsonb("metrics"), // Additional custom metrics
}, (table) => ({
  // Indexes for performance and time-series queries
  agentIdIdx: index().on(table.agentId),
  lastHealthCheckIdx: index().on(table.lastHealthCheck),
  // Composite index for efficient agent health history queries
  agentHealthHistoryIdx: index().on(table.agentId, table.lastHealthCheck),
}));

export const insertAgentSchema = createInsertSchema(agents).omit({
  id: true,
  lastExecuted: true,
});

export const insertExecutionLogSchema = createInsertSchema(executionLogs).omit({
  id: true,
  timestamp: true,
});

export const insertAgentConfigurationSchema = createInsertSchema(agentConfigurations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertExecutionHistorySchema = createInsertSchema(executionHistory).omit({
  id: true,
  startTime: true,
});

export const insertAgentHealthMetricsSchema = createInsertSchema(agentHealthMetrics).omit({
  id: true,
  lastHealthCheck: true,
});

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type ExecutionLog = typeof executionLogs.$inferSelect;
export type InsertExecutionLog = z.infer<typeof insertExecutionLogSchema>;
export type AgentConfiguration = typeof agentConfigurations.$inferSelect;
export type InsertAgentConfiguration = z.infer<typeof insertAgentConfigurationSchema>;
export type ExecutionHistory = typeof executionHistory.$inferSelect;
export type InsertExecutionHistory = z.infer<typeof insertExecutionHistorySchema>;
export type AgentHealthMetrics = typeof agentHealthMetrics.$inferSelect;
export type InsertAgentHealthMetrics = z.infer<typeof insertAgentHealthMetricsSchema>;

// Agent execution status types
export type AgentStatus = 'idle' | 'running' | 'complete' | 'error';
export type AgentType = 'data_extraction' | 'eligibility' | 'risk_assessment';
export type LogLevel = 'info' | 'warning' | 'error' | 'debug';
export type ExecutionStatus = 'success' | 'failed' | 'cancelled' | 'running';

// Default agent configurations
export const DEFAULT_AGENT_CONFIGS = {
  data_extraction: {
    timeout: 30000,
    retryAttempts: 3,
    batchSize: 100,
    sources: ['database', 'api', 'file']
  },
  eligibility: {
    timeout: 15000,
    retryAttempts: 2,
    strictMode: true,
    rules: ['age_verification', 'income_check', 'credit_score']
  },
  risk_assessment: {
    timeout: 45000,
    retryAttempts: 2,
    riskThreshold: 0.7,
    factors: ['financial', 'behavioral', 'historical']
  }
} as const;

// API response types
export interface AgentExecutionResponse {
  success: boolean;
  message: string;
  agent: Agent;
}

export interface SystemInitResponse {
  success: boolean;
  message: string;
  agents: Agent[];
}

export interface OrchestrationResponse {
  success: boolean;
  message: string;
  executionId: string;
}

export interface AgentHealthStatus {
  agentId: string;
  isHealthy: boolean;
  responseTime: number;
  errorRate: number;
  uptime: number;
  lastCheck: Date;
  metrics?: Record<string, any>;
}

export interface ExecutionHistoryEntry {
  id: string;
  executionId: string;
  agentType: AgentType;
  status: ExecutionStatus;
  startTime: Date;
  endTime?: Date;
  duration?: number;
  result?: Record<string, any>;
  errorMessage?: string;
}
