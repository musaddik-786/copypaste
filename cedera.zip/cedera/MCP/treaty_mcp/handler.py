# from common.db import get_db_connection


# def get_treaty_info(treaty_number):
#     connection = get_db_connection()
    
#     try:
#         cursor = connection.cursor(dictionary = True)
#         query = """
#             Select * from treaties where treaty_ref = %s
#         """
    
#         cursor.execute(query,(treaty_ref,))
#         treaty = cursor.fetchone()

#         if not treaty:
#             return {
#                 "status" : "not_found",
#                 "message" : f"Treaty {treaty_ref} was not found"
#             }
        
#         return {
#             "status" : "success",
#             "data" : treaty
#         }
#     finally:
#         cursor.close()
#         connection.close()


from common.db import get_db_connection
from psycopg2.extras import RealDictCursor

def get_treaty_info(treaty_ref: str):
   connection = None
   cursor = None
   try:
       connection = get_db_connection()
       cursor = connection.cursor(cursor_factory=RealDictCursor)
       query = """
           SELECT *
           FROM treaties
           WHERE treaty_ref = %s
       """
       cursor.execute(query, (treaty_ref,))
       treaty = cursor.fetchone()
       if not treaty:
           return {
               "status": "not_found",
               "message": f"Treaty {treaty_ref} was not found"
           }
       return {
           "status": "success",
           "data": dict(treaty)
       }
   finally:
       if cursor:
           cursor.close()
       if connection:
           connection.close()













def list_treaties(
    status: str | None = None,
    class_of_business: str | None = None,
    as_at: str | None = None
):
    connection = get_db_connection()

    try:
        cursor = connection.cursor(cursor_factory=RealDictCursor)

        query = """
            SELECT *
            FROM treaties
            WHERE 1=1
        """

        params = []

        if status:
            query += " AND status = %s"
            params.append(status)

        if class_of_business:
            query += " AND class_of_business = %s"
            params.append(class_of_business)

        if as_at:
            query += " AND inception_date <= %s"
            params.append(as_at)

        query += " ORDER BY treaty_ref"

        cursor.execute(query, params)

        treaties = cursor.fetchall()

        return {
            "status": "success",
            "count": len(treaties),
            "data": [dict(treaty) for treaty in treaties]
        }

    finally:
        cursor.close()
        connection.close()









def get_treaty_terms(treaty_ref: str):
    connection = get_db_connection()

    try:
        cursor = connection.cursor(cursor_factory=RealDictCursor)

        query = """
            SELECT *
            FROM treaty_terms
            WHERE treaty_ref = %s
            ORDER BY layer_number
        """

        cursor.execute(query, (treaty_ref,))
        terms = cursor.fetchall()

        if not terms:
            return {
                "status": "not_found",
                "message": f"No terms found for treaty {treaty_ref}"
            }

        return {
            "status": "success",
            "treaty_ref": treaty_ref,
            "count": len(terms),
            "data": [dict(term) for term in terms]
        }

    finally:
        cursor.close()
        connection.close()



def list_exclusions(treaty_ref: str):
    connection = get_db_connection()

    try:
        cursor = connection.cursor(cursor_factory=RealDictCursor)

        query = """
            SELECT *
            FROM treaty_exclusions
            WHERE treaty_ref = %s
            ORDER BY exclusion_ref
        """

        cursor.execute(query, (treaty_ref,))
        exclusions = cursor.fetchall()

        if not exclusions:
            return {
                "status": "not_found",
                "message": f"No exclusions found for treaty {treaty_ref}"
            }

        return {
            "status": "success",
            "treaty_ref": treaty_ref,
            "count": len(exclusions),
            "data": [dict(exclusion) for exclusion in exclusions]
        }

    finally:
        cursor.close()
        connection.close()





def get_clause(clause_ref: str, treaty_ref: str):
    connection = get_db_connection()

    try:
        cursor = connection.cursor(cursor_factory=RealDictCursor)

        query = """
            SELECT *
            FROM treaty_clauses
            WHERE clause_ref = %s
              AND treaty_ref = %s
        """

        cursor.execute(query, (clause_ref, treaty_ref))
        clause = cursor.fetchone()

        if not clause:
            return {
                "status": "not_found",
                "message": (
                    f"Clause {clause_ref} was not found "
                    f"for treaty {treaty_ref}"
                )
            }

        return {
            "status": "success",
            "data": dict(clause)
        }

    finally:
        cursor.close()
        connection.close()



