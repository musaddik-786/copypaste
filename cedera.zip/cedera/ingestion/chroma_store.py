import chromadb


CHROMA_PATH = "./chroma_db"


def get_chroma_collection():
    client = chromadb.PersistentClient(path=CHROMA_PATH)

    collection = client.get_or_create_collection(
        name="treaty_clauses"
    )

    return collection