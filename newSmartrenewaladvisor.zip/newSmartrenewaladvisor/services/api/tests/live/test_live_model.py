"""Opt-in smoke test against the REAL configured model (claimsfoundry gpt-4.1, keyless DefaultAzureCredential).

    .venv\\Scripts\\python -m pytest services/api/tests/live -m live -o addopts=""

SYNTHETIC data only: the fact pack is built from the demo persona Sarah Jenkins' cards and the draft statements.
Passes if the model returns schema-valid JSON; validator results are printed. In the service, any validator
failure is retried once and then replaced by the standard template, so a failing validator here is a quality
signal for the prompt, not a safety problem.
"""
from __future__ import annotations

import json
from typing import Any

import pytest
from sra_api.narrative.clients import AzureOpenAIClient
from sra_api.narrative.fact_pack import Statement, build
from sra_api.narrative.validators import ValidationContext, findings, passed, run_all
from sra_api.settings import REPO_ROOT, get_settings

pytestmark = pytest.mark.live

DRAFT: dict[str, Any] = json.loads((REPO_ROOT / "ai/content/benefit_statements.draft.v1.json").read_text(
    encoding="utf-8"))
PROMPT = (REPO_ROOT / "ai/prompts/narrative_system.v1.md").read_text(encoding="utf-8")
CASES = [
    ("CS-LIA-01", "CROSS_SELL", "LIAB_PRIVATE", "Personal Liability Insurance",
     {"expiring_premium": "490.00", "base_renewal_premium": "515.00", "incremental_annual": "57.00",
      "incremental_monthly_equiv": "4.75", "companion_standalone_annual": "57.00", "bundle_discount_pct": "5",
      "bundle_saving_annual": "28.60", "net_annual_total": "543.40"},
     [{"op": "==", "left": "customer.occupancy", "left_value": "TENANT", "right": "TENANT", "right_value": "TENANT",
       "result": True}]),
    ("UP-CAR-04", "UPSELL", "CAR_NCD_PROTECTION", "No-Claims Discount Protection",
     {"expiring_premium": "420.00", "base_renewal_premium": "445.00", "incremental_annual": "45.60",
      "incremental_monthly_equiv": "3.80", "bundle_discount_pct": "0", "bundle_saving_annual": "0.00",
      "net_annual_total": "490.60"},
     [{"op": ">=", "left": "motor.bonus_tier", "left_value": 12, "right": "params.ncd_min_bonus_tier",
       "right_value": 8, "result": True}]),
]


@pytest.mark.parametrize("audience", ["OFFICER", "CUSTOMER_LETTER"])
@pytest.mark.parametrize("case", CASES, ids=[c[0] for c in CASES])
def test_real_model_returns_valid_narrative(case: tuple[Any, ...], audience: str) -> None:
    settings = get_settings()
    if not settings.azure_openai_endpoint or not settings.narrative_deployment:
        pytest.skip("AZURE_OPENAI_ENDPOINT / deployment not configured")
    rule_id, kind, product, name, pricing, clauses = case
    stmts = [Statement(k, t, "DRAFT") for k, t in DRAFT["products"][product].items()]
    pack = build(rule_id=rule_id, opportunity_type=kind, product_code=product, product_name=name,
                 priority_tier="P1", pricing=pricing, clauses=clauses, statements=stmts, audience=audience).pack
    messages = [{"role": "system", "content": PROMPT.replace("{{FACT_PACK_JSON}}", json.dumps(pack, indent=2))},
                {"role": "user", "content": "Write the narrative JSON for this fact pack."}]
    completion = AzureOpenAIClient(settings).complete(settings.narrative_deployment, messages)
    output = json.loads(completion.text)
    results = run_all(output, pack, ValidationContext(("Sarah", "Jenkins", "David", "Miller")))
    print(f"\n{rule_id}/{audience}: {completion.latency_ms} ms, tokens {completion.input_tokens}/"
          f"{completion.output_tokens}, all validators passed: {passed(results)}")
    for f in findings(results):
        print("   finding:", f)
    print("   letter_rationale:", output.get("letter_rationale"))
    assert results[0].passed, findings(results)  # schema-valid JSON is the minimum contract
