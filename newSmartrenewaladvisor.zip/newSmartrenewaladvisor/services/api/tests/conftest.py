"""Make `tests/support` importable as `support`."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
