"""In-memory implementation of the adapter ports, built from the synthetic data in tools/generate_seeds.py
(the same tuples that generate db/003). Lets the Fact Builder be tested without a database, and gives the
integration tests an independent expectation for the SQL adapter."""
from __future__ import annotations

import importlib.util
import sys
from datetime import UTC, date, datetime
from decimal import Decimal
from pathlib import Path
from types import ModuleType
from typing import Any

from sra_api.adapters.ports import Row

REPO = Path(__file__).resolve().parents[4]


def _load_seeds() -> ModuleType:
    spec = importlib.util.spec_from_file_location("generate_seeds", REPO / "tools" / "generate_seeds.py")
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules["generate_seeds"] = mod
    spec.loader.exec_module(mod)
    return mod


SEEDS = _load_seeds()
PERSONAS: dict[str, Any] = {k: v for k, v in SEEDS.PERSONAS.items() if not k.startswith("_")}
GOLDEN_AS_OF: date = SEEDS.AS_OF
QUOTE_TO_PERSONA = {p["quote"]["quote_id"]: key for key, p in PERSONAS.items()}


def _d(s: str | None) -> date | None:
    return date.fromisoformat(s) if s else None


def _ts(s: str) -> datetime:
    return datetime.fromisoformat(s if "T" in s else s + "T00:00:00").replace(tzinfo=UTC)


def _m(v: Any) -> Decimal:
    return Decimal(f"{float(v):.2f}")


class MemorySource:
    """Implements PasPort, CrmPort, ClaimsPort, ReferencePort and DeclineLedgerPort."""

    def __init__(self, declines: list[Row] | None = None) -> None:
        s = SEEDS
        cols = ("customer_id", "full_name", "date_of_birth", "street_address", "postal_code", "city", "region_code",
                "preferred_language", "preferred_channel", "occupancy", "dwelling_type", "household_type",
                "primary_earner", "has_dependants", "household_vehicle_count", "payment_status", "vulnerability_hold")
        self._customers = {c[0]: dict(zip(cols, c[:-1], strict=True)) for c in s.CUSTOMERS}
        self._policies = [dict(policy_id=p[0], customer_id=p[1], lob_code=p[2], base_product_code=p[3],
                               coverage_level=p[4], package_tier=p[5], status="ACTIVE", inception_date=_d(p[6]),
                               expiry_date=_d(p[7]), annual_premium_gross=_m(p[8]), insurance_tax=_m(p[9]))
                          for p in s.POLICIES]
        self._modules = [dict(policy_id=pid, product_code=pc,
                              attached_at=_d(next(p[6] for p in s.POLICIES if p[0] == pid))) for pid, pc in s.MODULES]
        self._vehicles = {v[0]: dict(policy_id=v[0], make_model=v[1], build_year=v[2], market_value=_m(v[3]),
                                     annual_km=v[4], annual_km_verified=v[5], bonus_tier=v[6], registration_plate=v[7])
                          for v in s.VEHICLES}
        self._properties = {p[0]: dict(policy_id=p[0], dwelling_type=p[1], build_year=p[2], floor_area_sqm=p[3],
                                       zuers_zone=p[4], heavy_rain_class=p[5], backwater_valve_certified=p[6],
                                       has_solar_or_heatpump=p[7], basement_or_ground_floor_storage=p[8])
                            for p in s.PROPERTIES}
        self._animals = [dict(policy_id=a[0], animal_ref=a[1], species=a[2], breed=a[3], birth_year=a[4])
                         for a in s.ANIMALS]
        self._claims = [dict(claim_id=c[0], policy_id=c[1], customer_id=c[2], loss_date=_d(c[3]),
                             reported_date=_d(c[4]), peril=c[5], at_fault=c[6], severity=c[7], status=c[8],
                             status_changed_at=_ts(c[9])) for c in s.CLAIMS]
        self._complaints = [dict(complaint_id=c[0], customer_id=c[1], opened_at=_ts(c[2]), status=c[3],
                                 closed_at=c[4]) for c in s.COMPLAINTS]
        self._declared = [dict(customer_id=d[0], fact_key=d[1], value=d[2], source=d[3], verified=d[4],
                               declared_at=_d(d[5])) for d in s.DECLARED]
        self._consents = [dict(customer_id=c[0], purpose="ADVISORY_RENEWAL", status="GRANTED", channel="POST",
                               captured_at=_ts("2025-01-15T10:00:00"), evidence_ref="CONSENT-EVID-" + c[0])
                          for c in s.CUSTOMERS]
        self._embeddings = [dict(parent_product_code=e[0], parent_tier=e[1], embedded_product_code=e[2])
                            for e in s.EMBEDDING]
        self._quotes: dict[str, Row] = {}
        self._rating: dict[str, list[Row]] = {}
        for pe in PERSONAS.values():
            qt, pol = pe["quote"], pe["policy"]
            customer_id = next(p["customer_id"] for p in self._policies if p["policy_id"] == qt["policy_id"])
            self._quotes[qt["quote_id"]] = dict(
                quote_id=qt["quote_id"], policy_id=qt["policy_id"], created_at=_ts(qt["created_at"] + "T06:00:00"),
                status="QUOTED", renewal_date=_d(s.QUOTE_DATES[qt["quote_id"]]), letter_due_date=_d(qt["letter_due"]),
                expiring_premium_gross=_m(pol["expiring_premium"]), renewal_premium_gross=_m(pol["renewal_premium"]),
                customer_id=customer_id)
            self._rating[qt["quote_id"]] = [
                dict(rating_quote_id=f"{qt['quote_id']}-R{i}", quote_id=qt["quote_id"], product_code=pc,
                     variant="STANDARD", annual_gross=_m(rq["annual_gross"]), valid_until=_d(qt["letter_due"]),
                     rated_at=_ts(qt["created_at"] + "T06:05:00"))
                for i, (pc, rq) in enumerate(sorted(pe["pas_quotes"].items()), 1)]
        self._declines = declines or []

    # PasPort
    def renewal_quote(self, quote_id: str) -> Row | None:
        return self._quotes.get(quote_id)

    def policies_of_customer(self, customer_id: str) -> list[Row]:
        return [p for p in self._policies if p["customer_id"] == customer_id]

    def policy_modules(self, policy_ids: list[str]) -> list[Row]:
        return [m for m in self._modules if m["policy_id"] in policy_ids]

    def insured_vehicle(self, policy_id: str) -> Row | None:
        return self._vehicles.get(policy_id)

    def insured_property(self, policy_id: str) -> Row | None:
        return self._properties.get(policy_id)

    def insured_animals(self, policy_id: str) -> list[Row]:
        return [a for a in self._animals if a["policy_id"] == policy_id]

    def rating_quotes(self, quote_id: str) -> list[Row]:
        return self._rating.get(quote_id, [])

    # CrmPort
    def customer(self, customer_id: str) -> Row | None:
        return self._customers.get(customer_id)

    def declared_facts(self, customer_id: str) -> list[Row]:
        return [d for d in self._declared if d["customer_id"] == customer_id]

    def consents(self, customer_id: str) -> list[Row]:
        return [c for c in self._consents if c["customer_id"] == customer_id]

    def complaints(self, customer_id: str) -> list[Row]:
        return [c for c in self._complaints if c["customer_id"] == customer_id]

    # ClaimsPort
    def claims_of_customer(self, customer_id: str) -> list[Row]:
        return [c for c in self._claims if c["customer_id"] == customer_id]

    # ReferencePort / DeclineLedgerPort
    def product_embeddings(self) -> list[Row]:
        return self._embeddings

    def declines(self, customer_id: str, exclude_case_id: Any = None) -> list[Row]:
        return self._declines
