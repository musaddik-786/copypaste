"""Compare a built Decision Context with a golden persona.

personas.json stores money as JSON floats (e.g. 445.0); the Fact Builder produces Decimal (from numeric(12,2)).
Those compare by value. Holdings lists compare as sets. `_delta_vs_prototype` is documentation, not a fact.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any

UNORDERED = {"portfolio.active_products", "portfolio.embedded_covers", "unverified_facts"}


def differences(built: Any, expected: Any, path: str = "") -> list[str]:
    if isinstance(expected, dict):
        if not isinstance(built, dict):
            return [f"{path}: expected object, got {built!r}"]
        out: list[str] = []
        keys = {k for k in expected if not k.startswith("_")} | set(built)
        for k in sorted(keys):
            p = f"{path}.{k}" if path else k
            if k not in built:
                out.append(f"{p}: missing in built context")
            elif k not in expected:
                out.append(f"{p}: unexpected key (value {built[k]!r})")
            else:
                out += differences(built[k], expected[k], p)
        return out
    if path in UNORDERED:
        return [] if sorted(built) == sorted(expected) else [f"{path}: {sorted(built)} != {sorted(expected)}"]
    if isinstance(built, Decimal) and isinstance(expected, int | float) and not isinstance(expected, bool):
        return [] if built == Decimal(str(expected)) else [f"{path}: {built} != {expected}"]
    if type(built) is not type(expected) and not (built is None or expected is None):
        return [f"{path}: type {type(built).__name__} != {type(expected).__name__} ({built!r} vs {expected!r})"]
    return [] if built == expected else [f"{path}: {built!r} != {expected!r}"]
