"""Integration fixtures against the configured PostgreSQL (DATABASE_URL in env or repo-root .env).

Every test runs inside one outer transaction that is ROLLED BACK at the end, so the database stays exactly as
`python tools/db_reset.py --confirm <db>` left it. The API's own session dependency is replaced by a session
bound to that transaction (savepoint mode), so requests never commit.
Tests are skipped when no database is configured or the seeds are not loaded.
"""
from __future__ import annotations

from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import Connection, text
from sqlalchemy.orm import Session
from sra_api.settings import get_settings
from support.seed_source import GOLDEN_AS_OF


def _engine_or_skip():  # type: ignore[no-untyped-def]
    if not get_settings().database_url:
        pytest.skip("DATABASE_URL not configured")
    from sra_api.db import get_engine
    return get_engine()


@pytest.fixture(scope="session", autouse=True)
def _pin_business_date(tmp_path_factory: pytest.TempPathFactory) -> Iterator[None]:
    """Decisions in these tests use the golden as_of (2026-10-13) so they match the golden personas."""
    mp = pytest.MonkeyPatch()
    mp.setenv("SRA_AS_OF", GOLDEN_AS_OF.isoformat())
    mp.setenv("SRA_ENV", "test")
    # Narratives: deterministic fake model (no network, no cost); the live model has its own opt-in test.
    mp.setenv("SRA_NARRATIVE_CLIENT", "fake")
    mp.setenv("SRA_NARRATIVE_MODEL", "gpt-4.1")
    mp.setenv("SRA_SOURCE_DATA_CLASS", "SYNTHETIC")
    mp.setenv("SRA_ALLOW_DRAFT_STATEMENTS", "true")
    # Rendered letters go to a temp dir: the DB rows are rolled back after each test, files would not be.
    mp.setenv("SRA_LETTER_STORAGE_DIR", str(tmp_path_factory.mktemp("letters")))
    get_settings.cache_clear()
    yield
    mp.undo()
    get_settings.cache_clear()


@pytest.fixture(scope="session")
def engine():  # type: ignore[no-untyped-def]
    eng = _engine_or_skip()
    with eng.connect() as c:
        if not c.execute(text("SELECT to_regclass('src.renewal_quote') IS NOT NULL")).scalar():
            pytest.skip("schema not loaded - run: python tools/db_reset.py --confirm <database>")
        if c.execute(text("SELECT count(*) FROM sra.renewal_case")).scalar():
            pytest.skip("sra.renewal_case is not empty - reset the database before running integration tests")
    return eng


@pytest.fixture
def conn(engine) -> Iterator[Connection]:  # type: ignore[no-untyped-def]
    connection = engine.connect()
    outer = connection.begin()
    try:
        yield connection
    finally:
        outer.rollback()
        connection.close()


@pytest.fixture
def session(conn: Connection) -> Iterator[Session]:
    s = Session(bind=conn, join_transaction_mode="create_savepoint", expire_on_commit=False)
    try:
        yield s
    finally:
        s.close()


@pytest.fixture
def client(session: Session) -> Iterator[TestClient]:
    from sra_api.db import get_session
    from sra_api.main import create_app

    app = create_app()

    def _session() -> Iterator[Session]:
        yield session
        session.flush()

    app.dependency_overrides[get_session] = _session
    with TestClient(app) as c:
        yield c


OFFICER = {"X-Dev-User": "officer.anna"}
AUDITOR = {"X-Dev-User": "auditor.ada"}
