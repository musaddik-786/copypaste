"""Phase 4 on the real database: narratives generated, validated, cached, routed and logged; template fallback;
token re-insertion; officer edits. The model is a scripted FakeClient (see test_live_model.py for the real one)."""
from __future__ import annotations

import json
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.orm import Session
from sra_api.audit.ledger import verify_chain
from sra_api.narrative.clients import FakeClient, set_client_override, valid_reply
from sra_api.settings import get_settings

from .conftest import OFFICER

SARAH = "QUO-2026-91402"


@contextmanager
def model(script: list[Any] | None = None) -> Iterator[FakeClient]:
    fake = FakeClient(script)
    set_client_override(fake)
    try:
        yield fake
    finally:
        set_client_override(None)


@contextmanager
def env(**values: str) -> Iterator[None]:
    mp = pytest.MonkeyPatch()
    for k, v in values.items():
        mp.setenv(k, v)
    get_settings.cache_clear()
    try:
        yield
    finally:
        mp.undo()
        get_settings.cache_clear()


def evaluate(client: TestClient, quote: str = SARAH) -> dict[str, Any]:
    r = client.post(f"/renewal-quotes/{quote}/evaluations", headers=OFFICER)
    assert r.status_code == 200, r.text
    return dict(r.json())


def narratives(session: Session) -> list[Any]:
    return session.execute(text("SELECT n.*, r.selection FROM sra.narrative n JOIN sra.recommendation r "
                                "USING (recommendation_id) ORDER BY r.rank, n.audience, n.version")).all()


def calls(session: Session) -> int:
    return int(session.execute(text("SELECT count(*) FROM sra.llm_call")).scalar_one())


# ----------------------------------------------------------------------------- happy path
def test_cards_carry_validated_llm_narrative_with_tokens_reinserted(client: TestClient, session: Session) -> None:
    with model() as fake:
        body = evaluate(client)
    primary = next(c for c in body["recommendations"] if c["selection"] == "PRIMARY")
    n = primary["narrative"]
    assert n["origin"] == "LLM" and n["aiGenerated"] is True and n["standardWording"] is False
    assert n["draftWording"] is True                      # DRAFT statements, pending Compliance
    assert n["whyRecommended"].startswith("Sarah's")      # {{FIRST_NAME}} re-inserted server side
    assert len(n["keyBenefits"]) == 3 and n["letterRationale"]
    stored = narratives(session)
    assert len(stored) == 4                               # 2 cards x (OFFICER, CUSTOMER_LETTER), en only
    assert all("{{FIRST_NAME}}" in json.dumps(s.content) for s in stored if s.audience == "OFFICER")
    assert "Sarah" not in json.dumps([s.content for s in stored])   # personal data never stored in narratives
    assert {s.origin for s in stored} == {"LLM"} and {s.validation_status for s in stored} == {"PASSED"}
    assert len(fake.calls) == 4 and calls(session) == 4


def test_model_input_is_only_the_fact_pack(client: TestClient, session: Session) -> None:
    with model() as fake:
        evaluate(client)
    prompt = json.dumps(fake.calls)
    for personal in ("Sarah", "Jenkins", "Park Lane", "20095", "Hamburg", "CUST-38192", "POL-CAR-771204",
                     "QUO-2026-91402", "HH-SJ"):
        assert personal not in prompt
    row = session.execute(text("SELECT * FROM sra.llm_call LIMIT 1")).mappings().one()
    assert (row["deployment_name"], row["data_class"]) == ("gpt-4.1", "SYNTHETIC")
    assert len(row["request_sha256"]) == 64               # only a hash of the request is kept


def test_every_validator_result_is_recorded(client: TestClient, session: Session) -> None:
    with model():
        evaluate(client)
    rows = session.execute(text("SELECT validator, bool_and(passed) FROM sra.narrative_validation "
                                "GROUP BY validator ORDER BY validator")).all()
    assert [r[0] for r in rows] == ["APPROVED_CLAIMS", "LENGTH_READABILITY", "NUMBER_PROVENANCE", "PII_LEAK",
                                    "PROHIBITED_PHRASES", "PROTECTED_ATTRIBUTES", "SCHEMA"]
    assert all(r[1] for r in rows)


# ----------------------------------------------------------------------------- retry and fallback
def test_invalid_answer_is_retried_once_with_findings(client: TestClient, session: Session) -> None:
    bad = lambda p: json.dumps({**json.loads(valid_reply(p)), "how_it_helps": "It is guaranteed and exclusive."})  # noqa: E731
    with model([bad]) as fake:
        evaluate(client)
    assert "PROHIBITED_PHRASES" in fake.calls[1][-1]["content"]   # retry carries the findings
    first = narratives(session)[0]
    assert first.origin == "LLM" and first.validation_status == "PASSED"
    assert calls(session) == 5                                    # 4 narratives + 1 retry


def test_twice_invalid_falls_back_to_standard_wording(client: TestClient, session: Session) -> None:
    leak = lambda p: json.dumps({**json.loads(valid_reply(p)), "why_recommended": "Sarah Jenkins qualifies."})  # noqa: E731
    with model([leak, leak]):
        body = evaluate(client)
    primary = next(c for c in body["recommendations"] if c["selection"] == "PRIMARY")["narrative"]
    assert primary["origin"] == "TEMPLATE_FALLBACK" and primary["standardWording"] is True
    assert "Jenkins" not in json.dumps(body)
    events = session.execute(text("SELECT payload ->> 'reason' FROM audit.audit_event "
                                  "WHERE event_type = 'NARRATIVE_GENERATED' ORDER BY event_seq")).scalars().all()
    assert events[0] == "validation failed twice"


def test_model_failure_falls_back_and_is_logged(client: TestClient, session: Session) -> None:
    with model([TimeoutError("model down")]):
        body = evaluate(client)
    assert body["recommendations"][0]["narrative"]["origin"] == "TEMPLATE_FALLBACK"
    assert session.execute(text("SELECT finish_reason FROM sra.llm_call ORDER BY created_at LIMIT 1")
                           ).scalar_one() == "ERROR:TimeoutError"


def test_pseudonymised_data_is_never_sent_to_a_global_deployment(client: TestClient, session: Session) -> None:
    with env(SRA_SOURCE_DATA_CLASS="PSEUDONYMISED", SRA_ALLOW_DRAFT_STATEMENTS="false"), model() as fake:
        body = evaluate(client)
    assert fake.calls == [] and calls(session) == 0               # router refused before any call
    n = body["recommendations"][0]["narrative"]
    assert n["origin"] == "TEMPLATE_FALLBACK" and n["draftWording"] is False and n["keyBenefits"] == []
    reason = session.execute(text("SELECT payload ->> 'reason' FROM audit.audit_event "
                                  "WHERE event_type = 'NARRATIVE_GENERATED' LIMIT 1")).scalar_one()
    assert "PSEUDONYMISED data is not allowed for gpt-4.1" in reason


def test_draft_content_is_not_used_unless_allowed(client: TestClient) -> None:
    with env(SRA_ALLOW_DRAFT_STATEMENTS="false"), model() as fake:
        body = evaluate(client)
    assert fake.calls == []        # no APPROVED prompt exists yet -> no model call, standard wording
    n = body["recommendations"][0]["narrative"]
    assert n["origin"] == "TEMPLATE_FALLBACK" and n["keyBenefits"] == [] and n["draftWording"] is False


# ----------------------------------------------------------------------------- cache
def test_unchanged_fact_pack_reuses_the_narrative(client: TestClient, session: Session) -> None:
    with model() as fake:
        first = evaluate(client)
        # Only the alternative's price changes -> new decision run; the primary's fact pack is identical.
        session.execute(text(f"UPDATE src.rating_quote SET annual_gross = 99.00 WHERE quote_id = '{SARAH}' "
                             "AND product_code = 'HOME_CONTENTS'"))
        second = evaluate(client)
    assert second["decision"]["decisionRunId"] != first["decision"]["decisionRunId"]
    assert len(fake.calls) == 6    # 4 + 2 for the changed alternative; the primary came from the cache
    primary = next(c for c in second["recommendations"] if c["selection"] == "PRIMARY")["narrative"]
    assert primary["origin"] == "LLM"
    reasons = session.execute(text("SELECT payload ->> 'reason' FROM audit.audit_event "
                                   "WHERE event_type = 'NARRATIVE_GENERATED'")).scalars().all()
    assert sum(r.startswith("cache hit") for r in reasons) == 2


# ----------------------------------------------------------------------------- officer edits
def _primary_and_etag(client: TestClient) -> tuple[dict[str, Any], str]:
    body = evaluate(client)
    card = next(c for c in body["recommendations"] if c["selection"] == "PRIMARY")
    etag = client.get(f"/cases/{body['caseId']}", headers=OFFICER).headers["ETag"]
    return card, etag


def test_officer_edit_is_validated_and_versioned(client: TestClient, session: Session) -> None:
    with model():
        card, etag = _primary_and_etag(client)
    rec = card["recommendationId"]
    ok = client.put(f"/recommendations/{rec}/narrative", headers=OFFICER | {"If-Match": etag},
                    json={"whyRecommended": "{{FIRST_NAME}} rents an apartment and has no liability cover."})
    assert ok.status_code == 200, ok.text
    assert ok.json()["origin"] == "OFFICER_EDIT" and ok.json()["version"] == 2
    assert ok.json()["card"]["narrative"]["whyRecommended"] == "Sarah rents an apartment and has no liability cover."
    stored = session.execute(text("SELECT edited_by, content ->> 'why_recommended' FROM sra.narrative "
                                  "WHERE origin = 'OFFICER_EDIT'")).one()
    assert stored[0] == "officer.anna" and "{{FIRST_NAME}}" in stored[1]


@pytest.mark.parametrize(("change", "validator"), [
    ({"whyRecommended": "Sarah Jenkins has no liability cover."}, "PII_LEAK"),
    ({"howItHelps": "It pays out 10000 EUR per claim."}, "NUMBER_PROVENANCE"),
    ({"howItHelps": "This cover is guaranteed."}, "PROHIBITED_PHRASES"),
    ({"keyBenefitKeys": ["PL.INVENTED"]}, "APPROVED_CLAIMS"),
])
def test_officer_edit_rejected_by_validators(client: TestClient, change: dict[str, Any], validator: str) -> None:
    with model():
        card, etag = _primary_and_etag(client)
    r = client.put(f"/recommendations/{card['recommendationId']}/narrative", headers=OFFICER | {"If-Match": etag},
                   json=change)
    assert r.status_code == 422, r.text
    assert validator in {f["validator"] for f in r.json()["findings"]}


def test_officer_edit_requires_if_match(client: TestClient) -> None:
    with model():
        card, _ = _primary_and_etag(client)
    r = client.put(f"/recommendations/{card['recommendationId']}/narrative", headers=OFFICER,
                   json={"whyRecommended": "{{FIRST_NAME}} has no liability cover."})
    assert r.status_code == 428


def test_action_records_the_narrative_the_officer_saw(client: TestClient, session: Session) -> None:
    with model():
        card, etag = _primary_and_etag(client)
    r = client.post(f"/recommendations/{card['recommendationId']}/actions", headers=OFFICER | {"If-Match": etag},
                    json={"action": "INCLUDE", "narrativeIdShown": card["narrative"]["narrativeId"]})
    assert r.status_code == 201, r.text
    shown = session.execute(text("SELECT narrative_id_shown::text FROM sra.officer_action")).scalar_one()
    assert shown == card["narrative"]["narrativeId"]
    assert verify_chain(session).valid
