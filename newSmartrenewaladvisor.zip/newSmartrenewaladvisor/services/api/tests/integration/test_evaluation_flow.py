"""End-to-end Phase 2: queue -> Generate Possible Opportunities -> cards / case / trace, on the real database."""
from __future__ import annotations

import json
from typing import Any

import pytest
import sra_pricing
import sra_rules
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session
from sra_api.adapters.ports import collect_source
from sra_api.adapters.src_mock import SraReference, SrcMockClaims, SrcMockCrm, SrcMockPas
from sra_api.audit.ledger import verify_chain
from sra_api.factbuilder.builder import build_context
from support.persona_compare import differences
from support.seed_source import GOLDEN_AS_OF, PERSONAS, QUOTE_TO_PERSONA, REPO

from .conftest import AUDITOR, OFFICER

CATALOG: dict[str, Any] = json.loads((REPO / "rules/rule_catalog.v1.0.json").read_text(encoding="utf-8"))
PARAMS = {k: v["value"] for k, v in CATALOG["parameters"].items()}
QUOTES = sorted(QUOTE_TO_PERSONA)
IDS = [QUOTE_TO_PERSONA[q] for q in QUOTES]


def _evaluate(client: TestClient, quote_id: str, headers: dict[str, str] = OFFICER) -> dict[str, Any]:
    r = client.post(f"/renewal-quotes/{quote_id}/evaluations", headers=headers)
    assert r.status_code == 200, r.text
    body: dict[str, Any] = r.json()
    return body


def _expected(quote_id: str) -> sra_rules.DecisionResult:
    return sra_rules.evaluate(PERSONAS[QUOTE_TO_PERSONA[quote_id]], CATALOG, GOLDEN_AS_OF,
                              pricer=sra_pricing.price_candidate)


# ----------------------------------------------------------------------------- adapters + fact builder on SQL
@pytest.mark.parametrize("quote_id", QUOTES, ids=IDS)
def test_sql_adapter_context_equals_persona(session: Session, quote_id: str) -> None:
    pas, crm, claims, ref = SrcMockPas(session), SrcMockCrm(session), SrcMockClaims(session), SraReference(session)
    snap = collect_source(quote_id, pas, crm, claims, ref, ref)
    assert snap is not None
    built = build_context(snap, PARAMS, GOLDEN_AS_OF).context
    assert differences(built, PERSONAS[QUOTE_TO_PERSONA[quote_id]]) == []


# ----------------------------------------------------------------------------- evaluation per persona
@pytest.mark.parametrize("quote_id", QUOTES, ids=IDS)
def test_evaluation_matches_engine_on_golden_persona(client: TestClient, quote_id: str) -> None:
    body = _evaluate(client, quote_id)
    exp = _expected(quote_id)
    assert body["caseCreated"] is True
    assert body["decision"]["status"] == exp.status
    assert body["decision"]["suppressionReasons"] == exp.suppression_reasons
    assert body["decision"]["rulesetVersion"] == CATALOG["version"]
    cards = {c["selection"]: c for c in body["recommendations"]}
    assert (cards.get("PRIMARY") or {}).get("ruleId") == exp.primary
    assert (cards.get("ALTERNATIVE") or {}).get("ruleId") == exp.alternative
    for cand in exp.candidates:
        if cand.selection in ("PRIMARY", "ALTERNATIVE"):
            p = cards[cand.selection]["pricing"]
            assert p["netAnnualTotal"] == cand.pricing["net_annual_total"]
            assert p["bundleSavingAnnual"] == cand.pricing["bundle_saving_annual"]
            assert p["bundleDiscountPct"] == cand.pricing["bundle_discount_pct"]
            assert p["incrementalMonthlyEquivalent"] == cand.pricing["incremental_monthly_equiv"]


def test_sarah_gets_personal_liability_with_itemised_bundle_price(client: TestClient) -> None:
    body = _evaluate(client, "QUO-2026-91402")
    primary = next(c for c in body["recommendations"] if c["selection"] == "PRIMARY")
    assert primary["ruleId"] == "CS-LIA-01"
    assert primary["opportunityType"] == "CROSS_SELL"
    assert primary["pricing"] == {"expiringPremium": "490.00", "baseRenewalPremium": "515.00",
                                  "incrementalAnnual": "57.00", "incrementalMonthlyEquivalent": "4.75",
                                  "companionStandaloneAnnual": "57.00", "bundleDiscountPct": "5",
                                  "bundleSavingAnnual": "28.60", "netAnnualTotal": "543.40",
                                  "presentation": "SEPARATE_POLICY_ITEMISED"}
    assert primary["recommendationRef"].startswith("REC-2026-")
    assert primary["status"] == "PENDING"
    assert primary["evidence"], "evidence panel needs the clause values"
    case = client.get(f"/cases/{body['caseId']}", headers=OFFICER).json()
    assert case["state"] == "READY_FOR_REVIEW"
    assert case["opportunitySignal"] in ("CROSS_SELL", "MULTI_CROSS_SELL", "UPSELL_AND_CROSS_SELL")


def test_mark_is_suppressed_with_all_gatekeepers_audited(client: TestClient) -> None:
    body = _evaluate(client, "QUO-2026-44019")
    assert body["decision"]["status"] == "SUPPRESSED"
    assert body["recommendations"] == []
    case = client.get(f"/cases/{body['caseId']}", headers=OFFICER).json()
    assert case["state"] == "SUPPRESSED" and case["opportunitySignal"] == "SUPPRESSED"
    trace = client.get(f"/decision-runs/{body['decision']['decisionRunId']}/trace", headers=AUDITOR).json()
    gk = {e["ruleId"]: e["outcome"] for e in trace["evaluations"] if e["stage"] == "GATEKEEPER"}
    assert len(gk) == 6, "every active gatekeeper is evaluated, even after the first hit"
    assert {r for r, o in gk.items() if o == "SUPPRESS"} >= {"GK-03", "GK-04", "GK-05"}


def test_elena_building_blocked_by_data_integrity_gate(client: TestClient) -> None:
    body = _evaluate(client, "QUO-2026-61849")
    trace = client.get(f"/decision-runs/{body['decision']['decisionRunId']}/trace", headers=OFFICER).json()
    building = next(e for e in trace["evaluations"] if e["ruleId"] == "CS-HOM-02")
    assert building["outcome"] == "DATA_INTEGRITY_FAIL"
    assert "customer.dwelling_type=MISSING" in building["detail"]
    case = client.get(f"/cases/{body['caseId']}", headers=OFFICER).json()
    assert {"factPath": "customer.dwelling_type", "quality": "MISSING", "sourceSystem": "CRM"} \
        in case["dataQualityFlags"]


# ----------------------------------------------------------------------------- idempotency & supersede
def test_repeated_clicks_reuse_case_and_run(client: TestClient, session: Session) -> None:
    first = _evaluate(client, "QUO-2026-88129")
    events_after_first = session.execute(text("SELECT count(*) FROM audit.audit_event")).scalar()
    second = _evaluate(client, "QUO-2026-88129")
    assert second["caseId"] == first["caseId"]
    assert second["caseCreated"] is False
    assert second["decision"]["decisionRunId"] == first["decision"]["decisionRunId"]
    assert second["decision"]["reusedPreviousRun"] is True
    cases = session.execute(text("SELECT count(*) FROM sra.renewal_case WHERE quote_id = 'QUO-2026-88129'")).scalar()
    assert cases == 1
    assert session.execute(text("SELECT count(*) FROM sra.decision_run")).scalar() == 1
    assert session.execute(text("SELECT count(*) FROM audit.audit_event")).scalar() == events_after_first


def test_changed_source_data_creates_new_run_and_supersedes(client: TestClient, session: Session) -> None:
    first = _evaluate(client, "QUO-2026-91402")
    old = {c["ruleId"]: c["recommendationId"] for c in first["recommendations"]}
    # PAS re-rates Personal Liability for Sarah
    session.execute(text("UPDATE src.rating_quote SET annual_gross = 60.00 "
                         "WHERE quote_id = 'QUO-2026-91402' AND product_code = 'LIAB_PRIVATE'"))
    second = _evaluate(client, "QUO-2026-91402")
    assert second["decision"]["decisionRunId"] != first["decision"]["decisionRunId"]
    assert second["decision"]["reusedPreviousRun"] is False
    new = {c["ruleId"]: c for c in second["recommendations"]}
    assert new["CS-LIA-01"]["pricing"]["companionStandaloneAnnual"] == "60.00"
    rows = session.execute(text("SELECT recommendation_id::text, status, superseded_by::text "
                                "FROM sra.recommendation WHERE recommendation_id::text = ANY(:ids)"),
                           {"ids": list(old.values())}).all()
    assert {r.status for r in rows} == {"SUPERSEDED"}
    by_id = {r.recommendation_id: r.superseded_by for r in rows}
    assert by_id[old["CS-LIA-01"]] == new["CS-LIA-01"]["recommendationId"]
    assert session.execute(text("SELECT count(*) FROM sra.decision_run")).scalar() == 2


def test_dispatched_case_rejects_evaluation(client: TestClient, session: Session) -> None:
    body = _evaluate(client, "QUO-2026-72810")
    session.execute(text("UPDATE sra.renewal_case SET state = 'DISPATCHED' WHERE case_id = :c"),
                    {"c": body["caseId"]})
    r = client.post("/renewal-quotes/QUO-2026-72810/evaluations", headers=OFFICER)
    assert r.status_code == 409
    assert r.headers["content-type"].startswith("application/problem+json")
    assert r.json()["code"] == "WINDOW_CLOSED"


def test_unknown_quote_is_404(client: TestClient) -> None:
    r = client.post("/renewal-quotes/QUO-2026-00000/evaluations", headers=OFFICER)
    assert r.status_code == 404 and r.json()["code"] == "NOT_FOUND"


# ----------------------------------------------------------------------------- invariants on the database
def test_immutable_tables_reject_update(client: TestClient, session: Session) -> None:
    _evaluate(client, "QUO-2026-91402")
    column = {"sra.decision_run": "status", "sra.rule_evaluation": "detail",
              "sra.policy_snapshot": "request_id", "audit.audit_event": "hash"}
    for table, col in column.items():
        with pytest.raises(DBAPIError, match="append-only"), session.begin_nested():
            session.execute(text(f"UPDATE {table} SET {col} = {col}"))
        with pytest.raises(DBAPIError, match="append-only"), session.begin_nested():
            session.execute(text(f"DELETE FROM {table}"))


def test_audit_chain_is_valid_and_covers_every_change(client: TestClient, session: Session) -> None:
    for q in QUOTES:
        _evaluate(client, q)
    result = verify_chain(session)
    assert result.valid, result
    types = [r[0] for r in session.execute(text("SELECT event_type FROM audit.audit_event ORDER BY event_seq"))]
    assert types.count("CASE_CREATED") == 5
    assert types.count("EVALUATED") == 5
    assert types.count("STATE_CHANGED") == 5


def test_decision_is_reproducible_from_stored_snapshot(client: TestClient, session: Session) -> None:
    body = _evaluate(client, "QUO-2026-61849")
    ctx, out_sha, as_of = session.execute(text(
        "SELECT ps.decision_context, dr.output_sha256, dr.as_of FROM sra.decision_run dr "
        "JOIN sra.policy_snapshot ps USING (snapshot_id) WHERE dr.decision_run_id = :r"),
        {"r": body["decision"]["decisionRunId"]}).one()
    from sra_api.decisioning.service import output_sha256
    replay = sra_rules.evaluate(ctx, CATALOG, as_of, pricer=sra_pricing.price_candidate)
    assert output_sha256(replay) == out_sha  # CTL-12 replay


# ----------------------------------------------------------------------------- queue & auth
def test_queue_and_kpis_follow_case_state(client: TestClient) -> None:
    before = client.get("/renewal-quotes", headers=OFFICER).json()
    assert before["total"] == 5 and all(not i["evaluated"] for i in before["items"])
    assert all(isinstance(i["renewalPremium"], str) for i in before["items"])
    _evaluate(client, "QUO-2026-44019")
    kpis = client.get("/renewal-quotes/kpis", headers=OFFICER).json()
    assert kpis == {"total": 5, "pendingReview": 4, "conductHold": 1, "dispatched": 0}
    held = client.get("/renewal-quotes?status=CONDUCT_HOLD", headers=OFFICER).json()
    assert [i["quoteId"] for i in held["items"]] == ["QUO-2026-44019"]
    assert client.get("/renewal-quotes?q=jenkins", headers=OFFICER).json()["total"] == 1


def test_auth_is_required_and_roles_enforced(client: TestClient) -> None:
    assert client.get("/renewal-quotes").status_code == 401
    assert client.get("/renewal-quotes", headers={"X-Dev-User": "nobody"}).status_code == 401
    assert client.post("/renewal-quotes/QUO-2026-91402/evaluations", headers=AUDITOR).status_code == 403
    assert client.get("/renewal-quotes", headers=AUDITOR).status_code == 200
