"""Phase 5 on the real database: compose -> approve -> dispatch, and every human-in-the-loop guard (invariant 10)."""
from __future__ import annotations

import hashlib
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import date
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.orm import Session
from sra_api.audit.ledger import verify_chain
from sra_api.settings import get_settings

from .conftest import OFFICER

SARAH, MARK = "QUO-2026-91402", "QUO-2026-44019"


@contextmanager
def business_day(d: date) -> Iterator[None]:
    mp = pytest.MonkeyPatch()
    mp.setenv("SRA_AS_OF", d.isoformat())
    get_settings.cache_clear()
    try:
        yield
    finally:
        mp.undo()
        get_settings.cache_clear()


class Console:
    def __init__(self, client: TestClient) -> None:
        self.c = client
        self.etag = ""
        self.case_id = ""

    def _h(self) -> dict[str, str]:
        return OFFICER | {"If-Match": self.etag}

    def _track(self, r: Any) -> Any:
        if "ETag" in r.headers:
            self.etag = r.headers["ETag"]
        return r

    def evaluate(self, quote: str = SARAH) -> dict[str, Any]:
        body = self.c.post(f"/renewal-quotes/{quote}/evaluations", headers=OFFICER).json()
        self.case_id = body["caseId"]
        self._track(self.c.get(f"/cases/{self.case_id}", headers=OFFICER))
        return dict(body)

    def cards(self) -> dict[str, dict[str, Any]]:
        return {c["selection"]: c for c in self.c.get(f"/cases/{self.case_id}/recommendations", headers=OFFICER).json()}

    def act(self, selection: str, body: dict[str, Any]) -> Any:
        return self._track(self.c.post(f"/recommendations/{self.cards()[selection]['recommendationId']}/actions",
                                       json=body, headers=self._h()))

    def compose(self) -> Any:
        return self._track(self.c.post(f"/cases/{self.case_id}/letter-draft", headers=self._h()))

    def approve(self) -> Any:
        return self._track(self.c.post(f"/cases/{self.case_id}/letter-draft/approve", headers=self._h()))

    def dispatch(self) -> Any:
        return self._track(self.c.post(f"/cases/{self.case_id}/dispatch", headers=self._h()))

    def letter(self) -> dict[str, Any]:
        return dict(self.c.get(f"/cases/{self.case_id}/letter-draft", headers=OFFICER).json())

    def state(self) -> str:
        return str(self.c.get(f"/cases/{self.case_id}", headers=OFFICER).json()["state"])


@pytest.fixture
def ui(client: TestClient) -> Console:
    return Console(client)


def _decided_sarah(ui: Console) -> None:
    ui.evaluate()
    assert ui.act("PRIMARY", {"action": "INCLUDE"}).status_code == 201
    assert ui.act("ALTERNATIVE", {"action": "SKIP", "skipReasonCode": "CUSTOMER_BUDGET"}).status_code == 201
    assert ui.state() == "DECIDED"


# ----------------------------------------------------------------------------- happy path
def test_advisory_letter_end_to_end(ui: Console, session: Session) -> None:
    _decided_sarah(ui)
    composed = ui.compose()
    assert composed.status_code == 201, composed.text
    assert composed.json()["letterType"] == "ADVISORY" and composed.json()["caseState"] == "LETTER_DRAFTED"
    letter = ui.letter()
    assert [s["sectionType"] for s in letter["sections"]] == [
        "CORE_RENEWAL_TERMS", "PREMIUM_CHANGE_NOTICE", "ADVISORY_BLOCK", "BUNDLE_SAVINGS", "OPT_IN_INSTRUCTION",
        "OBJECTION_NOTICE", "ATTACHMENTS"]
    block = letter["sections"][2]
    assert block["recommendationId"] == ui.cards()["PRIMARY"]["recommendationId"]   # only the INCLUDED one
    assert dict(block["content"]["table"])["Annual total for both policies"] == "543.40"
    assert letter["sections"][0]["content"]["salutation"] == "Dear Sarah Jenkins,"

    pdf = ui.c.get(f"/cases/{ui.case_id}/letter-draft/pdf", headers=OFFICER)
    assert pdf.status_code == 200 and pdf.content.startswith(b"%PDF")
    assert hashlib.sha256(pdf.content).hexdigest() == letter["contentSha256"]

    approved = ui.approve()
    assert approved.status_code == 200, approved.text
    assert approved.json()["status"] == "APPROVED" and approved.json()["caseState"] == "LETTER_APPROVED"
    sent = ui.dispatch()
    assert sent.status_code == 202, sent.text
    assert sent.json()["caseState"] == "DISPATCHED" and sent.json()["omsReference"].startswith("OMS-SIM-")
    row = session.execute(text("SELECT channel, dispatched_by FROM sra.letter_dispatch")).one()
    assert (row.channel, row.dispatched_by) == ("PORTAL", "officer.anna")   # Sarah prefers the portal

    again = ui.c.post(f"/renewal-quotes/{SARAH}/evaluations", headers=OFFICER)
    assert again.status_code == 409 and again.json()["code"] == "WINDOW_CLOSED"   # dispatch closes the window
    assert ui.c.get("/renewal-quotes/kpis", headers=OFFICER).json()["dispatched"] == 1
    assert verify_chain(session).valid


def test_suppressed_case_gets_standard_notice_only(ui: Console) -> None:
    ui.evaluate(MARK)
    r = ui.compose()
    assert r.status_code == 201 and r.json()["letterType"] == "STANDARD"
    assert [s["sectionType"] for s in ui.letter()["sections"]] == ["CORE_RENEWAL_TERMS", "PREMIUM_CHANGE_NOTICE",
                                                                    "ATTACHMENTS"]
    assert ui.approve().status_code == 200 and ui.dispatch().status_code == 202


def test_all_skipped_gives_standard_letter(ui: Console) -> None:
    ui.evaluate()
    ui.act("PRIMARY", {"action": "SKIP", "skipReasonCode": "CUSTOMER_BUDGET"})
    ui.act("ALTERNATIVE", {"action": "SKIP", "skipReasonCode": "COVERED_EXTERNALLY"})
    assert ui.compose().json()["letterType"] == "STANDARD"


def test_compose_is_idempotent(ui: Console, session: Session) -> None:
    _decided_sarah(ui)
    first = ui.compose().json()
    second = ui.compose().json()
    assert second["reusedDraft"] is True and second["letterId"] == first["letterId"]
    assert session.execute(text("SELECT count(*) FROM sra.letter_draft")).scalar() == 1


# ----------------------------------------------------------------------------- guards
def test_letter_needs_every_recommendation_decided(ui: Console) -> None:
    ui.evaluate()
    ui.act("PRIMARY", {"action": "INCLUDE"})                   # alternative still PENDING
    r = ui.compose()
    assert r.status_code == 409 and r.json()["code"] == "LETTER_NOT_COMPOSABLE"
    assert "SLA cut-off 2026-10-20" in r.json()["detail"]


def test_sla_cutoff_composes_without_open_items(ui: Console, session: Session) -> None:
    ui.evaluate()
    ui.act("PRIMARY", {"action": "INCLUDE"})
    ui.act("ALTERNATIVE", {"action": "DEFER", "deferReasonCode": "CUSTOMER_CONTACT_PENDING",
                           "followUpAt": "2026-10-15"})
    assert ui.state() == "DECIDED"
    with business_day(date(2026, 10, 20)):
        r = ui.compose()
    assert r.status_code == 201, r.text
    advisory = [s for s in ui.letter()["sections"] if s["sectionType"] == "ADVISORY_BLOCK"]
    assert len(advisory) == 1                                   # the deferred one is not in the letter
    assert ui.cards()["ALTERNATIVE"]["status"] == "EXPIRED"


def test_sla_cutoff_from_review_expires_pending_items(ui: Console, session: Session) -> None:
    ui.evaluate()
    ui.act("PRIMARY", {"action": "INCLUDE"})                    # IN_REVIEW, alternative PENDING
    with business_day(date(2026, 10, 20)):
        r = ui.compose()
    assert r.status_code == 201 and r.json()["caseState"] == "LETTER_DRAFTED"
    assert ui.cards()["ALTERNATIVE"]["status"] == "EXPIRED"
    assert session.execute(text("SELECT count(*) FROM audit.audit_event WHERE event_type = 'EXPIRED_AT_SLA_CUTOFF'")
                           ).scalar() == 1


def test_dispatch_requires_approval(ui: Console) -> None:
    _decided_sarah(ui)
    ui.compose()
    r = ui.dispatch()
    assert r.status_code == 409 and r.json()["code"] == "NOT_APPROVED"


def test_approve_requires_a_draft(ui: Console) -> None:
    _decided_sarah(ui)
    r = ui.approve()
    assert r.status_code == 409 and r.json()["code"] == "NOT_DRAFTED"


def test_edit_after_drafting_makes_the_draft_stale(ui: Console) -> None:
    _decided_sarah(ui)
    ui.compose()
    rec = ui.cards()["PRIMARY"]["recommendationId"]
    edit = ui._track(ui.c.put(f"/recommendations/{rec}/narrative", headers=ui._h(), json={
        "audience": "CUSTOMER_LETTER",
        "letterRationale": "{{FIRST_NAME}}, this optional policy could suit you. It can be taken out separately."}))
    assert edit.status_code == 200, edit.text
    stale = ui.approve()
    assert stale.status_code == 409 and stale.json()["code"] == "STALE_DRAFT"
    assert ui.compose().status_code == 201
    assert "Sarah, this optional policy" in str(ui.letter()["sections"][2]["content"]["rationale"])
    assert ui.approve().status_code == 200


def test_undo_after_drafting_cancels_the_draft(ui: Console, session: Session) -> None:
    _decided_sarah(ui)
    ui.compose()
    card = ui.cards()["PRIMARY"]
    u = ui._track(ui.c.post(f"/recommendations/{card['recommendationId']}/actions/"
                            f"{card['currentAction']['actionId']}/reversal", headers=ui._h()))
    assert u.status_code == 201 and u.json()["caseState"] == "IN_REVIEW"
    assert session.execute(text("SELECT status FROM sra.letter_draft")).scalar_one() == "CANCELLED"
    assert ui.c.get(f"/cases/{ui.case_id}/letter-draft", headers=OFFICER).status_code == 404


def test_tampered_pdf_is_never_dispatched(ui: Console) -> None:
    _decided_sarah(ui)
    ui.compose()
    ui.approve()
    pdf = Path(get_settings().sra_letter_storage_dir) / ui.case_id / f"letter-v{ui.letter()['version']}.pdf"
    pdf.write_bytes(pdf.read_bytes() + b"%tampered")      # someone edits the frozen file
    r = ui.dispatch()
    assert r.status_code == 409 and r.json()["code"] == "LETTER_TAMPERED"
    assert ui.letter()["status"] == "APPROVED"            # nothing was sent


def test_approved_letter_freezes_the_case(ui: Console) -> None:
    _decided_sarah(ui)
    ui.compose()
    ui.approve()
    rec = ui.cards()["PRIMARY"]
    undo = ui.c.post(f"/recommendations/{rec['recommendationId']}/actions/{rec['currentAction']['actionId']}/reversal",
                     headers=ui._h())
    assert undo.status_code == 409
    edit = ui.c.put(f"/recommendations/{rec['recommendationId']}/narrative", headers=ui._h(),
                    json={"whyRecommended": "{{FIRST_NAME}} changed."})
    assert edit.status_code == 409
    assert ui.c.post(f"/renewal-quotes/{SARAH}/evaluations", headers=OFFICER).status_code == 409


def test_not_triggered_or_unknown_case(ui: Console, client: TestClient) -> None:
    r = client.post("/cases/00000000-0000-0000-0000-000000000000/letter-draft", headers=OFFICER | {"If-Match": "1"})
    assert r.status_code == 404
