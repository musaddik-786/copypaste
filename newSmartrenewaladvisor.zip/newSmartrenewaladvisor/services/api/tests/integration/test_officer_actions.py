"""Phase 3 on the real database: Include / Skip / Defer, undo, optimistic locking, cooldown ledger, expiry.

Sarah (QUO-2026-91402) has a PRIMARY and an ALTERNATIVE card; her letter is due Wed 2026-10-21, so the SLA
cut-off is Tue 2026-10-20. Business date is pinned to 2026-10-13 unless a test moves it.
"""
from __future__ import annotations

import json
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import date
from typing import Any

import pytest
import sra_pricing
import sra_rules
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.orm import Session
from sra_api.adapters.ports import collect_source
from sra_api.adapters.src_mock import SraReference, SrcMockClaims, SrcMockCrm, SrcMockPas
from sra_api.audit.ledger import verify_chain
from sra_api.cases.action_rules import add_months, cooldown_months
from sra_api.factbuilder.builder import build_context
from sra_api.settings import get_settings
from support.seed_source import GOLDEN_AS_OF, REPO

from .conftest import AUDITOR, OFFICER

SARAH = "QUO-2026-91402"
BEN = {"X-Dev-User": "officer.ben"}
CATALOG: dict[str, Any] = json.loads((REPO / "rules/rule_catalog.v1.0.json").read_text(encoding="utf-8"))


@contextmanager
def business_day(d: date) -> Iterator[None]:
    mp = pytest.MonkeyPatch()
    mp.setenv("SRA_AS_OF", d.isoformat())
    get_settings.cache_clear()
    try:
        yield
    finally:
        mp.undo()
        get_settings.cache_clear()


class Officer:
    """Small console stand-in: keeps the case rowVersion like the real UI would (from ETag)."""

    def __init__(self, client: TestClient, headers: dict[str, str] = OFFICER) -> None:
        self.c, self.h = client, headers

    def evaluate(self, quote_id: str = SARAH) -> dict[str, Any]:
        r = self.c.post(f"/renewal-quotes/{quote_id}/evaluations", headers=self.h)
        assert r.status_code == 200, r.text
        return dict(r.json())

    def case(self, case_id: str) -> tuple[dict[str, Any], str]:
        r = self.c.get(f"/cases/{case_id}", headers=self.h)
        assert r.status_code == 200, r.text
        return r.json(), r.headers["ETag"]

    def cards(self, case_id: str) -> dict[str, dict[str, Any]]:
        return {c["selection"]: c for c in self.c.get(f"/cases/{case_id}/recommendations", headers=self.h).json()}

    def act(self, rec_id: str, body: dict[str, Any], etag: str | None) -> Any:
        h = dict(self.h) | ({"If-Match": etag} if etag is not None else {})
        return self.c.post(f"/recommendations/{rec_id}/actions", json=body, headers=h)

    def undo(self, rec_id: str, action_id: str, etag: str) -> Any:
        return self.c.post(f"/recommendations/{rec_id}/actions/{action_id}/reversal",
                           headers=dict(self.h) | {"If-Match": etag})


@pytest.fixture
def officer(client: TestClient) -> Officer:
    return Officer(client)


@pytest.fixture
def sarah(officer: Officer) -> dict[str, Any]:
    body = officer.evaluate()
    cards = officer.cards(body["caseId"])
    assert set(cards) == {"PRIMARY", "ALTERNATIVE"}
    _, etag = officer.case(body["caseId"])
    return {"case_id": body["caseId"], "primary": cards["PRIMARY"], "alternative": cards["ALTERNATIVE"],
            "etag": etag}


def _events(session: Session, case_id: str) -> list[str]:
    return [r[0] for r in session.execute(text(
        "SELECT event_type FROM audit.audit_event WHERE case_id = :c ORDER BY event_seq"), {"c": case_id})]


# ----------------------------------------------------------------------------- happy path
def test_include_both_moves_case_to_decided(officer: Officer, sarah: dict[str, Any], session: Session) -> None:
    r1 = officer.act(sarah["primary"]["recommendationId"], {"action": "INCLUDE"}, sarah["etag"])
    assert r1.status_code == 201, r1.text
    assert r1.json()["caseState"] == "IN_REVIEW" and r1.json()["recommendationStatus"] == "INCLUDED"
    assert r1.headers["ETag"] == f'"{r1.json()["rowVersion"]}"'
    r2 = officer.act(sarah["alternative"]["recommendationId"], {"action": "INCLUDE"}, r1.headers["ETag"])
    assert r2.status_code == 201, r2.text
    assert r2.json()["caseState"] == "DECIDED"
    cards = officer.cards(sarah["case_id"])
    assert {c["status"] for c in cards.values()} == {"INCLUDED"}
    assert cards["PRIMARY"]["currentAction"]["action"] == "INCLUDE"
    assert cards["PRIMARY"]["currentAction"]["actedBy"] == "officer.anna"
    ev = _events(session, sarah["case_id"])
    assert ev.count("INCLUDED") == 2
    assert ev[-1] == "STATE_CHANGED"
    assert verify_chain(session).valid


def test_open_case_for_review(officer: Officer, sarah: dict[str, Any], client: TestClient) -> None:
    h = OFFICER | {"If-Match": sarah["etag"]}
    r = client.post(f"/cases/{sarah['case_id']}/review", headers=h)
    assert r.status_code == 200 and r.json()["caseState"] == "IN_REVIEW"
    again = client.post(f"/cases/{sarah['case_id']}/review", headers=OFFICER | {"If-Match": r.headers["ETag"]})
    assert again.status_code == 409 and again.json()["code"] == "ILLEGAL_TRANSITION"


# ----------------------------------------------------------------------------- optimistic locking
def test_if_match_is_required_and_must_be_current(officer: Officer, sarah: dict[str, Any]) -> None:
    rec = sarah["primary"]["recommendationId"]
    missing = officer.act(rec, {"action": "INCLUDE"}, None)
    assert missing.status_code == 428 and missing.json()["code"] == "IF_MATCH_REQUIRED"
    stale = officer.act(rec, {"action": "INCLUDE"}, '"999"')
    assert stale.status_code == 412 and stale.json()["code"] == "STALE_ROW_VERSION"
    assert officer.cards(sarah["case_id"])["PRIMARY"]["status"] == "PENDING"  # nothing was written


def test_second_officer_with_old_version_is_rejected(client: TestClient, sarah: dict[str, Any]) -> None:
    anna, ben = Officer(client), Officer(client, BEN)
    assert anna.act(sarah["primary"]["recommendationId"], {"action": "INCLUDE"}, sarah["etag"]).status_code == 201
    late = ben.act(sarah["alternative"]["recommendationId"], {"action": "INCLUDE"}, sarah["etag"])
    assert late.status_code == 412  # Ben must reload and see Anna's decision first


# ----------------------------------------------------------------------------- skip
@pytest.mark.parametrize(("body", "field"), [
    ({"action": "SKIP"}, "skipReasonCode"),
    ({"action": "SKIP", "skipReasonCode": "NOT_A_REASON"}, "skipReasonCode"),
    ({"action": "SKIP", "skipReasonCode": "INAPPROPRIATE_TIMING"}, "comment"),   # requires a comment
])
def test_skip_needs_a_valid_reason(officer: Officer, sarah: dict[str, Any], body: dict[str, Any],
                                   field: str) -> None:
    r = officer.act(sarah["primary"]["recommendationId"], body, sarah["etag"])
    assert r.status_code == 422, r.text
    assert r.headers["content-type"].startswith("application/problem+json")
    assert field in [f["field"] for f in r.json()["findings"]]


def test_skip_without_cooldown_writes_no_decline(officer: Officer, sarah: dict[str, Any], session: Session) -> None:
    r = officer.act(sarah["primary"]["recommendationId"],
                    {"action": "SKIP", "skipReasonCode": "INAPPROPRIATE_TIMING", "comment": "moving house"},
                    sarah["etag"])
    assert r.status_code == 201 and r.json()["recommendationStatus"] == "SKIPPED"
    assert session.execute(text("SELECT count(*) FROM sra.recommendation_decline")).scalar() == 0


def test_customer_decline_starts_cooldown_from_ruleset(officer: Officer, sarah: dict[str, Any],
                                                        session: Session) -> None:
    rec = sarah["primary"]
    r = officer.act(rec["recommendationId"], {"action": "SKIP", "skipReasonCode": "CUSTOMER_BUDGET"}, sarah["etag"])
    assert r.status_code == 201, r.text
    row = session.execute(text("SELECT customer_id, product_code, declined_at, cooldown_until, source "
                               "FROM sra.recommendation_decline")).one()
    expected_until = add_months(GOLDEN_AS_OF, cooldown_months(rec["productCode"], CATALOG))
    assert (row.customer_id, row.product_code, row.declined_at, row.cooldown_until, row.source) == (
        "CUST-38192", rec["productCode"], GOLDEN_AS_OF, expected_until, "OFFICER_SKIP")
    assert "DECLINE_RECORDED" in _events(session, sarah["case_id"])


def test_repeat_click_after_skip_keeps_officer_decisions(officer: Officer, sarah: dict[str, Any]) -> None:
    r = officer.act(sarah["primary"]["recommendationId"], {"action": "SKIP", "skipReasonCode": "CUSTOMER_BUDGET"},
                    sarah["etag"])
    officer.act(sarah["alternative"]["recommendationId"], {"action": "INCLUDE"}, r.headers["ETag"])
    again = officer.evaluate()
    assert again["decision"]["reusedPreviousRun"] is True
    assert {c["selection"]: c["status"] for c in again["recommendations"]} == {"PRIMARY": "SKIPPED",
                                                                                "ALTERNATIVE": "INCLUDED"}


def test_decline_blocks_the_product_in_a_later_renewal(officer: Officer, sarah: dict[str, Any],
                                                       session: Session) -> None:
    officer.act(sarah["primary"]["recommendationId"], {"action": "SKIP", "skipReasonCode": "CUSTOMER_BUDGET"},
                sarah["etag"])
    # A future case for the same customer reads the full ledger (no exclusion of its own declines).
    pas, crm, claims, ref = SrcMockPas(session), SrcMockCrm(session), SrcMockClaims(session), SraReference(session)
    snap = collect_source(SARAH, pas, crm, claims, ref, ref)
    assert snap is not None
    ctx = build_context(snap, {k: v["value"] for k, v in CATALOG["parameters"].items()}, GOLDEN_AS_OF).context
    res = sra_rules.evaluate(ctx, CATALOG, GOLDEN_AS_OF, pricer=sra_pricing.price_candidate)
    assert res.outcome_of(sarah["primary"]["ruleId"]) == "COOLDOWN_ACTIVE"


# ----------------------------------------------------------------------------- defer
@pytest.mark.parametrize(("follow_up", "reason"), [
    (None, "CUSTOMER_CONTACT_PENDING"),         # date missing
    ("2026-10-13", "CUSTOMER_CONTACT_PENDING"),  # not in the future
    ("2026-10-19", "DATA_VERIFICATION"),         # 6 days > max 5
    ("2026-10-21", "CUSTOMER_CONTACT_PENDING"),  # after SLA cut-off 2026-10-20
])
def test_defer_rules(officer: Officer, sarah: dict[str, Any], follow_up: str | None, reason: str) -> None:
    body: dict[str, Any] = {"action": "DEFER", "deferReasonCode": reason}
    if follow_up:
        body["followUpAt"] = follow_up + "T09:00:00Z"
    r = officer.act(sarah["primary"]["recommendationId"], body, sarah["etag"])
    assert r.status_code == 422, r.text
    assert "followUpAt" in [f["field"] for f in r.json()["findings"]]


def test_valid_defer(officer: Officer, sarah: dict[str, Any]) -> None:
    r = officer.act(sarah["primary"]["recommendationId"],
                    {"action": "DEFER", "deferReasonCode": "CUSTOMER_CONTACT_PENDING",
                     "followUpAt": "2026-10-15T09:00:00Z", "comment": "customer calls back Thursday"}, sarah["etag"])
    assert r.status_code == 201 and r.json()["recommendationStatus"] == "DEFERRED"
    card = officer.cards(sarah["case_id"])["PRIMARY"]
    assert card["currentAction"]["deferReasonCode"] == "CUSTOMER_CONTACT_PENDING"
    assert card["currentAction"]["followUpAt"].startswith("2026-10-15")


def test_deferred_item_expires_at_sla_cutoff(officer: Officer, sarah: dict[str, Any], session: Session) -> None:
    r = officer.act(sarah["primary"]["recommendationId"],
                    {"action": "DEFER", "deferReasonCode": "CUSTOMER_CONTACT_PENDING",
                     "followUpAt": "2026-10-15T09:00:00Z"}, sarah["etag"])
    with business_day(date(2026, 10, 20)):  # SLA cut-off day
        r2 = officer.act(sarah["alternative"]["recommendationId"], {"action": "INCLUDE"}, r.headers["ETag"])
    assert r2.status_code == 201, r2.text
    assert r2.json()["caseState"] == "DECIDED"  # expired counts as resolved (= not part of the letter)
    assert officer.cards(sarah["case_id"])["PRIMARY"]["status"] == "EXPIRED"
    assert "DEFERRAL_EXPIRED" in _events(session, sarah["case_id"])


# ----------------------------------------------------------------------------- undo
def test_undo_reopens_review_and_restores_pending(officer: Officer, sarah: dict[str, Any], session: Session) -> None:
    r1 = officer.act(sarah["primary"]["recommendationId"], {"action": "INCLUDE"}, sarah["etag"])
    r2 = officer.act(sarah["alternative"]["recommendationId"], {"action": "INCLUDE"}, r1.headers["ETag"])
    assert r2.json()["caseState"] == "DECIDED"
    u = officer.undo(sarah["primary"]["recommendationId"], r1.json()["actionId"], r2.headers["ETag"])
    assert u.status_code == 201, u.text
    assert u.json()["caseState"] == "IN_REVIEW" and u.json()["recommendationStatus"] == "PENDING"
    assert officer.cards(sarah["case_id"])["PRIMARY"]["currentAction"] is None
    rows = session.execute(text("SELECT action, reverses_action_id::text FROM sra.officer_action "
                                "WHERE recommendation_id = :r ORDER BY acted_at"),
                           {"r": sarah["primary"]["recommendationId"]}).all()
    assert [r.action for r in rows] == ["INCLUDE", "REVERSAL"]          # nothing updated, only appended
    assert rows[1].reverses_action_id == r1.json()["actionId"]
    again = officer.undo(sarah["primary"]["recommendationId"], r1.json()["actionId"], u.headers["ETag"])
    assert again.status_code == 409 and again.json()["code"] == "ACTION_NOT_REVERSIBLE"
    # after undo the officer can decide again
    redo = officer.act(sarah["primary"]["recommendationId"], {"action": "INCLUDE"}, u.headers["ETag"])
    assert redo.status_code == 201 and redo.json()["caseState"] == "DECIDED"


def test_undo_of_customer_decline_removes_cooldown(officer: Officer, sarah: dict[str, Any], session: Session) -> None:
    r = officer.act(sarah["primary"]["recommendationId"], {"action": "SKIP", "skipReasonCode": "CUSTOMER_BUDGET"},
                    sarah["etag"])
    u = officer.undo(sarah["primary"]["recommendationId"], r.json()["actionId"], r.headers["ETag"])
    assert u.status_code == 201, u.text
    assert session.execute(text("SELECT count(*) FROM sra.recommendation_decline")).scalar() == 0
    assert "DECLINE_REVOKED" in _events(session, sarah["case_id"])


# ----------------------------------------------------------------------------- guards
def test_same_recommendation_cannot_be_actioned_twice(officer: Officer, sarah: dict[str, Any]) -> None:
    r = officer.act(sarah["primary"]["recommendationId"], {"action": "INCLUDE"}, sarah["etag"])
    twice = officer.act(sarah["primary"]["recommendationId"], {"action": "SKIP", "skipReasonCode": "CUSTOMER_BUDGET"},
                        r.headers["ETag"])
    assert twice.status_code == 409 and twice.json()["code"] == "RECOMMENDATION_NOT_ACTIONABLE"


def test_superseded_recommendation_is_not_actionable(officer: Officer, sarah: dict[str, Any],
                                                     session: Session) -> None:
    session.execute(text("UPDATE src.rating_quote SET annual_gross = 60.00 "
                         f"WHERE quote_id = '{SARAH}' AND product_code = 'LIAB_PRIVATE'"))
    officer.evaluate()
    _, etag = officer.case(sarah["case_id"])
    r = officer.act(sarah["primary"]["recommendationId"], {"action": "INCLUDE"}, etag)
    assert r.status_code == 409 and r.json()["recommendationStatus"] == "SUPERSEDED"


def test_suppressed_case_has_nothing_to_review(officer: Officer, client: TestClient) -> None:
    body = officer.evaluate("QUO-2026-44019")
    _, etag = officer.case(body["caseId"])
    r = client.post(f"/cases/{body['caseId']}/review", headers=OFFICER | {"If-Match": etag})
    assert r.status_code == 409


def test_auditor_cannot_act(client: TestClient, sarah: dict[str, Any]) -> None:
    r = Officer(client, AUDITOR).act(sarah["primary"]["recommendationId"], {"action": "INCLUDE"}, sarah["etag"])
    assert r.status_code == 403


def test_unknown_recommendation_and_bad_body(officer: Officer, sarah: dict[str, Any]) -> None:
    assert officer.act(str(uuid.uuid4()), {"action": "INCLUDE"}, sarah["etag"]).status_code == 404
    bad = officer.act(sarah["primary"]["recommendationId"], {"action": "INCLUDE", "extra": 1}, sarah["etag"])
    assert bad.status_code == 422 and bad.json()["code"] == "INVALID_REQUEST"
    shown = officer.act(sarah["primary"]["recommendationId"],
                        {"action": "INCLUDE", "narrativeIdShown": str(uuid.uuid4())}, sarah["etag"])
    assert shown.status_code == 422  # must be a narrative of this recommendation (Phase 4)


def test_full_workflow_keeps_audit_chain_valid(officer: Officer, sarah: dict[str, Any], session: Session) -> None:
    r1 = officer.act(sarah["primary"]["recommendationId"], {"action": "SKIP", "skipReasonCode": "CUSTOMER_BUDGET"},
                     sarah["etag"])
    u = officer.undo(sarah["primary"]["recommendationId"], r1.json()["actionId"], r1.headers["ETag"])
    r2 = officer.act(sarah["primary"]["recommendationId"], {"action": "INCLUDE"}, u.headers["ETag"])
    officer.act(sarah["alternative"]["recommendationId"],
                {"action": "DEFER", "deferReasonCode": "DATA_VERIFICATION", "followUpAt": "2026-10-16"},
                r2.headers["ETag"])
    check = verify_chain(session)
    assert check.valid, check
    ev = _events(session, sarah["case_id"])
    for expected in ("CASE_CREATED", "EVALUATED", "SKIPPED", "DECLINE_RECORDED", "REVERSED", "DECLINE_REVOKED",
                     "INCLUDED", "DEFERRED"):
        assert expected in ev
