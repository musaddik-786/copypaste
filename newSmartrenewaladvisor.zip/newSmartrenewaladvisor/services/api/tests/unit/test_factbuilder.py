"""Fact Builder: raw synthetic source rows -> Decision Context == rules/golden/personas.json (no database)."""
from __future__ import annotations

import json
from datetime import date, timedelta
from typing import Any

import pytest
import sra_pricing
import sra_rules
from sra_api.adapters.ports import collect_source
from sra_api.factbuilder.builder import build_context
from support.persona_compare import differences
from support.seed_source import GOLDEN_AS_OF, PERSONAS, QUOTE_TO_PERSONA, REPO, MemorySource

CATALOG: dict[str, Any] = json.loads((REPO / "rules/rule_catalog.v1.0.json").read_text(encoding="utf-8"))
PARAMS = {k: v["value"] for k, v in CATALOG["parameters"].items()}
QUOTES = sorted(QUOTE_TO_PERSONA)


def _build(quote_id: str, src: MemorySource | None = None, as_of: date = GOLDEN_AS_OF) -> dict[str, Any]:
    src = src or MemorySource()
    snap = collect_source(quote_id, src, src, src, src, src)
    assert snap is not None
    return build_context(snap, PARAMS, as_of).context


@pytest.mark.parametrize("quote_id", QUOTES, ids=[QUOTE_TO_PERSONA[q] for q in QUOTES])
def test_built_context_equals_persona(quote_id: str) -> None:
    assert differences(_build(quote_id), PERSONAS[QUOTE_TO_PERSONA[quote_id]]) == []


@pytest.mark.parametrize("quote_id", QUOTES, ids=[QUOTE_TO_PERSONA[q] for q in QUOTES])
def test_decision_on_built_context_equals_decision_on_persona(quote_id: str) -> None:
    def run(ctx: dict[str, Any]) -> dict[str, Any]:
        res = sra_rules.result_to_dict(sra_rules.evaluate(ctx, CATALOG, GOLDEN_AS_OF,
                                                          pricer=sra_pricing.price_candidate))
        res.pop("input_hash")  # differs only because personas.json carries documentation fields
        return res
    assert run(_build(quote_id)) == run(PERSONAS[QUOTE_TO_PERSONA[quote_id]])


def test_unknown_quote_returns_none() -> None:
    src = MemorySource()
    assert collect_source("QUO-0000-00000", src, src, src, src, src) is None


def test_missing_consent_row_is_missing_not_granted() -> None:
    src = MemorySource()
    src._consents = []
    ctx = _build("QUO-2026-91402", src)
    assert ctx["consent"]["advisory_renewal"] is None  # -> GK-01 SUPPRESS_DATA_INTEGRITY (fail closed)


def test_unverified_declaration_is_flagged() -> None:
    src = MemorySource()
    for d in src._declared:
        if d["customer_id"] == "CUST-77310" and d["fact_key"] == "dog_owner":
            d["verified"] = False
    assert "customer.dog_owner" in _build("QUO-2026-61849", src)["unverified_facts"]


def test_expired_rating_quote_is_not_verified() -> None:
    # Sarah's quotes are valid until the letter due date (2026-10-21); one day later they are no longer verified
    ctx = _build("QUO-2026-91402", as_of=date(2026, 10, 22))
    assert all(q["verified"] is False for q in ctx["pas_quotes"].values())


def test_declines_from_ledger_feed_cooldown_history() -> None:
    src = MemorySource(declines=[{"product_code": "LIAB_PRIVATE", "declined_at": date(2026, 6, 1),
                                  "source": "OFFICER_SKIP"}])
    ctx = _build("QUO-2026-91402", src)
    assert ctx["history"]["declines"] == [{"product_code": "LIAB_PRIVATE", "declined_at": "2026-06-01",
                                           "source": "OFFICER_SKIP"}]


def test_grievance_lookback_comes_from_ruleset_parameters() -> None:
    src = MemorySource()
    snap = collect_source("QUO-2026-44019", src, src, src, src, src)
    assert snap is not None
    # Mark's claim became DISPUTED on 2026-10-03 (10 days before as_of)
    assert build_context(snap, {**PARAMS, "grievance_lookback_days": 30}, GOLDEN_AS_OF).context[
        "conduct"]["disputed_claim_in_lookback"] is True
    assert build_context(snap, {**PARAMS, "grievance_lookback_days": 5}, GOLDEN_AS_OF).context[
        "conduct"]["disputed_claim_in_lookback"] is False


def test_facts_carry_quality_and_source() -> None:
    src = MemorySource()
    snap = collect_source("QUO-2026-61849", src, src, src, src, src)
    assert snap is not None
    facts = {f.path: f for f in build_context(snap, PARAMS, GOLDEN_AS_OF).facts}
    assert facts["customer.dwelling_type"].quality == "MISSING"
    assert facts["customer.dwelling_type"].source_system == "CRM"
    assert facts["policy.renewal_premium"].quality == "OK"
    assert facts["conduct.open_claim_in_settlement"].source_system == "CLAIMS"


def test_days_to_letter_due_follows_as_of() -> None:
    assert _build("QUO-2026-44019", as_of=GOLDEN_AS_OF + timedelta(days=1))["quote"]["days_to_letter_due"] == 2
