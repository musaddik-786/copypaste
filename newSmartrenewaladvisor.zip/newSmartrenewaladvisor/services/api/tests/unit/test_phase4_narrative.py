"""DB-free tests for Phase 4: fact pack, every validator (positive and negative), router matrix, templates."""
from __future__ import annotations

import json
from typing import Any

import pytest
from sra_api.narrative.clients import FakeClient, valid_reply
from sra_api.narrative.fact_pack import Statement, build
from sra_api.narrative.router import Deployment, route
from sra_api.narrative.templates import fallback
from sra_api.narrative.validators import (
    ValidationContext,
    approved_claims,
    length_readability,
    number_provenance,
    passed,
    pii_leak,
    prohibited_phrases,
    protected_attributes,
    run_all,
)
from support.seed_source import REPO

CATALOG: dict[str, Any] = json.loads((REPO / "rules/rule_catalog.v1.0.json").read_text(encoding="utf-8"))
DRAFT: dict[str, Any] = json.loads((REPO / "ai/content/benefit_statements.draft.v1.json").read_text(encoding="utf-8"))
CTX = ValidationContext(("Sarah", "Jenkins", "Sarah Jenkins", "82 Park Lane", "20095", "Hamburg", "CUST-38192"))
PRICING = {"expiring_premium": "490.00", "base_renewal_premium": "515.00", "incremental_annual": "57.00",
           "incremental_monthly_equiv": "4.75", "companion_standalone_annual": "57.00", "bundle_discount_pct": "5",
           "bundle_saving_annual": "28.60", "net_annual_total": "543.40"}
CLAUSES = [{"op": "==", "left": "customer.occupancy", "left_value": "TENANT", "right": "TENANT",
            "right_value": "TENANT", "result": True},
           {"op": "==", "left": "customer.customer_id", "left_value": "CUST-38192", "right": "x", "right_value": "x",
            "result": False},
           {"op": "<=", "left": "vehicle.age_years", "left_value": 4, "right": "params.full_comp_max_vehicle_age",
            "right_value": 8, "result": True}]


def statements(product: str) -> list[Statement]:
    return [Statement(k, t, "DRAFT") for k, t in DRAFT["products"][product].items()]


def pack(product: str = "LIAB_PRIVATE", kind: str = "CROSS_SELL", audience: str = "OFFICER",
         clauses: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    name = CATALOG["products"][product]["name_en"]
    return build(rule_id="CS-LIA-01", opportunity_type=kind, product_code=product, product_name=name,
                 priority_tier="P1", pricing=PRICING, clauses=CLAUSES if clauses is None else clauses,
                 statements=statements(product), audience=audience).pack


def good(**over: Any) -> dict[str, Any]:
    out: dict[str, Any] = json.loads(valid_reply(pack()))
    out.update(over)
    return out


# ----------------------------------------------------------------------------- fact pack
def test_fact_pack_holds_no_identifiers_or_personal_data() -> None:
    p = pack()
    blob = json.dumps(p)
    for forbidden in ("CUST-38192", "customer_id", "Sarah", "Hamburg", "POL-", "QUO-"):
        assert forbidden not in blob
    assert [f["key"] for f in p["facts"]] == ["customer.occupancy", "vehicle.age_years"]
    assert p["tokens"] == {"first_name": "{{FIRST_NAME}}", "city": "{{CITY}}"}
    assert p["current_gap"] and all(not b["statement_key"].endswith(".GAP") for b in p["approved_benefits"])


def test_fact_pack_hash_is_stable_and_content_sensitive() -> None:
    a = build(rule_id="CS-LIA-01", opportunity_type="CROSS_SELL", product_code="LIAB_PRIVATE",
              product_name="Personal Liability Insurance", priority_tier="P1", pricing=PRICING, clauses=CLAUSES,
              statements=statements("LIAB_PRIVATE"), audience="OFFICER")
    b = build(rule_id="CS-LIA-01", opportunity_type="CROSS_SELL", product_code="LIAB_PRIVATE",
              product_name="Personal Liability Insurance", priority_tier="P1", pricing=PRICING, clauses=CLAUSES,
              statements=statements("LIAB_PRIVATE"), audience="OFFICER")
    c = build(rule_id="CS-LIA-01", opportunity_type="CROSS_SELL", product_code="LIAB_PRIVATE",
              product_name="Personal Liability Insurance", priority_tier="P1",
              pricing={**PRICING, "net_annual_total": "543.41"}, clauses=CLAUSES,
              statements=statements("LIAB_PRIVATE"), audience="OFFICER")
    assert a.sha256 == b.sha256 != c.sha256
    assert a.uses_draft_content


# ----------------------------------------------------------------------------- every product: template + model reply
RULE_PRODUCTS = sorted({(r["product_code"], r["type"]) for r in CATALOG["rules"]})


@pytest.mark.parametrize(("product", "kind"), RULE_PRODUCTS, ids=[p for p, _ in RULE_PRODUCTS])
@pytest.mark.parametrize("audience", ["OFFICER", "CUSTOMER_LETTER"])
def test_template_and_fake_reply_pass_all_validators(product: str, kind: str, audience: str) -> None:
    p = pack(product, kind, audience)
    for out in (fallback(p), json.loads(valid_reply(p))):
        results = run_all(out, p, CTX)
        assert passed(results), [(r.validator, [f.message for f in r.findings]) for r in results if not r.passed]


@pytest.mark.parametrize(("product", "kind"), RULE_PRODUCTS, ids=[p for p, _ in RULE_PRODUCTS])
@pytest.mark.parametrize("audience", ["OFFICER", "CUSTOMER_LETTER"])
def test_template_passes_without_any_approved_wording(product: str, kind: str, audience: str) -> None:
    """The safety net must hold even when no statement is usable (pseudonymised data, drafts not allowed)."""
    p = build(rule_id="R", opportunity_type=kind, product_code=product, product_name=CATALOG["products"][product][
        "name_en"], priority_tier="P1", pricing=PRICING, clauses=CLAUSES, statements=[], audience=audience).pack
    results = run_all(fallback(p), p, CTX)
    assert passed(results), [(r.validator, [f.message for f in r.findings]) for r in results if not r.passed]


def test_neutral_sentence_is_not_a_claim_but_invented_benefit_is() -> None:
    p = build(rule_id="R", opportunity_type="CROSS_SELL", product_code="LIAB_PRIVATE",
              product_name="Personal Liability Insurance", priority_tier="P1", pricing=PRICING, clauses=CLAUSES,
              statements=[], audience="OFFICER").pack
    neutral = good(how_it_helps="The details of the cover are set out in the product information document.",
                   key_benefit_keys=[])
    assert approved_claims.check(neutral, p, CTX).passed
    assert not approved_claims.check(good(how_it_helps="It protects you against lawsuits worldwide.",
                                          key_benefit_keys=[]), p, CTX).passed


def test_draft_wording_itself_is_lexicon_clean() -> None:
    for product, stmts in DRAFT["products"].items():
        for key, text_ in stmts.items():
            fake = {"why_recommended": text_, "current_gap": "", "how_it_helps": "", "letter_rationale": ""}
            p = {"approved_benefits": [], "facts": [], "recommendation": {"product_name": CATALOG["products"][
                product]["name_en"]}}
            assert prohibited_phrases.check(fake, p, CTX).passed, (product, key)
            assert protected_attributes.check(fake, p, CTX).passed, (product, key)
            assert not number_provenance.numbers_in(text_), (product, key, "statements must not contain numbers")


# ----------------------------------------------------------------------------- validators: negatives
def test_schema_rejects_extra_and_missing_fields() -> None:
    assert not run_all({**good(), "extra": 1}, pack(), CTX)[0].passed
    bad = good()
    del bad["used_numbers"]
    assert not run_all(bad, pack(), CTX)[0].passed
    assert not run_all("not json", pack(), CTX)[0].passed


@pytest.mark.parametrize(("text_", "used", "ok"), [
    ("The total is 543.40 a year.", ["543.40"], True),
    ("The total is €543.40 a year.", ["543.40"], True),
    ("Insgesamt 543,40 € pro Jahr.", ["543,40"], True),
    ("A bundle saving of 5% applies.", ["5"], True),
    ("Vehicles of 4 years qualify.", ["4"], True),                 # fact value
    ("The total is 543.40 a year.", [], False),                   # not declared in used_numbers
    ("Most claims cost 1,200 EUR.", ["1,200"], False),            # invented number
    ("Save 30% today.", ["30"], False),
])
def test_number_provenance(text_: str, used: list[str], ok: bool) -> None:
    r = number_provenance.check(good(why_recommended=text_, used_numbers=used), pack(), CTX)
    assert r.passed is ok, r.findings


def test_approved_claims_rejects_unknown_keys_and_unsupported_benefits() -> None:
    assert not approved_claims.check(good(key_benefit_keys=["PL.MADE_UP"]), pack(), CTX).passed
    assert not approved_claims.check(good(key_benefit_keys=["PL.HOUSEHOLD", "PL.HOUSEHOLD"]), pack(), CTX).passed
    invented = good(how_it_helps="It reimburses hospital stays and pays out a monthly pension for life.")
    assert not approved_claims.check(invented, pack(), CTX).passed
    paraphrase = good(how_it_helps="It pays for damage accidentally caused to other people or their property.")
    assert approved_claims.check(paraphrase, pack(), CTX).passed


@pytest.mark.parametrize(("phrase", "blocked"), [
    ("This cover is guaranteed to pay.", True), ("Act now, this is exclusive.", True),
    ("Avoid financial ruin.", True), ("It is required by law.", True), ("You are fully covered.", True),
    ("Studies show most customers agree.", True), ("We analysed your data.", True),
    ("Diese Deckung ist Pflicht.", True), ("The first month is free.", False),   # PP-07 is WARN only
    ("It pays for damage to others.", False),
])
def test_prohibited_phrases(phrase: str, blocked: bool) -> None:
    r = prohibited_phrases.check(good(how_it_helps=phrase), pack(), CTX)
    assert r.passed is not blocked
    if "free" in phrase:
        assert [f.severity for f in r.findings] == ["WARN"]


@pytest.mark.parametrize(("text_", "leak"), [
    ("{{FIRST_NAME}} in {{CITY}} has no liability cover.", False),
    ("Sarah has no liability cover.", True), ("The customer lives in Hamburg.", True),
    ("Policy POL-CAR-771204 renews soon.", True), ("Write to sarah@example.com.", True),
    ("IBAN DE89 3704 0044 0532 0130 00 is on file.", True), ("Call +49 40 1234 5678.", True),
    ("The plate HH-SJ 5678 is registered.", True), ("Declared on 2026-06-02.", False),
])
def test_pii_leak(text_: str, leak: bool) -> None:
    assert pii_leak.check(good(why_recommended=text_), pack(), CTX).passed is not leak


def test_protected_attributes_with_object_age_exemption() -> None:
    no_age_facts = pack(clauses=[CLAUSES[0]])
    assert not protected_attributes.check(good(why_recommended="Given her age, this fits."), no_age_facts, CTX).passed
    assert not protected_attributes.check(good(why_recommended="Her health matters."), no_age_facts, CTX).passed
    # vehicle.age_years is an exempt fact key -> describing the vehicle's age is allowed
    assert protected_attributes.check(good(why_recommended="The vehicle age is 4 years."), pack(), CTX).passed
    pet = pack("PET_HEALTH_SURGERY", "CROSS_SELL")
    assert protected_attributes.check(good(why_recommended="Pet Health & Surgery Cover fits."), pet, CTX).passed


def test_length_and_readability() -> None:
    assert not length_readability.check(good(letter_rationale="Only one sentence."), pack(), CTX).passed
    assert not length_readability.check(good(why_recommended="A. B. C. D."), pack(), CTX).passed
    assert not length_readability.check(good(key_benefit_keys=["PL.HOUSEHOLD"]), pack(), CTX).passed
    long_words = "Notwithstanding indemnification responsibilities, comprehensive organisational considerations " \
                 "necessitate institutionalised contractualisation methodologies."
    assert not length_readability.check(good(how_it_helps=long_words), pack(), CTX).passed


# ----------------------------------------------------------------------------- router matrix (invariant 8)
def dep(provider: str = "AZURE_OPENAI", boundary: str = "EU", classes: tuple[str, ...] = ("SYNTHETIC",
        "PSEUDONYMISED"), active: bool = True) -> Deployment:
    return Deployment("d", provider, "m", "t", boundary, classes, active)


@pytest.mark.parametrize(("deployment", "data_class", "claude_flag", "allowed"), [
    (dep(), "SYNTHETIC", False, True),
    (dep(), "PSEUDONYMISED", False, True),                                        # EU data zone
    (dep(boundary="GLOBAL", classes=("SYNTHETIC",)), "SYNTHETIC", False, True),   # claimsfoundry gpt-4.1
    (dep(boundary="GLOBAL", classes=("SYNTHETIC",)), "PSEUDONYMISED", False, False),
    (dep(boundary="GLOBAL", classes=("SYNTHETIC", "PSEUDONYMISED")), "PSEUDONYMISED", False, False),  # mis-config
    (dep(provider="ANTHROPIC_FOUNDRY", boundary="GLOBAL", classes=("SYNTHETIC",)), "SYNTHETIC", False, False),
    (dep(provider="ANTHROPIC_FOUNDRY", boundary="GLOBAL", classes=("SYNTHETIC",)), "SYNTHETIC", True, True),
    (dep(provider="ANTHROPIC_FOUNDRY", boundary="EU"), "PSEUDONYMISED", True, False),
    (dep(active=False), "SYNTHETIC", False, False),
    (None, "SYNTHETIC", False, False),
])
def test_router_matrix(deployment: Deployment | None, data_class: str, claude_flag: bool, allowed: bool) -> None:
    assert route(deployment, data_class, allow_synthetic_claude=claude_flag).allowed is allowed  # type: ignore[arg-type]


def test_fake_client_reads_pack_from_prompt() -> None:
    p = pack()
    client = FakeClient()
    out = client.complete("d", [{"role": "system", "content": "x\n```json\n" + json.dumps(p) + "\n```"},
                                {"role": "user", "content": "go"}])
    assert passed(run_all(json.loads(out.text), p, CTX))
