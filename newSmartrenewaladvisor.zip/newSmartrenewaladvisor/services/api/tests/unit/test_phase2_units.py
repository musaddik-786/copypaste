"""DB-free unit tests: state machine, queue signal, pricing row mapping, audit hashing, settings guard."""
from __future__ import annotations

import uuid
from datetime import UTC, datetime
from decimal import Decimal

import pytest
from sra_api.audit.ledger import GENESIS, event_hash
from sra_api.cases.state_machine import opportunity_signal, state_after_decision
from sra_api.pricing.persist import scenario_values
from sra_api.settings import Settings
from sra_rules import Candidate


@pytest.mark.parametrize(("status", "current", "expected"), [
    ("NOT_TRIGGERED", "RECEIVED", "NOT_TRIGGERED"),
    ("SUPPRESSED", "RECEIVED", "SUPPRESSED"),
    ("NO_OPPORTUNITY", "RECEIVED", "EVALUATED"),
    ("RECOMMENDATIONS_AVAILABLE", "RECEIVED", "READY_FOR_REVIEW"),
    ("RECOMMENDATIONS_AVAILABLE", "IN_REVIEW", "IN_REVIEW"),       # stale re-evaluation keeps the officer in review
    ("RECOMMENDATIONS_AVAILABLE", "DECIDED", "READY_FOR_REVIEW"),  # superseded decisions need review again
    ("SUPPRESSED", "READY_FOR_REVIEW", "SUPPRESSED"),              # e.g. a complaint arrived meanwhile
])
def test_state_after_decision(status: str, current: str, expected: str) -> None:
    assert state_after_decision(status, current) == expected


@pytest.mark.parametrize("closed", ["LETTER_APPROVED", "DISPATCHED", "CLOSED"])
def test_closed_window_cannot_be_reevaluated(closed: str) -> None:
    with pytest.raises(ValueError):
        state_after_decision("RECOMMENDATIONS_AVAILABLE", closed)


@pytest.mark.parametrize(("status", "types", "signal"), [
    ("SUPPRESSED", [], "SUPPRESSED"), ("NO_OPPORTUNITY", [], "NONE"), ("NOT_TRIGGERED", [], "NONE"),
    ("RECOMMENDATIONS_AVAILABLE", ["UPSELL"], "UPSELL"),
    ("RECOMMENDATIONS_AVAILABLE", ["CROSS_SELL"], "CROSS_SELL"),
    ("RECOMMENDATIONS_AVAILABLE", ["UPSELL", "CROSS_SELL"], "UPSELL_AND_CROSS_SELL"),
    ("RECOMMENDATIONS_AVAILABLE", ["UPSELL", "UPSELL"], "MULTI_UPSELL"),
    ("RECOMMENDATIONS_AVAILABLE", ["CROSS_SELL", "CROSS_SELL"], "MULTI_CROSS_SELL"),
])
def test_opportunity_signal(status: str, types: list[str], signal: str) -> None:
    assert opportunity_signal(status, types) == signal


def _cand(kind: str, pricing: dict[str, str]) -> Candidate:
    return Candidate("R-1", kind, "LIAB_PRIVATE", "P1", 1, None, pricing)


def test_cross_sell_scenario_satisfies_db_net_consistency() -> None:
    v = scenario_values(_cand("CROSS_SELL", {
        "expiring_premium": "490.00", "base_renewal_premium": "515.00", "incremental_annual": "57.00",
        "incremental_monthly_equiv": "4.75", "bundle_discount_pct": "5", "bundle_saving_annual": "28.60",
        "companion_standalone_annual": "57.00", "net_annual_total": "543.40"}), {"LIAB_PRIVATE": "QUO-R1"})
    assert v["net_annual_total"] == (v["base_renewal_premium"] + v["upsell_increment_annual"]
                                     + v["companion_standalone_annual"] - v["bundle_saving_annual"])
    assert v["upsell_increment_annual"] == Decimal("0.00") and v["rating_quote_refs"] == ["QUO-R1"]


def test_upsell_scenario_satisfies_db_net_consistency() -> None:
    v = scenario_values(_cand("UPSELL", {
        "expiring_premium": "420.00", "base_renewal_premium": "445.00", "incremental_annual": "45.60",
        "incremental_monthly_equiv": "3.80", "bundle_discount_pct": "0", "bundle_saving_annual": "0.00",
        "net_annual_total": "490.60"}), {})
    assert v["net_annual_total"] == v["base_renewal_premium"] + v["upsell_increment_annual"]
    assert v["companion_standalone_annual"] == Decimal("0.00")
    assert all(not isinstance(x, float) for x in v.values())


def test_audit_hash_changes_with_any_part_of_the_event() -> None:
    at = datetime(2026, 10, 13, 9, 0, tzinfo=UTC)
    env = {"actor_type": "OFFICER", "actor_id": "officer.anna", "case_id": str(uuid.uuid4()),
           "entity_type": "CASE", "entity_id": "x", "event_type": "STATE_CHANGED", "payload": {"to": "IN_REVIEW"}}
    h = event_hash(GENESIS, env, at)
    assert h == event_hash(GENESIS, dict(reversed(list(env.items()))), at)  # key order does not matter
    assert h != event_hash("1" * 64, env, at)                                # chain link
    assert h != event_hash(GENESIS, {**env, "actor_id": "officer.ben"}, at)  # who
    assert h != event_hash(GENESIS, {**env, "payload": {"to": "DECIDED"}}, at)  # what
    assert h != event_hash(GENESIS, env, at.replace(microsecond=1))          # when


def test_dev_auth_refused_outside_local() -> None:
    with pytest.raises(ValueError, match="only allowed"):
        Settings(sra_env="prod", sra_auth_mode="dev", database_url="")
    assert Settings(sra_env="prod", sra_auth_mode="entra", database_url="").sra_auth_mode == "entra"


def test_database_url_uses_psycopg3_driver() -> None:
    s = Settings(database_url="postgresql://u:p@h:5432/db?sslmode=require", sra_env="local")
    assert s.database_url.startswith("postgresql+psycopg://")
