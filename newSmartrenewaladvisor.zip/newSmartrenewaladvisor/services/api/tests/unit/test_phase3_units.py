"""DB-free tests for Phase 3: the full transition matrix and the officer-action rules."""
from __future__ import annotations

import json
from datetime import date
from typing import Any

import pytest
from sra_api.cases.action_rules import (
    ActionRequest,
    add_months,
    cooldown_months,
    sla_cutoff,
    validate,
)
from sra_api.cases.state_machine import OFFICER_TRANSITIONS, IllegalTransition, transition
from support.seed_source import REPO

CATALOG: dict[str, Any] = json.loads((REPO / "rules/rule_catalog.v1.0.json").read_text(encoding="utf-8"))
STATES = ["RECEIVED", "EVALUATED", "SUPPRESSED", "READY_FOR_REVIEW", "IN_REVIEW", "DECIDED", "LETTER_DRAFTED",
          "LETTER_APPROVED", "DISPATCHED", "CLOSED", "NOT_TRIGGERED"]
EVENTS = ["START_REVIEW", "ACTION", "ALL_ACTIONED", "REVERSAL", "COMPOSE", "SLA_CUTOFF", "APPROVE", "DISPATCH"]
EXPECTED = {("READY_FOR_REVIEW", "START_REVIEW"): "IN_REVIEW", ("IN_REVIEW", "ACTION"): "IN_REVIEW",
            ("IN_REVIEW", "ALL_ACTIONED"): "DECIDED", ("IN_REVIEW", "REVERSAL"): "IN_REVIEW",
            ("DECIDED", "REVERSAL"): "IN_REVIEW", ("LETTER_DRAFTED", "REVERSAL"): "IN_REVIEW",
            ("DECIDED", "COMPOSE"): "LETTER_DRAFTED", ("SUPPRESSED", "COMPOSE"): "LETTER_DRAFTED",
            ("EVALUATED", "COMPOSE"): "LETTER_DRAFTED", ("LETTER_DRAFTED", "COMPOSE"): "LETTER_DRAFTED",
            ("READY_FOR_REVIEW", "SLA_CUTOFF"): "LETTER_DRAFTED", ("IN_REVIEW", "SLA_CUTOFF"): "LETTER_DRAFTED",
            ("LETTER_DRAFTED", "APPROVE"): "LETTER_APPROVED", ("LETTER_APPROVED", "DISPATCH"): "DISPATCHED"}

SKIP_REASONS = {"CUSTOMER_BUDGET": {"active": True, "requires_comment": False, "creates_cooldown": True},
                "INAPPROPRIATE_TIMING": {"active": True, "requires_comment": True, "creates_cooldown": False},
                "RETIRED": {"active": False, "requires_comment": False, "creates_cooldown": False}}
CONTACT = {"max_defer_days": 7}
TODAY = date(2026, 10, 13)          # Tuesday
DUE = date(2026, 10, 21)            # Wednesday -> SLA cut-off Tuesday 2026-10-20


# ----------------------------------------------------------------------------- state machine
@pytest.mark.parametrize("state", STATES)
@pytest.mark.parametrize("event", EVENTS)
def test_transition_matrix(state: str, event: str) -> None:
    if (state, event) in EXPECTED:
        assert transition(state, event) == EXPECTED[(state, event)]  # type: ignore[arg-type]
    else:
        with pytest.raises(IllegalTransition):
            transition(state, event)  # type: ignore[arg-type]


def test_table_has_no_untested_entries() -> None:
    assert OFFICER_TRANSITIONS == EXPECTED


# ----------------------------------------------------------------------------- dates
@pytest.mark.parametrize(("due", "cutoff"), [
    (date(2026, 10, 21), date(2026, 10, 20)),   # Wed -> Tue
    (date(2026, 10, 26), date(2026, 10, 23)),   # Mon -> previous Fri
    (date(2026, 10, 25), date(2026, 10, 23)),   # Sun -> Fri
    (date(2026, 10, 24), date(2026, 10, 23)),   # Sat -> Fri
])
def test_sla_cutoff_is_previous_working_day(due: date, cutoff: date) -> None:
    assert sla_cutoff(due) == cutoff


@pytest.mark.parametrize(("d", "months", "expected"), [
    (date(2026, 10, 13), 12, date(2027, 10, 13)), (date(2026, 10, 13), 6, date(2027, 4, 13)),
    (date(2026, 8, 31), 6, date(2027, 2, 28)), (date(2027, 8, 31), 6, date(2028, 2, 29)),
])
def test_add_months(d: date, months: int, expected: date) -> None:
    assert add_months(d, months) == expected


def test_cooldown_length_comes_from_ruleset_parameters() -> None:
    p = CATALOG["parameters"]
    assert cooldown_months("CAR_NCD_PROTECTION", CATALOG) == p["cooldown_rider_months"]["value"]       # RIDER
    assert cooldown_months("LIAB_PRIVATE", CATALOG) == p["cooldown_companion_months"]["value"]         # COMPANION
    assert cooldown_months("UNKNOWN_PRODUCT", CATALOG) == p["cooldown_companion_months"]["value"]      # fail-safe


# ----------------------------------------------------------------------------- action validation
def _v(req: ActionRequest) -> list[str]:
    return [f.field for f in validate(req, skip_reason=SKIP_REASONS.get(req.skip_reason_code or ""),
                                      defer_reason=CONTACT if req.defer_reason_code == "CUSTOMER_CONTACT_PENDING"
                                      else None, today=TODAY, letter_due=DUE)]


@pytest.mark.parametrize(("req", "fields"), [
    (ActionRequest("INCLUDE"), []),
    (ActionRequest("INCLUDE", skip_reason_code="CUSTOMER_BUDGET"), ["action"]),
    (ActionRequest("SKIP"), ["skipReasonCode"]),
    (ActionRequest("SKIP", skip_reason_code="NOPE"), ["skipReasonCode"]),
    (ActionRequest("SKIP", skip_reason_code="RETIRED"), ["skipReasonCode"]),
    (ActionRequest("SKIP", skip_reason_code="CUSTOMER_BUDGET"), []),
    (ActionRequest("SKIP", skip_reason_code="INAPPROPRIATE_TIMING"), ["comment"]),
    (ActionRequest("SKIP", skip_reason_code="INAPPROPRIATE_TIMING", comment="   "), ["comment"]),
    (ActionRequest("SKIP", skip_reason_code="INAPPROPRIATE_TIMING", comment="call back after move"), []),
    (ActionRequest("DEFER"), ["deferReasonCode", "followUpAt"]),
    (ActionRequest("DEFER", defer_reason_code="CUSTOMER_CONTACT_PENDING"), ["followUpAt"]),
    (ActionRequest("DEFER", defer_reason_code="CUSTOMER_CONTACT_PENDING", follow_up_on=TODAY), ["followUpAt"]),
    (ActionRequest("DEFER", defer_reason_code="CUSTOMER_CONTACT_PENDING", follow_up_on=date(2026, 10, 14)), []),
    (ActionRequest("DEFER", defer_reason_code="CUSTOMER_CONTACT_PENDING", follow_up_on=date(2026, 10, 20)), []),
    # 8 days > max_defer_days (7) and after the SLA cut-off (2026-10-20)
    (ActionRequest("DEFER", defer_reason_code="CUSTOMER_CONTACT_PENDING", follow_up_on=date(2026, 10, 21)),
     ["followUpAt", "followUpAt"]),
    (ActionRequest("DEFER", defer_reason_code="UNKNOWN", follow_up_on=date(2026, 10, 14)), ["deferReasonCode"]),
])
def test_validate(req: ActionRequest, fields: list[str]) -> None:
    assert _v(req) == fields


def test_defer_after_cutoff_is_rejected_even_within_max_days() -> None:
    late_today = date(2026, 10, 19)
    findings = validate(ActionRequest("DEFER", defer_reason_code="CUSTOMER_CONTACT_PENDING",
                                      follow_up_on=date(2026, 10, 21)),
                        skip_reason=None, defer_reason=CONTACT, today=late_today, letter_due=DUE)
    assert [f.message for f in findings] == ["the follow-up date is after the SLA cut-off 2026-10-20"]
