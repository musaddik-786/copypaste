"""DB-free tests for the letter composer and PDF renderer (ADR-012, BR-13, docs/05 §5.5, invariant 10)."""
from __future__ import annotations

import hashlib
import json
from dataclasses import replace

import pytest
from sra_api.letters.composer import SECTION_ORDER, LetterInputs, LetterRecommendation, compose, section_order_is_valid
from sra_api.letters.pdf import render

CROSS = LetterRecommendation(
    "r-cross", "REC-2026-0001", "CROSS_SELL", "Personal Liability Insurance", "INCLUDED", 1,
    {"expiring_premium": "490.00", "base_renewal_premium": "515.00", "incremental_annual": "57.00",
     "companion_standalone_annual": "57.00", "incremental_monthly_equiv": "4.75", "bundle_discount_pct": "5",
     "bundle_saving_annual": "28.60", "net_annual_total": "543.40"},
    "Based on the information we hold, Personal Liability Insurance could complement your cover. It is optional.",
    "LLM", True)
UPSELL = LetterRecommendation(
    "r-up", "REC-2026-0002", "UPSELL", "No-Claims Discount Protection", "INCLUDED", 2,
    {"expiring_premium": "490.00", "base_renewal_premium": "515.00", "incremental_annual": "52.80",
     "incremental_monthly_equiv": "4.40", "bundle_discount_pct": "0", "bundle_saving_annual": "0.00",
     "net_annual_total": "567.80"},
    "Based on the information we hold, this cover could be added to your renewal. It is optional.", "LLM", True)


def inputs(*recs: LetterRecommendation) -> LetterInputs:
    return LetterInputs("Sarah", "Jenkins", "POL-CAR-771204", "CAR", "2026-11-21", "490.00", "515.00", list(recs))


def types(letter_inputs: LetterInputs) -> list[str]:
    return [s.section_type for s in compose(letter_inputs).sections]


def test_no_included_recommendation_gives_standard_letter() -> None:
    for recs in [(), (replace(CROSS, status="SKIPPED"),), (replace(CROSS, status="EXPIRED"),),
                 (replace(CROSS, status="DEFERRED"),), (replace(CROSS, status="PENDING"),)]:
        c = compose(inputs(*recs))
        assert c.letter_type == "STANDARD"
        assert [s.section_type for s in c.sections] == ["CORE_RENEWAL_TERMS", "PREMIUM_CHANGE_NOTICE", "ATTACHMENTS"]


def test_advisory_letter_has_every_section_in_the_fixed_order() -> None:
    c = compose(inputs(CROSS))
    assert c.letter_type == "ADVISORY"
    assert [s.section_type for s in c.sections] == list(SECTION_ORDER)
    assert section_order_is_valid(c.sections)


def test_only_included_recommendations_reach_the_letter() -> None:
    c = compose(inputs(CROSS, replace(UPSELL, status="SKIPPED")))
    advisory = [s for s in c.sections if s.section_type == "ADVISORY_BLOCK"]
    assert [s.recommendation_id for s in advisory] == ["r-cross"]


def test_two_included_recommendations_get_separate_blocks_and_no_combined_total() -> None:
    c = compose(inputs(UPSELL, CROSS))
    assert [s.section_type for s in c.sections] == ["CORE_RENEWAL_TERMS", "PREMIUM_CHANGE_NOTICE", "ADVISORY_BLOCK",
                                                    "ADVISORY_BLOCK", "BUNDLE_SAVINGS", "OPT_IN_INSTRUCTION",
                                                    "OBJECTION_NOTICE", "ATTACHMENTS"]
    assert [s.recommendation_id for s in c.sections if s.section_type == "ADVISORY_BLOCK"] == ["r-cross", "r-up"]
    assert "both recommendations" not in json.dumps([s.content for s in c.sections]).lower()


def test_cross_sell_is_itemised_and_separately_purchasable() -> None:
    block = next(s for s in compose(inputs(CROSS)).sections if s.section_type == "ADVISORY_BLOCK").content
    assert block["separator_heading"] == "Optional recommendation (not part of your renewal)"
    assert block["heading"] == "Recommended Policy - Personal Liability Insurance"
    table = dict(block["table"])
    assert table["Annual premium of the separate policy"] == "57.00"
    assert table["Bundle saving per year"] == "28.60" and table["Annual total for both policies"] == "543.40"
    assert "This policy can be taken out separately at EUR 57.00 per year." in block["notes"]


def test_upsell_heading_and_no_bundle_section() -> None:
    c = compose(inputs(UPSELL))
    block = next(s for s in c.sections if s.section_type == "ADVISORY_BLOCK").content
    assert block["heading"] == "Recommended Coverage - No-Claims Discount Protection"
    assert "BUNDLE_SAVINGS" not in [s.section_type for s in c.sections]


def test_no_pre_ticked_opt_in_anywhere() -> None:
    blob = json.dumps([s.content for s in compose(inputs(UPSELL, CROSS)).sections]).lower()
    for marker in ("checked", "checkbox", "[x]", "pre-ticked", "selected\": true", "opt_in\": true"):
        assert marker not in blob
    opt_in = next(s for s in compose(inputs(CROSS)).sections if s.section_type == "OPT_IN_INSTRUCTION").content
    assert "Nothing changes unless you tell us" in opt_in["text"]


def test_objection_notice_and_documents_are_always_in_advisory_letters() -> None:
    c = compose(inputs(CROSS))
    objection = next(s for s in c.sections if s.section_type == "OBJECTION_NOTICE").content["text"]
    assert "Article 21" in objection
    items = next(s for s in c.sections if s.section_type == "ATTACHMENTS").content["items"]
    assert any("IPID" in i for i in items) and any("AVB" in i for i in items)
    assert any("withdrawal" in i for i in items)        # companion policy -> VVG §8 withdrawal information
    assert not any("http" in i for i in items)          # no invented document links


def test_genai_text_only_fills_the_rationale_slot() -> None:
    c = compose(inputs(CROSS))
    blocks = [s for s in c.sections if CROSS.letter_rationale in json.dumps(s.content)]
    assert [s.section_type for s in blocks] == ["ADVISORY_BLOCK"]


def test_missing_rationale_is_refused() -> None:
    with pytest.raises(ValueError, match="validated letter rationale"):
        compose(inputs(replace(CROSS, letter_rationale=None)))


def test_pdf_is_deterministic_and_content_sensitive() -> None:
    a, b = render(compose(inputs(CROSS)), title="t"), render(compose(inputs(CROSS)), title="t")
    assert hashlib.sha256(a).digest() == hashlib.sha256(b).digest() and a.startswith(b"%PDF")
    changed = render(compose(inputs(replace(CROSS, pricing={**CROSS.pricing, "net_annual_total": "543.41"}))),
                     title="t")
    assert hashlib.sha256(changed).digest() != hashlib.sha256(a).digest()


def test_draft_wording_is_flagged() -> None:
    assert compose(inputs(CROSS)).draft_wording is True
