"""Runtime configuration. Values come from the environment or the repo-root ``.env`` (never committed)."""
from __future__ import annotations

from datetime import date
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

REPO_ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=REPO_ROOT / ".env", env_file_encoding="utf-8", extra="ignore")

    database_url: str = ""
    sra_env: Literal["local", "dev", "test", "prod"] = "local"
    sra_auth_mode: Literal["dev", "entra"] = "dev"
    # Pin the business date for demos / tests (the golden suite uses 2026-10-13). Empty = today.
    sra_as_of: date | None = None
    sra_jurisdiction: str = "DE"

    # --- Narrative service (Phase 4). Keyless auth: DefaultAzureCredential, no API key anywhere.
    azure_openai_endpoint: str = ""
    azure_openai_chat_deployment: str = ""
    azure_openai_api_version: str = "2024-10-21"
    # Deployment the router uses; must exist in sra.model_deployment. Defaults to the chat deployment.
    sra_narrative_model: str = ""
    # azure = real model; fake = deterministic test double (never used outside tests/demos without a model)
    sra_narrative_client: Literal["azure", "fake"] = "azure"
    # Data class of the configured source systems. The POC src mock holds synthetic personas only.
    sra_source_data_class: Literal["SYNTHETIC", "PSEUDONYMISED"] = "SYNTHETIC"
    sra_allow_synthetic_claude: bool = False
    # Use DRAFT (not yet Compliance-approved) benefit statements and prompt - only ever for SYNTHETIC data.
    sra_allow_draft_statements: bool = False
    sra_narrative_inline: bool = True       # generate during the evaluation request (POC); else on demand
    sra_letter_languages: str = "en"        # comma separated; en is the default everywhere
    sra_narrative_timeout_s: float = 30.0
    # --- Letters (Phase 5). POC: rendered PDFs on local disk (git-ignored); Azure Blob (immutable) in the pilot.
    sra_letter_storage_dir: Path = REPO_ROOT / "var" / "letters"

    @property
    def narrative_deployment(self) -> str:
        return self.sra_narrative_model or self.azure_openai_chat_deployment

    @property
    def languages(self) -> list[str]:
        langs = [x.strip() for x in self.sra_letter_languages.split(",") if x.strip()]
        return langs or ["en"]

    @field_validator("database_url")
    @classmethod
    def _use_psycopg3(cls, v: str) -> str:
        for prefix in ("postgresql://", "postgres://"):
            if v.startswith(prefix):
                return "postgresql+psycopg://" + v[len(prefix):]
        return v

    @field_validator("sra_as_of", mode="before")
    @classmethod
    def _empty_as_none(cls, v: object) -> object:
        return None if v == "" else v

    @model_validator(mode="after")
    def _dev_auth_only_locally(self) -> Settings:
        # The header-based dev stub must never run outside a developer machine / test run.
        if self.sra_auth_mode == "dev" and self.sra_env not in ("local", "test"):
            raise ValueError("SRA_AUTH_MODE=dev is only allowed when SRA_ENV is 'local' or 'test'")
        if self.sra_allow_draft_statements and self.sra_source_data_class != "SYNTHETIC":
            raise ValueError("SRA_ALLOW_DRAFT_STATEMENTS is only allowed with SYNTHETIC source data")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
