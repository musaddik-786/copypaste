"""Append-only, hash-chained audit ledger (ADR-005, CLAUDE.md invariant 11).

hash = sha256(prev_hash || canonical(envelope) || occurred_at)

* One global chain ordered by `event_seq`; the first event links to GENESIS (64 zeros).
* `envelope` = actor, case, entity, event type and payload - a superset of the `canonical(payload)` in the
  db/001 column comment, so changing *who* or *what* an event is about is detected too.
* canonical = sorted keys, compact separators, UTF-8; `occurred_at` = UTC ISO-8601 with microseconds, set by
  the application (not by the database default) so the exact hashed value is the stored value.
* Appends are serialised with a transaction-scoped advisory lock, so concurrent requests cannot fork the chain.
  The event is written in the caller's transaction: it commits or rolls back together with the state change.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Literal

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from sra_api import jsonutil
from sra_api.clock import utcnow
from sra_api.models import AuditEvent

GENESIS = "0" * 64
AUDIT_CHAIN_LOCK = 0x5352_4141_5544  # "SRAAUD" - arbitrary but fixed advisory lock key
ActorType = Literal["SYSTEM", "OFFICER", "RULE_ADMIN", "INTEGRATION"]


@dataclass(frozen=True)
class Actor:
    actor_type: ActorType
    actor_id: str


SYSTEM = Actor("SYSTEM", "sra-api")


def _ts(dt: datetime) -> str:
    return dt.astimezone(UTC).isoformat(timespec="microseconds")


def _envelope(e: AuditEvent) -> dict[str, Any]:
    return {"actor_type": e.actor_type, "actor_id": e.actor_id,
            "case_id": str(e.case_id) if e.case_id else None, "entity_type": e.entity_type,
            "entity_id": e.entity_id, "event_type": e.event_type, "payload": e.payload}


def event_hash(prev_hash: str, envelope: dict[str, Any], occurred_at: datetime) -> str:
    return jsonutil.sha256_hex(prev_hash + jsonutil.canonical(envelope) + _ts(occurred_at))


def append(session: Session, actor: Actor, *, entity_type: str, entity_id: str, event_type: str,
           payload: dict[str, Any], case_id: uuid.UUID | None = None) -> AuditEvent:
    """Append one event to the chain inside the caller's transaction."""
    session.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": AUDIT_CHAIN_LOCK})
    prev = session.execute(text("SELECT hash FROM audit.audit_event ORDER BY event_seq DESC LIMIT 1")).scalar()
    event = AuditEvent(occurred_at=utcnow(), actor_type=actor.actor_type, actor_id=actor.actor_id, case_id=case_id,
                       entity_type=entity_type, entity_id=entity_id, event_type=event_type,
                       payload=jsonutil.to_jsonable(payload), prev_hash=prev or GENESIS)
    event.hash = event_hash(event.prev_hash, _envelope(event), event.occurred_at)
    session.add(event)
    session.flush()
    return event


@dataclass(frozen=True)
class ChainVerification:
    valid: bool
    events_checked: int
    first_broken_seq: int | None = None
    reason: str | None = None


def verify_chain(session: Session) -> ChainVerification:
    """Recompute every hash and link from GENESIS. Any edit, deletion or re-ordering breaks the chain."""
    prev, n = GENESIS, 0
    for e in session.scalars(select(AuditEvent).order_by(AuditEvent.event_seq)):
        n += 1
        if e.prev_hash != prev:
            return ChainVerification(False, n, e.event_seq, "prev_hash does not link to the previous event")
        if event_hash(e.prev_hash, _envelope(e), e.occurred_at) != e.hash:
            return ChainVerification(False, n, e.event_seq, "hash does not match the event content")
        prev = e.hash
    return ChainVerification(True, n)
