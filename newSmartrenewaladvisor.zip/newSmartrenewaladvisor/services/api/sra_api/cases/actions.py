"""Officer work on a case: start review, Include / Skip / Defer, undo (reversal), deferred-item expiry.

Every mutation:
* locks the case row and checks optimistic concurrency (If-Match = case row_version; 412 if stale),
* moves the case only through `state_machine.transition` (409 on anything else),
* bumps row_version once and writes its audit events in the same transaction (invariant 11).
Nothing here touches a letter: Phase 5 composes letters from the recorded actions.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, date, datetime
from typing import Any

from sqlalchemy import delete, select, text
from sqlalchemy.orm import Session

from sra_api.admin.ruleset_store import load_published_ruleset
from sra_api.audit import ledger
from sra_api.cases import action_rules
from sra_api.cases.action_rules import RESOLVED_STATUSES, STATUS_FOR_ACTION, ActionRequest
from sra_api.cases.state_machine import IllegalTransition, OfficerEvent, transition
from sra_api.clock import utcnow
from sra_api.errors import ProblemError, not_found
from sra_api.models import OfficerAction, Recommendation, RecommendationDecline, RenewalCase

SURFACED = ("PRIMARY", "ALTERNATIVE")
ACTIONABLE_STATES = ("READY_FOR_REVIEW", "IN_REVIEW")
REVERSIBLE_STATES = ("IN_REVIEW", "DECIDED", "LETTER_DRAFTED")


@dataclass(frozen=True)
class CaseChange:
    case_id: uuid.UUID
    state: str
    row_version: int
    recommendation_id: uuid.UUID | None = None
    recommendation_status: str | None = None
    action_id: uuid.UUID | None = None
    action: str | None = None


# ----------------------------------------------------------------------------- helpers
def parse_if_match(value: str | None) -> int:
    """Accepts `7`, `"7"` or `W/"7"`. Missing -> 428 (the precondition is mandatory for every mutation)."""
    if value is None or not value.strip():
        raise ProblemError(428, "Precondition required", "send If-Match with the case rowVersion",
                           code="IF_MATCH_REQUIRED")
    raw = value.strip().removeprefix("W/").strip('"')
    if not raw.isdigit():
        raise ProblemError(400, "Bad If-Match", f"If-Match must be the case rowVersion, got {value!r}",
                           code="BAD_IF_MATCH")
    return int(raw)


def _lock_case(session: Session, case_id: uuid.UUID, if_match: int) -> RenewalCase:
    case = session.scalars(select(RenewalCase).where(RenewalCase.case_id == case_id).with_for_update()
                           .execution_options(populate_existing=True)).one_or_none()
    if case is None:
        raise not_found("Case", str(case_id))
    if case.row_version != if_match:
        raise ProblemError(412, "Precondition failed",
                           f"case changed since you loaded it (rowVersion {case.row_version}, you sent {if_match})",
                           code="STALE_ROW_VERSION", currentRowVersion=case.row_version)
    return case


def _move(session: Session, case: RenewalCase, event: OfficerEvent, actor: ledger.Actor) -> None:
    try:
        nxt = transition(case.state, event)
    except IllegalTransition as e:
        raise ProblemError(409, "Illegal state transition", str(e), code="ILLEGAL_TRANSITION",
                           state=case.state) from None
    if nxt != case.state:
        before, case.state = case.state, nxt
        ledger.append(session, actor, case_id=case.case_id, entity_type="CASE", entity_id=str(case.case_id),
                      event_type="STATE_CHANGED", payload={"from": before, "to": nxt, "event": event})


def _bump(session: Session, case: RenewalCase) -> None:
    case.row_version += 1
    case.updated_at = utcnow()
    session.flush()


def _surfaced(session: Session, case: RenewalCase) -> list[Recommendation]:
    return list(session.scalars(select(Recommendation).where(
        Recommendation.case_id == case.case_id, Recommendation.decision_run_id == case.current_decision_run_id,
        Recommendation.selection.in_(SURFACED), Recommendation.status != "SUPERSEDED")
        .order_by(Recommendation.rank)))


def _current_action(session: Session, rec_id: uuid.UUID) -> OfficerAction | None:
    """Latest INCLUDE/SKIP/DEFER on the recommendation that was not reversed (= v_recommendation_current_action)."""
    reversed_ids = select(OfficerAction.reverses_action_id).where(OfficerAction.reverses_action_id.is_not(None))
    return session.scalars(select(OfficerAction).where(
        OfficerAction.recommendation_id == rec_id, OfficerAction.action.in_(tuple(STATUS_FOR_ACTION)),
        OfficerAction.action_id.not_in(reversed_ids)).order_by(OfficerAction.acted_at.desc()).limit(1)).first()


def _reason_row(session: Session, table: str, code: str | None) -> dict[str, Any] | None:
    if not code:
        return None
    row = session.execute(text(f"SELECT * FROM ref.{table} WHERE reason_code = :c"), {"c": code}).mappings().first()
    return dict(row) if row else None


def _business_datetime(d: date) -> datetime:
    return datetime(d.year, d.month, d.day, 9, 0, tzinfo=UTC)


def expire_overdue_deferrals(session: Session, case: RenewalCase, today: date, actor: ledger.Actor) -> int:
    """ADR-012 / D-15: deferred items expire at the SLA cut-off - they will not be part of the letter."""
    if today < action_rules.sla_cutoff(case.letter_due_date):
        return 0
    n = 0
    for rec in _surfaced(session, case):
        if rec.status == "DEFERRED":
            rec.status = "EXPIRED"
            n += 1
            ledger.append(session, ledger.SYSTEM, case_id=case.case_id, entity_type="RECOMMENDATION",
                          entity_id=str(rec.recommendation_id), event_type="DEFERRAL_EXPIRED",
                          payload={"recommendation_ref": rec.recommendation_ref,
                                   "sla_cutoff": action_rules.sla_cutoff(case.letter_due_date).isoformat(),
                                   "triggered_by": actor.actor_id})
    session.flush()
    # Expiry can resolve the last open item of a case under review. (A case never opened goes straight to the
    # letter at the SLA cut-off - Phase 5 - so READY_FOR_REVIEW is left alone here.)
    if n and case.state == "IN_REVIEW" and all(r.status in RESOLVED_STATUSES for r in _surfaced(session, case)):
        _move(session, case, "ALL_ACTIONED", ledger.SYSTEM)
    return n


# ----------------------------------------------------------------------------- commands
def start_review(session: Session, case_id: uuid.UUID, if_match: int, actor: ledger.Actor) -> CaseChange:
    case = _lock_case(session, case_id, if_match)
    _move(session, case, "START_REVIEW", actor)
    _bump(session, case)
    return CaseChange(case.case_id, case.state, case.row_version)


def record_action(session: Session, rec_id: uuid.UUID, req: ActionRequest, if_match: int, actor: ledger.Actor,
                  *, today: date, jurisdiction: str, narrative_id_shown: uuid.UUID | None = None) -> CaseChange:
    rec = session.get(Recommendation, rec_id)
    if rec is None:
        raise not_found("Recommendation", str(rec_id))
    case = _lock_case(session, rec.case_id, if_match)
    session.refresh(rec)
    expire_overdue_deferrals(session, case, today, actor)

    if case.state not in ACTIONABLE_STATES:
        raise ProblemError(409, "Case not open for decisions", f"case is {case.state}", code="CASE_NOT_ACTIONABLE",
                           state=case.state)
    if (rec.decision_run_id != case.current_decision_run_id or rec.selection not in SURFACED
            or rec.status != "PENDING"):
        raise ProblemError(409, "Recommendation not actionable",
                           f"{rec.recommendation_ref} is {rec.status} ({rec.selection}); reverse the current "
                           "action first, or re-load the case", code="RECOMMENDATION_NOT_ACTIONABLE",
                           recommendationStatus=rec.status)

    skip = _reason_row(session, "skip_reason", req.skip_reason_code)
    defer = _reason_row(session, "defer_reason", req.defer_reason_code)
    findings = action_rules.validate(req, skip_reason=skip, defer_reason=defer, today=today,
                                     letter_due=case.letter_due_date)
    if narrative_id_shown is not None and session.execute(text(
            "SELECT 1 FROM sra.narrative WHERE narrative_id = :n AND recommendation_id = :r"),
            {"n": narrative_id_shown, "r": rec.recommendation_id}).first() is None:
        findings.append(action_rules.Finding("narrativeIdShown", "narrative does not belong to this recommendation"))
    if findings:
        raise ProblemError(422, "Invalid officer action", "; ".join(f.message for f in findings),
                           code="INVALID_ACTION", findings=[{"field": f.field, "message": f.message}
                                                            for f in findings])

    if case.state == "READY_FOR_REVIEW":
        _move(session, case, "START_REVIEW", actor)

    act = OfficerAction(recommendation_id=rec.recommendation_id, case_id=case.case_id, action=req.action,
                        skip_reason_code=req.skip_reason_code, defer_reason_code=req.defer_reason_code,
                        follow_up_at=_business_datetime(req.follow_up_on) if req.follow_up_on else None,
                        comment=(req.comment or None), narrative_id_shown=narrative_id_shown,
                        acted_by=actor.actor_id, acted_at=utcnow())
    session.add(act)
    rec.status = STATUS_FOR_ACTION[req.action]
    session.flush()
    ledger.append(session, actor, case_id=case.case_id, entity_type="RECOMMENDATION",
                  entity_id=str(rec.recommendation_id), event_type=rec.status,
                  payload={"action_id": str(act.action_id), "recommendation_ref": rec.recommendation_ref,
                           "action": req.action, "skip_reason_code": req.skip_reason_code,
                           "defer_reason_code": req.defer_reason_code,
                           "follow_up_on": req.follow_up_on.isoformat() if req.follow_up_on else None,
                           "data_fix_requested": bool(skip and skip.get("triggers_data_fix")),
                           "narrative_id_shown": str(narrative_id_shown) if narrative_id_shown else None})

    if req.action == "SKIP" and skip and skip.get("creates_cooldown"):
        catalog = load_published_ruleset(session, jurisdiction).catalog
        decline = RecommendationDecline(
            customer_id=case.customer_id, product_code=rec.product_code, declined_at=today, source="OFFICER_SKIP",
            recommendation_id=rec.recommendation_id,
            cooldown_until=action_rules.add_months(today, action_rules.cooldown_months(rec.product_code, catalog)))
        session.add(decline)
        session.flush()
        ledger.append(session, actor, case_id=case.case_id, entity_type="DECLINE", entity_id=str(decline.decline_id),
                      event_type="DECLINE_RECORDED",
                      payload={"product_code": decline.product_code, "declined_at": today.isoformat(),
                               "cooldown_until": decline.cooldown_until.isoformat(),
                               "skip_reason_code": req.skip_reason_code})

    all_resolved = all(r.status in RESOLVED_STATUSES for r in _surfaced(session, case))
    _move(session, case, "ALL_ACTIONED" if all_resolved else "ACTION", actor)
    _bump(session, case)
    return CaseChange(case.case_id, case.state, case.row_version, rec.recommendation_id, rec.status,
                      act.action_id, act.action)


def reverse_action(session: Session, rec_id: uuid.UUID, action_id: uuid.UUID, if_match: int,
                   actor: ledger.Actor, *, today: date) -> CaseChange:
    rec = session.get(Recommendation, rec_id)
    if rec is None:
        raise not_found("Recommendation", str(rec_id))
    case = _lock_case(session, rec.case_id, if_match)
    session.refresh(rec)
    expire_overdue_deferrals(session, case, today, actor)
    if case.state not in REVERSIBLE_STATES:
        raise ProblemError(409, "Case not open for undo", f"case is {case.state}", code="CASE_NOT_REVERSIBLE",
                           state=case.state)
    target = session.get(OfficerAction, action_id)
    if target is None or target.recommendation_id != rec.recommendation_id:
        raise not_found("Action", str(action_id))
    current = _current_action(session, rec.recommendation_id)
    if current is None or current.action_id != target.action_id or rec.status not in ("INCLUDED", "SKIPPED",
                                                                                         "DEFERRED"):
        raise ProblemError(409, "Action not reversible",
                           "only the current, not yet reversed action of a live recommendation can be undone",
                           code="ACTION_NOT_REVERSIBLE")

    undo = OfficerAction(recommendation_id=rec.recommendation_id, case_id=case.case_id, action="REVERSAL",
                         reverses_action_id=target.action_id, acted_by=actor.actor_id, acted_at=utcnow())
    session.add(undo)
    previous, rec.status = rec.status, "PENDING"
    session.flush()
    ledger.append(session, actor, case_id=case.case_id, entity_type="RECOMMENDATION",
                  entity_id=str(rec.recommendation_id), event_type="REVERSED",
                  payload={"action_id": str(undo.action_id), "reverses_action_id": str(target.action_id),
                           "recommendation_ref": rec.recommendation_ref, "previous_status": previous})
    if target.action == "SKIP":
        # An undone skip is no longer a customer decline: remove its cooldown (the audit keeps the history).
        removed = session.scalars(delete(RecommendationDecline).where(
            RecommendationDecline.recommendation_id == rec.recommendation_id,
            RecommendationDecline.source == "OFFICER_SKIP").returning(RecommendationDecline.decline_id)).all()
        for decline_id in removed:
            ledger.append(session, actor, case_id=case.case_id, entity_type="DECLINE", entity_id=str(decline_id),
                          event_type="DECLINE_REVOKED", payload={"reverses_action_id": str(target.action_id)})
    if case.state == "LETTER_DRAFTED":
        cancel_drafts(session, case, actor, "officer undid a decision")
    _move(session, case, "REVERSAL", actor)
    _bump(session, case)
    return CaseChange(case.case_id, case.state, case.row_version, rec.recommendation_id, rec.status,
                      undo.action_id, undo.action)


def cancel_drafts(session: Session, case: RenewalCase, actor: ledger.Actor, reason: str) -> int:
    """A changed decision invalidates any letter draft (approved letters cannot reach here: window closed)."""
    ids = session.execute(text("UPDATE sra.letter_draft SET status = 'CANCELLED' WHERE case_id = :c "
                               "AND status = 'DRAFT' RETURNING letter_id"), {"c": case.case_id}).scalars().all()
    for letter_id in ids:
        ledger.append(session, actor, case_id=case.case_id, entity_type="LETTER", entity_id=str(letter_id),
                      event_type="LETTER_CANCELLED", payload={"reason": reason})
    return len(ids)


# Public names for other modules that mutate a case (e.g. narrative edits) under the same locking rules.
lock_case = _lock_case
bump = _bump


def change_as_dict(c: CaseChange) -> dict[str, Any]:
    out: dict[str, Any] = {"caseId": str(c.case_id), "caseState": c.state, "rowVersion": c.row_version}
    if c.recommendation_id is not None:
        out.update({"recommendationId": str(c.recommendation_id), "recommendationStatus": c.recommendation_status,
                    "actionId": str(c.action_id), "action": c.action})
    return out
