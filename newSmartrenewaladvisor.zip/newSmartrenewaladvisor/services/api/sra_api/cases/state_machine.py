"""Case lifecycle (docs/diagrams/03_case_state_machine.dot) as explicit, testable tables.

Evaluation (Phase 2) uses `state_after_decision`; officer work (Phase 3) uses `transition`. Any move that is
not in the table raises IllegalTransition (HTTP 409). Letter states (Phase 5) are added there.
"""
from __future__ import annotations

from collections.abc import Iterable
from typing import Literal

# Once the letter is approved or dispatched the operational window is closed: no re-evaluation (409).
WINDOW_CLOSED_STATES = frozenset({"LETTER_APPROVED", "DISPATCHED", "CLOSED"})
DISPATCHED_STATES = frozenset({"DISPATCHED", "CLOSED"})

_STATE_FOR_DECISION = {"NOT_TRIGGERED": "NOT_TRIGGERED", "SUPPRESSED": "SUPPRESSED",
                       "NO_OPPORTUNITY": "EVALUATED", "RECOMMENDATIONS_AVAILABLE": "READY_FOR_REVIEW"}

OfficerEvent = Literal["START_REVIEW", "ACTION", "ALL_ACTIONED", "REVERSAL", "COMPOSE", "SLA_CUTOFF", "APPROVE",
                       "DISPATCH"]

# (current state, event) -> next state. Everything else is illegal.
OFFICER_TRANSITIONS: dict[tuple[str, OfficerEvent], str] = {
    ("READY_FOR_REVIEW", "START_REVIEW"): "IN_REVIEW",   # officer opens the case
    ("IN_REVIEW", "ACTION"): "IN_REVIEW",                # some recommendations still open
    ("IN_REVIEW", "ALL_ACTIONED"): "DECIDED",            # every surfaced recommendation resolved
    ("IN_REVIEW", "REVERSAL"): "IN_REVIEW",              # undo while still reviewing
    ("DECIDED", "REVERSAL"): "IN_REVIEW",                # undo (logged) re-opens the review
    ("LETTER_DRAFTED", "REVERSAL"): "IN_REVIEW",         # undo after drafting cancels the draft
    # Phase 5 - letters
    ("DECIDED", "COMPOSE"): "LETTER_DRAFTED",
    ("SUPPRESSED", "COMPOSE"): "LETTER_DRAFTED",         # standard renewal notice only
    ("EVALUATED", "COMPOSE"): "LETTER_DRAFTED",          # no opportunity -> standard notice
    ("LETTER_DRAFTED", "COMPOSE"): "LETTER_DRAFTED",     # re-compose after an edit
    ("READY_FOR_REVIEW", "SLA_CUTOFF"): "LETTER_DRAFTED",  # cut-off: open items are not included (logged)
    ("IN_REVIEW", "SLA_CUTOFF"): "LETTER_DRAFTED",
    ("LETTER_DRAFTED", "APPROVE"): "LETTER_APPROVED",    # officer approves; PDF + hash frozen
    ("LETTER_APPROVED", "DISPATCH"): "DISPATCHED",       # handed to output management; window closed
}


class IllegalTransition(ValueError):
    def __init__(self, state: str, event: str) -> None:
        super().__init__(f"{event} is not allowed when the case is {state}")
        self.state, self.event = state, event


def transition(state: str, event: OfficerEvent) -> str:
    try:
        return OFFICER_TRANSITIONS[(state, event)]
    except KeyError:
        raise IllegalTransition(state, event) from None


def state_after_decision(decision_status: str, current_state: str) -> str:
    """Case state after a decision run. An officer already reviewing keeps reviewing (stale re-evaluation)."""
    if current_state in WINDOW_CLOSED_STATES:
        raise ValueError(f"case in {current_state} cannot be re-evaluated")
    nxt = _STATE_FOR_DECISION[decision_status]
    if nxt == "READY_FOR_REVIEW" and current_state == "IN_REVIEW":
        return "IN_REVIEW"
    return nxt


def opportunity_signal(decision_status: str, surfaced_types: Iterable[str]) -> str:
    """Queue badge: NONE / UPSELL / CROSS_SELL / UPSELL_AND_CROSS_SELL / MULTI_* / SUPPRESSED."""
    if decision_status == "SUPPRESSED":
        return "SUPPRESSED"
    types = list(surfaced_types)
    ups, cross = types.count("UPSELL"), types.count("CROSS_SELL")
    if ups and cross:
        return "UPSELL_AND_CROSS_SELL"
    if ups:
        return "MULTI_UPSELL" if ups > 1 else "UPSELL"
    if cross:
        return "MULTI_CROSS_SELL" if cross > 1 else "CROSS_SELL"
    return "NONE"
