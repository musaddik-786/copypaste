"""Pure rules for officer actions (BR-10 / BR-11, ADR-012). No I/O, no clock: dates are passed in.

* SKIP needs an active reason; some reasons also need a comment.
* DEFER needs a reason and a follow-up date that is in the future, within the reason's `max_defer_days`
  and no later than the SLA cut-off (letter due date minus one working day). Deferred items expire there.
* A SKIP whose reason `creates_cooldown` counts as a customer decline (EL-03); the cooldown length comes
  from the ruleset parameters for the product's cooldown class - never from code (ADR-002).
"""
from __future__ import annotations

import calendar
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any, Literal

ActionType = Literal["INCLUDE", "SKIP", "DEFER"]
STATUS_FOR_ACTION = {"INCLUDE": "INCLUDED", "SKIP": "SKIPPED", "DEFER": "DEFERRED"}
RESOLVED_STATUSES = frozenset({"INCLUDED", "SKIPPED", "DEFERRED", "EXPIRED"})  # count towards DECIDED
WEEKEND = (5, 6)


@dataclass(frozen=True)
class ActionRequest:
    action: ActionType
    skip_reason_code: str | None = None
    defer_reason_code: str | None = None
    follow_up_on: date | None = None
    comment: str | None = None


@dataclass(frozen=True)
class Finding:
    field: str
    message: str


def sla_cutoff(letter_due: date) -> date:
    """One working day (Mon-Fri) before the letter due date. Public holidays are not modelled in the POC."""
    d = letter_due - timedelta(days=1)
    while d.weekday() in WEEKEND:
        d -= timedelta(days=1)
    return d


def add_months(d: date, months: int) -> date:
    """Calendar months later; clamps to the month's last day (31 Jan + 1 month = 28/29 Feb)."""
    y, m = divmod(d.year * 12 + d.month - 1 + months, 12)
    month = m + 1
    return date(y, month, min(d.day, calendar.monthrange(y, month)[1]))


def cooldown_months(product_code: str, catalog: Mapping[str, Any]) -> int:
    """Same class lookup as the engine's EL-03 (unknown products get the longer companion cooldown)."""
    cls = catalog["products"].get(product_code, {}).get("cooldown_class", "COMPANION")
    key = "cooldown_rider_months" if cls == "RIDER" else "cooldown_companion_months"
    value: int = catalog["parameters"][key]["value"]
    return value


def validate(req: ActionRequest, *, skip_reason: Mapping[str, Any] | None,
             defer_reason: Mapping[str, Any] | None, today: date, letter_due: date) -> list[Finding]:
    """Returns every problem with the request (empty list = valid). Reason rows come from ref.*."""
    out: list[Finding] = []
    comment = (req.comment or "").strip()
    if req.action == "INCLUDE":
        if req.skip_reason_code or req.defer_reason_code or req.follow_up_on:
            out.append(Finding("action", "INCLUDE takes no skip/defer reason or follow-up date"))
    elif req.action == "SKIP":
        if req.defer_reason_code or req.follow_up_on:
            out.append(Finding("action", "SKIP takes no defer reason or follow-up date"))
        if not req.skip_reason_code:
            out.append(Finding("skipReasonCode", "a skip reason is mandatory (BR-11)"))
        elif skip_reason is None or not skip_reason.get("active"):
            out.append(Finding("skipReasonCode", f"unknown or inactive skip reason {req.skip_reason_code!r}"))
        elif skip_reason.get("requires_comment") and not comment:
            out.append(Finding("comment", f"skip reason {req.skip_reason_code} requires a comment"))
    elif req.action == "DEFER":
        if req.skip_reason_code:
            out.append(Finding("action", "DEFER takes no skip reason"))
        if not req.defer_reason_code:
            out.append(Finding("deferReasonCode", "a defer reason is mandatory"))
        elif defer_reason is None:
            out.append(Finding("deferReasonCode", f"unknown defer reason {req.defer_reason_code!r}"))
        cutoff = sla_cutoff(letter_due)
        if req.follow_up_on is None:
            out.append(Finding("followUpAt", "a follow-up date is mandatory for DEFER"))
        elif req.follow_up_on <= today:
            out.append(Finding("followUpAt", "the follow-up date must be in the future"))
        else:
            if defer_reason is not None and req.follow_up_on > today + timedelta(days=defer_reason["max_defer_days"]):
                out.append(Finding("followUpAt", f"{req.defer_reason_code} allows at most "
                                                 f"{defer_reason['max_defer_days']} days"))
            if req.follow_up_on > cutoff:
                out.append(Finding("followUpAt", f"the follow-up date is after the SLA cut-off {cutoff.isoformat()}"))
    else:
        out.append(Finding("action", f"unsupported action {req.action!r}"))
    return out
