"""Read models for the console (SQLAlchemy Core). Money leaves the API as a 2-dp string, never a float."""
from __future__ import annotations

import uuid
from datetime import date
from decimal import Decimal
from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from sra_api.cases.action_rules import sla_cutoff
from sra_api.errors import not_found
from sra_api.narrative.service import render, tokens_for

PAGE_SIZE = 25
PENDING_REVIEW_STATES = ("READY_FOR_REVIEW", "IN_REVIEW", "DECIDED", "LETTER_DRAFTED")
SURFACED = ("PRIMARY", "ALTERNATIVE")


def money(v: Decimal | None) -> str | None:
    return None if v is None else f"{v:.2f}"


def _iso(v: date | None) -> str | None:
    return v.isoformat() if v else None


# Quotes in the operational window (not yet past the letter due date), plus any quote that already has a case.
_QUEUE_SQL = """
SELECT q.quote_id, q.policy_id, p.customer_id, cu.full_name, p.lob_code, q.renewal_date, q.letter_due_date,
       q.expiring_premium_gross, q.renewal_premium_gross,
       rc.case_id, rc.state, rc.opportunity_signal, rc.suppression_reason_codes,
       COALESCE(v.build_year || ' ' || v.make_model,
                initcap(replace(pr.dwelling_type, '_', ' ')) || ', built ' || pr.build_year,
                an.species || ' (' || an.breed || ')', p.base_product_code) AS asset_summary,
       CASE WHEN rc.case_id IS NULL THEN 'PENDING_REVIEW'
            WHEN rc.state = ANY(:pending) THEN 'PENDING_REVIEW'
            WHEN rc.state = 'SUPPRESSED' THEN 'CONDUCT_HOLD'
            WHEN rc.state IN ('DISPATCHED', 'CLOSED') THEN 'DISPATCHED'
            ELSE 'OTHER' END AS queue_status
FROM src.renewal_quote q
JOIN src.policy p ON p.policy_id = q.policy_id
JOIN src.customer cu ON cu.customer_id = p.customer_id
LEFT JOIN sra.renewal_case rc ON rc.quote_id = q.quote_id
LEFT JOIN src.insured_vehicle v ON v.policy_id = p.policy_id
LEFT JOIN src.insured_property pr ON pr.policy_id = p.policy_id
LEFT JOIN LATERAL (SELECT species, breed FROM src.insured_animal a WHERE a.policy_id = p.policy_id
                   ORDER BY animal_ref LIMIT 1) an ON true
WHERE (q.status = 'QUOTED' AND q.letter_due_date >= :as_of) OR rc.case_id IS NOT NULL
"""


def _queue_rows(session: Session, as_of: date) -> list[dict[str, Any]]:
    rows = session.execute(text(_QUEUE_SQL + " ORDER BY q.letter_due_date, q.quote_id"),
                           {"as_of": as_of, "pending": list(PENDING_REVIEW_STATES)}).mappings()
    return [dict(r) for r in rows]


def queue(session: Session, as_of: date, *, q: str | None = None, lob: str | None = None,
          status: str = "ALL", page: int = 1) -> dict[str, Any]:
    rows = _queue_rows(session, as_of)
    if q:
        needle = q.lower()
        rows = [r for r in rows if any(needle in str(r[k]).lower()
                                       for k in ("full_name", "policy_id", "customer_id", "quote_id"))]
    if lob:
        rows = [r for r in rows if r["lob_code"] == lob]
    if status != "ALL":
        rows = [r for r in rows if r["queue_status"] == status]
    start = (max(page, 1) - 1) * PAGE_SIZE
    items = [{"quoteId": r["quote_id"], "caseId": str(r["case_id"]) if r["case_id"] else None,
              "policyId": r["policy_id"], "customerRef": r["customer_id"], "customerName": r["full_name"],
              "lob": r["lob_code"], "assetSummary": r["asset_summary"],
              "expiringPremium": money(r["expiring_premium_gross"]),
              "renewalPremium": money(r["renewal_premium_gross"]),
              "renewalDate": _iso(r["renewal_date"]), "letterDueDate": _iso(r["letter_due_date"]),
              "daysToLetterDue": (r["letter_due_date"] - as_of).days,
              "state": r["state"], "evaluated": r["case_id"] is not None,
              "opportunitySignal": r["opportunity_signal"],
              "suppressionReasons": list(r["suppression_reason_codes"] or []),
              "queueStatus": r["queue_status"]} for r in rows[start:start + PAGE_SIZE]]
    return {"items": items, "total": len(rows), "page": max(page, 1), "pageSize": PAGE_SIZE}


def kpis(session: Session, as_of: date) -> dict[str, int]:
    rows = _queue_rows(session, as_of)
    return {"total": len(rows),
            "pendingReview": sum(r["queue_status"] == "PENDING_REVIEW" for r in rows),
            "conductHold": sum(r["queue_status"] == "CONDUCT_HOLD" for r in rows),
            "dispatched": sum(r["queue_status"] == "DISPATCHED" for r in rows)}


def _case_row(session: Session, case_id: uuid.UUID) -> dict[str, Any]:
    row = session.execute(text("SELECT * FROM sra.renewal_case WHERE case_id = :c"), {"c": case_id}).mappings().first()
    if row is None:
        raise not_found("Case", str(case_id))
    return dict(row)


def case_detail(session: Session, case_id: uuid.UUID) -> dict[str, Any]:
    c = _case_row(session, case_id)
    run = session.execute(text(
        "SELECT dr.decision_run_id, dr.status, dr.suppression_reasons, dr.ruleset_version, dr.as_of, dr.created_at, "
        "       ps.snapshot_id, ps.decision_context, ps.captured_at "
        "FROM sra.decision_run dr JOIN sra.policy_snapshot ps USING (snapshot_id) "
        "WHERE dr.decision_run_id = :r"), {"r": c["current_decision_run_id"]}).mappings().first()
    flags: list[dict[str, Any]] = []
    if run is not None:
        flags = [dict(f) for f in session.execute(text(
            "SELECT fact_path AS \"factPath\", quality, source_system AS \"sourceSystem\" FROM sra.snapshot_fact "
            "WHERE snapshot_id = :s AND quality <> 'OK' ORDER BY fact_path"), {"s": run["snapshot_id"]}).mappings()]
    ctx = run["decision_context"] if run else {}
    return {
        "caseId": str(c["case_id"]), "quoteId": c["quote_id"], "policyId": c["policy_id"],
        "customerRef": c["customer_id"], "customerName": c["customer_display_name"], "lob": c["lob_code"],
        "state": c["state"], "opportunitySignal": c["opportunity_signal"],
        "suppressionReasons": list(c["suppression_reason_codes"]), "rowVersion": c["row_version"],
        "renewalDate": _iso(c["renewal_date"]), "letterDueDate": _iso(c["letter_due_date"]),
        "slaCutoffDate": _iso(sla_cutoff(c["letter_due_date"])),  # deferred items expire here
        "expiringPremium": money(c["expiring_premium"]), "renewalPremium": money(c["renewal_premium"]),
        "decision": None if run is None else {
            "decisionRunId": str(run["decision_run_id"]), "status": run["status"],
            "suppressionReasons": list(run["suppression_reasons"]), "rulesetVersion": run["ruleset_version"],
            "asOf": _iso(run["as_of"]), "evaluatedAt": run["created_at"].isoformat()},
        # Panels for the policy-details screen; the context holds facts only (no names or addresses).
        "panels": {k: ctx.get(k) for k in ("customer", "policy", "vehicle", "motor", "property", "pet", "claims",
                                            "portfolio", "conduct", "consent", "external") if k in ctx},
        "dataQualityFlags": flags,
    }


def _evidence(clauses: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for cl in clauses:
        right = cl["right_value"] if isinstance(cl["right"], str) and cl["right"].startswith("params.") \
            else cl["right"]
        out.append({"label": cl["left"], "value": cl["left_value"],
                    "condition": f"{cl['left']} {cl['op']} {right}", "result": cl["result"]})
    return out


def _narratives(session: Session, rec_ids: list[uuid.UUID], language: str) -> dict[tuple[str, str], Any]:
    """Latest PASSED narrative per (recommendation, audience). Unvalidated text is never returned (invariant 9)."""
    if not rec_ids:
        return {}
    rows = session.execute(text(
        "SELECT DISTINCT ON (n.recommendation_id, n.audience) n.*, "
        "  COALESCE((SELECT jsonb_agg(f) FROM sra.narrative_validation v, jsonb_array_elements(v.findings) f "
        "            WHERE v.narrative_id = n.narrative_id AND f ->> 'severity' = 'WARN'), '[]') AS warnings "
        "FROM sra.narrative n WHERE n.recommendation_id = ANY(:ids) AND n.language = :l "
        "AND n.validation_status = 'PASSED' ORDER BY n.recommendation_id, n.audience, n.version DESC"),
        {"ids": rec_ids, "l": language}).mappings()
    return {(str(r["recommendation_id"]), r["audience"]): r for r in rows}


def _narrative_card(officer: Any, letter: Any, tokens: dict[str, str]) -> dict[str, Any] | None:
    if officer is None and letter is None:
        return None
    o = officer["content"] if officer is not None else {}
    lt = letter["content"] if letter is not None else {}
    origin = officer["origin"] if officer is not None else letter["origin"]
    card: dict[str, Any] = render({
        "narrativeId": str(officer["narrative_id"]) if officer is not None else None,
        "letterNarrativeId": str(letter["narrative_id"]) if letter is not None else None,
        "whyRecommended": o.get("why_recommended"), "currentGap": o.get("current_gap"),
        "howItHelps": o.get("how_it_helps"),
        "keyBenefits": [b["text"] for b in o.get("key_benefits") or []],
        "comparisonRows": o.get("comparison_rows") or [],
        "letterRationale": lt.get("letter_rationale"),
        "origin": origin, "aiGenerated": origin == "LLM",
        "standardWording": origin == "TEMPLATE_FALLBACK",
        "draftWording": bool(o.get("draft_wording") or lt.get("draft_wording")),
        "warnings": list((officer or {}).get("warnings") or []) + list((letter or {}).get("warnings") or []),
    }, tokens)
    return card


def recommendation_cards(session: Session, case_id: uuid.UUID, language: str = "en") -> list[dict[str, Any]]:
    c = _case_row(session, case_id)
    if c["current_decision_run_id"] is None:
        return []
    rows = session.execute(text(
        "SELECT r.*, p.name_en, ps.expiring_premium, ps.base_renewal_premium, ps.upsell_increment_annual, "
        "       ps.companion_standalone_annual, ps.bundle_discount_pct, ps.bundle_saving_annual, "
        "       ps.net_annual_total, ps.monthly_equivalent, re.clauses, "
        "       ca.action_id AS ca_action_id, ca.action AS ca_action, ca.skip_reason_code AS ca_skip, "
        "       ca.defer_reason_code AS ca_defer, ca.follow_up_at AS ca_follow_up, ca.comment AS ca_comment, "
        "       ca.acted_by AS ca_by, ca.acted_at AS ca_at "
        "FROM sra.recommendation r "
        "LEFT JOIN sra.v_recommendation_current_action ca ON ca.recommendation_id = r.recommendation_id "
        "JOIN ref.product p ON p.product_code = r.product_code "
        "JOIN sra.pricing_scenario ps ON ps.decision_run_id = r.decision_run_id "
        "     AND ps.included_recommendation_ids = ARRAY[r.recommendation_id] "
        "LEFT JOIN sra.rule_evaluation re ON re.decision_run_id = r.decision_run_id AND re.rule_id = r.rule_id "
        "WHERE r.decision_run_id = :run AND r.selection = ANY(:surfaced) AND r.status <> 'SUPERSEDED' "
        "ORDER BY r.rank"), {"run": c["current_decision_run_id"], "surfaced": list(SURFACED)}).mappings().all()
    texts = _narratives(session, [r["recommendation_id"] for r in rows], language)
    tokens = tokens_for(session, case_id)
    cards = []
    for r in rows:
        upsell = r["opportunity_type"] == "UPSELL"
        increment = r["upsell_increment_annual"] if upsell else r["companion_standalone_annual"]
        cards.append({
            "recommendationId": str(r["recommendation_id"]), "recommendationRef": r["recommendation_ref"],
            "opportunityType": r["opportunity_type"], "selection": r["selection"], "rank": r["rank"],
            "ruleId": r["rule_id"], "productCode": r["product_code"], "priorityTier": r["priority_tier"],
            "title": r["name_en"],
            "subtitle": "Recommended Coverage" if upsell else "Recommended Policy",
            "narrative": _narrative_card(texts.get((str(r["recommendation_id"]), "OFFICER")),
                                         texts.get((str(r["recommendation_id"]), "CUSTOMER_LETTER")), tokens),
            "pricing": {
                "expiringPremium": money(r["expiring_premium"]),
                "baseRenewalPremium": money(r["base_renewal_premium"]),
                "incrementalAnnual": money(increment),
                "incrementalMonthlyEquivalent": money(r["monthly_equivalent"]),
                "companionStandaloneAnnual": None if upsell else money(r["companion_standalone_annual"]),
                "bundleDiscountPct": f"{r['bundle_discount_pct'].normalize():f}",
                "bundleSavingAnnual": money(r["bundle_saving_annual"]),
                "netAnnualTotal": money(r["net_annual_total"]),
                "presentation": "CONSOLIDATED_INTO_RENEWAL" if upsell else "SEPARATE_POLICY_ITEMISED"},
            "evidence": _evidence(r["clauses"] or []),
            "status": r["status"],
            # The live officer decision (actionId is what the console sends to undo it).
            "currentAction": None if r["ca_action_id"] is None or r["status"] in ("PENDING", "EXPIRED") else {
                "actionId": str(r["ca_action_id"]), "action": r["ca_action"],
                "skipReasonCode": r["ca_skip"], "deferReasonCode": r["ca_defer"],
                "followUpAt": r["ca_follow_up"].isoformat() if r["ca_follow_up"] else None,
                "comment": r["ca_comment"], "actedBy": r["ca_by"], "actedAt": r["ca_at"].isoformat()}})
    return cards


def decision_trace(session: Session, decision_run_id: uuid.UUID) -> dict[str, Any]:
    run = session.execute(text("SELECT * FROM sra.decision_run WHERE decision_run_id = :r"),
                          {"r": decision_run_id}).mappings().first()
    if run is None:
        raise not_found("Decision run", str(decision_run_id))
    evals = session.execute(text("SELECT seq, rule_id, stage, product_code, outcome, detail, clauses "
                                 "FROM sra.rule_evaluation WHERE decision_run_id = :r ORDER BY seq"),
                            {"r": decision_run_id}).mappings()
    return {"decisionRunId": str(run["decision_run_id"]), "caseId": str(run["case_id"]),
            "snapshotId": str(run["snapshot_id"]), "status": run["status"],
            "suppressionReasons": list(run["suppression_reasons"]), "rulesetVersion": run["ruleset_version"],
            "engineVersion": run["engine_version"], "trigger": run["trigger"], "asOf": _iso(run["as_of"]),
            "inputSha256": run["input_sha256"], "outputSha256": run["output_sha256"],
            "durationMs": run["duration_ms"], "requestedBy": run["requested_by"],
            "createdAt": run["created_at"].isoformat(),
            "evaluations": [{"seq": e["seq"], "ruleId": e["rule_id"], "stage": e["stage"],
                             "productCode": e["product_code"], "outcome": e["outcome"], "detail": e["detail"],
                             "clauses": e["clauses"]} for e in evals]}
