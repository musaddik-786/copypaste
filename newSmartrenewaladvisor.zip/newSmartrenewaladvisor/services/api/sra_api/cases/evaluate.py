"""`POST /renewal-quotes/{quoteId}/evaluations` - "Generate Possible Opportunities" (CLAUDE.md request flow).

All steps run in the caller's single transaction, so a case, its snapshot, decision run, trace,
recommendations, pricing and audit events are either all written or none are (invariant 11).

1. create sra.renewal_case if new (idempotent on quote_id; row-locked so concurrent clicks serialise)
2. pull the snapshot via the adapter ports and build the Decision Context (Fact Builder)
3. if neither the context nor the published ruleset changed since the latest run -> return that run (no writes)
4. otherwise: immutable policy_snapshot (+ snapshot_fact), decision_run (+ rule_evaluation)
5. supersede previous open recommendations; persist the surfaced ones with their pricing scenario
6. move the case state; audit every change
7. generate the narratives for the new cards (Narrative Service, validators, template fallback)
"""
from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass
from datetime import date
from typing import Any

import sra_rules
from sqlalchemy import select, text, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session
from sra_rules.hashing import canonical_hash

from sra_api import jsonutil
from sra_api.adapters.ports import SourceSnapshot, collect_source
from sra_api.adapters.src_mock import SraReference, SrcMockClaims, SrcMockCrm, SrcMockPas
from sra_api.admin.ruleset_store import load_published_ruleset
from sra_api.audit import ledger
from sra_api.cases.actions import cancel_drafts
from sra_api.cases.state_machine import (
    DISPATCHED_STATES,
    WINDOW_CLOSED_STATES,
    opportunity_signal,
    state_after_decision,
)
from sra_api.clock import utcnow
from sra_api.decisioning.ruleset import LoadedRuleset
from sra_api.decisioning.service import ENGINE_VERSION, PRICING_CALC_VERSION, Decision, decide
from sra_api.errors import ProblemError, not_found
from sra_api.factbuilder.builder import FACT_BUILDER_VERSION, BuiltContext, build_context
from sra_api.models import (
    DecisionRun,
    PolicySnapshot,
    PricingScenario,
    Recommendation,
    RenewalCase,
    RuleEvaluation,
    SnapshotFact,
)
from sra_api.narrative import service as narrative_service
from sra_api.pricing.persist import scenario_values
from sra_api.settings import get_settings

SURFACED = ("PRIMARY", "ALTERNATIVE")
OPEN_RECOMMENDATION_STATUSES = ("PENDING", "INCLUDED", "SKIPPED", "DEFERRED")


@dataclass(frozen=True)
class EvaluationOutcome:
    case_id: uuid.UUID
    quote_id: str
    decision_run_id: uuid.UUID
    status: str
    suppression_reasons: list[str]
    ruleset_version: str
    as_of: date
    reused_previous_run: bool
    case_created: bool


def _get_or_create_case(session: Session, snap: SourceSnapshot, actor: ledger.Actor) -> tuple[RenewalCase, bool]:
    q, p, c = snap.quote, snap.policy, snap.customer
    inserted = session.execute(
        insert(RenewalCase).values(
            quote_id=q["quote_id"], policy_id=p["policy_id"], customer_id=c["customer_id"], lob_code=p["lob_code"],
            customer_display_name=c["full_name"], renewal_date=q["renewal_date"],
            letter_due_date=q["letter_due_date"], expiring_premium=q["expiring_premium_gross"],
            renewal_premium=q["renewal_premium_gross"], state="RECEIVED",
        ).on_conflict_do_nothing(index_elements=["quote_id"]).returning(RenewalCase.case_id)
    ).scalar_one_or_none()
    # Row lock: a second click on the same quote waits here until the first evaluation commits.
    case = session.scalars(select(RenewalCase).where(RenewalCase.quote_id == q["quote_id"])
                           .with_for_update().execution_options(populate_existing=True)).one()
    if inserted is not None:
        ledger.append(session, actor, case_id=case.case_id, entity_type="CASE", entity_id=str(case.case_id),
                      event_type="CASE_CREATED", payload={"quote_id": case.quote_id, "policy_id": case.policy_id,
                                                          "state": case.state})
    return case, inserted is not None


def _latest_run(session: Session, case_id: uuid.UUID) -> DecisionRun | None:
    return session.scalars(select(DecisionRun).where(DecisionRun.case_id == case_id)
                           .order_by(DecisionRun.created_at.desc(), DecisionRun.decision_run_id).limit(1)).first()


def _next_recommendation_ref(session: Session, as_of: date) -> str:
    n = session.execute(text("SELECT nextval('sra.recommendation_ref_seq')")).scalar_one()
    return f"REC-{as_of.year}-{n:04d}"


def _persist_run(session: Session, case: RenewalCase, snap: SourceSnapshot, built: BuiltContext,
                 ruleset: LoadedRuleset, decision: Decision, as_of: date, actor: ledger.Actor,
                 request_id: str | None) -> DecisionRun:
    result = decision.result
    snapshot = PolicySnapshot(case_id=case.case_id, request_id=request_id,
                              raw_payload=jsonutil.to_jsonable(asdict(snap)),
                              decision_context=jsonutil.to_jsonable(built.context),
                              context_sha256=result.input_hash, fact_builder_version=FACT_BUILDER_VERSION)
    session.add(snapshot)
    session.flush()
    session.add_all(SnapshotFact(snapshot_id=snapshot.snapshot_id, fact_path=f.path,
                                 value=jsonutil.to_jsonable(f.value), quality=f.quality,
                                 source_system=f.source_system, as_of=as_of) for f in built.facts)
    run = DecisionRun(case_id=case.case_id, snapshot_id=snapshot.snapshot_id, ruleset_version=ruleset.version,
                      engine_version=ENGINE_VERSION, trigger="OFFICER_REQUEST", as_of=as_of, status=result.status,
                      suppression_reasons=list(result.suppression_reasons), input_sha256=result.input_hash,
                      output_sha256=decision.output_sha256, duration_ms=decision.duration_ms,
                      requested_by=actor.actor_id)
    session.add(run)
    session.flush()
    session.add_all(RuleEvaluation(decision_run_id=run.decision_run_id, seq=i, rule_id=o.rule_id, stage=o.stage,
                                   product_code=o.product_code, outcome=o.outcome, detail=o.detail,
                                   clauses=jsonutil.to_jsonable(o.clauses))
                    for i, o in enumerate(result.outcomes, 1))
    ledger.append(session, actor, case_id=case.case_id, entity_type="DECISION_RUN",
                  entity_id=str(run.decision_run_id), event_type="EVALUATED",
                  payload={"status": run.status, "suppression_reasons": run.suppression_reasons,
                           "ruleset_version": run.ruleset_version, "engine_version": run.engine_version,
                           "snapshot_id": str(snapshot.snapshot_id), "input_sha256": run.input_sha256,
                           "output_sha256": run.output_sha256, "as_of": as_of.isoformat(),
                           "primary": result.primary, "alternative": result.alternative,
                           "referrals": result.referrals})
    return run


def _replace_recommendations(session: Session, case: RenewalCase, run: DecisionRun, built: BuiltContext,
                             result: sra_rules.DecisionResult, as_of: date, actor: ledger.Actor
                             ) -> tuple[list[str], list[Recommendation]]:
    """Supersede the open recommendations of earlier runs and persist the surfaced candidates of this one."""
    old = list(session.scalars(select(Recommendation).where(
        Recommendation.case_id == case.case_id, Recommendation.status.in_(OPEN_RECOMMENDATION_STATUSES))))
    new: dict[str, Recommendation] = {}
    ranked = [c for c in result.candidates if c.selection in SURFACED]
    for rank, cand in enumerate(result.candidates, 1):
        if cand.selection not in SURFACED:
            continue
        rec = Recommendation(recommendation_ref=_next_recommendation_ref(session, as_of),
                             decision_run_id=run.decision_run_id, case_id=case.case_id, rule_id=cand.rule_id,
                             opportunity_type=cand.type, product_code=cand.product_code,
                             priority_tier=cand.priority_tier, selection=cand.selection, rank=rank, status="PENDING")
        session.add(rec)
        session.flush()
        session.add(PricingScenario(case_id=case.case_id, decision_run_id=run.decision_run_id,
                                    included_recommendation_ids=[rec.recommendation_id],
                                    calc_version=PRICING_CALC_VERSION,
                                    **scenario_values(cand, built.rating_quote_refs)))
        new[cand.rule_id] = rec
    for o in old:
        successor = new.get(o.rule_id)
        session.execute(update(Recommendation).where(Recommendation.recommendation_id == o.recommendation_id)
                        .values(status="SUPERSEDED",
                                superseded_by=successor.recommendation_id if successor else None))
        ledger.append(session, actor, case_id=case.case_id, entity_type="RECOMMENDATION",
                      entity_id=str(o.recommendation_id), event_type="SUPERSEDED",
                      payload={"recommendation_ref": o.recommendation_ref, "previous_status": o.status,
                               "superseded_by": str(successor.recommendation_id) if successor else None,
                               "decision_run_id": str(run.decision_run_id)})
    for rec in new.values():
        ledger.append(session, actor, case_id=case.case_id, entity_type="RECOMMENDATION",
                      entity_id=str(rec.recommendation_id), event_type="RECOMMENDATION_CREATED",
                      payload={"recommendation_ref": rec.recommendation_ref, "rule_id": rec.rule_id,
                               "product_code": rec.product_code, "selection": rec.selection,
                               "decision_run_id": str(run.decision_run_id)})
    return [c.type for c in ranked], list(new.values())


def _move_case(session: Session, case: RenewalCase, snap: SourceSnapshot, run: DecisionRun,
               surfaced_types: list[str], actor: ledger.Actor) -> None:
    before = case.state
    case.state = state_after_decision(run.status, before)
    case.opportunity_signal = opportunity_signal(run.status, surfaced_types)
    case.suppression_reason_codes = list(run.suppression_reasons)
    case.current_decision_run_id = run.decision_run_id
    # A re-quote in PAS can change the premiums; the case shows the latest values.
    case.expiring_premium = snap.quote["expiring_premium_gross"]
    case.renewal_premium = snap.quote["renewal_premium_gross"]
    case.letter_due_date = snap.quote["letter_due_date"]
    case.updated_at = utcnow()
    case.row_version += 1
    session.flush()
    ledger.append(session, actor, case_id=case.case_id, entity_type="CASE", entity_id=str(case.case_id),
                  event_type="STATE_CHANGED",
                  payload={"from": before, "to": case.state, "opportunity_signal": case.opportunity_signal,
                           "decision_run_id": str(run.decision_run_id), "row_version": case.row_version})


def evaluate_quote(session: Session, quote_id: str, actor: ledger.Actor, *, as_of: date, jurisdiction: str,
                   request_id: str | None = None) -> EvaluationOutcome:
    ruleset = load_published_ruleset(session, jurisdiction)
    pas, crm, claims, ref = SrcMockPas(session), SrcMockCrm(session), SrcMockClaims(session), SraReference(session)
    snap = collect_source(quote_id, pas, crm, claims, ref, ref)
    if snap is None:
        raise not_found("Renewal quote", quote_id)

    case, created = _get_or_create_case(session, snap, actor)
    if case.state in WINDOW_CLOSED_STATES:
        raise ProblemError(409, "Operational window closed",
                           f"case {case.case_id} is {case.state}; the renewal letter is approved or dispatched",
                           code="WINDOW_CLOSED", caseId=str(case.case_id), state=case.state)

    # Re-read the cooldown ledger without this case's own declines (see SraReference.declines).
    snap.declines = ref.declines(snap.customer["customer_id"], exclude_case_id=case.case_id)
    built = build_context(snap, ruleset.params, as_of, letter_dispatched=case.state in DISPATCHED_STATES)
    latest = _latest_run(session, case.case_id)
    if (latest is not None and latest.input_sha256 == canonical_hash(built.context)
            and latest.ruleset_version == ruleset.version and latest.as_of == as_of):
        return EvaluationOutcome(case.case_id, case.quote_id, latest.decision_run_id, latest.status,
                                 list(latest.suppression_reasons), latest.ruleset_version, as_of,
                                 reused_previous_run=True, case_created=created)

    decision = decide(built.context, ruleset, as_of)
    cancel_drafts(session, case, actor, "re-evaluated with changed source data")
    run = _persist_run(session, case, snap, built, ruleset, decision, as_of, actor, request_id)
    surfaced, new_recs = _replace_recommendations(session, case, run, built, decision.result, as_of, actor)
    _move_case(session, case, snap, run, surfaced, actor)
    if get_settings().sra_narrative_inline:
        # Step 6: rationale + letter text for the new cards (validated, cached by fact pack). Same transaction.
        narrative_service.generate_for_recommendations(session, new_recs, actor)
    return EvaluationOutcome(case.case_id, case.quote_id, run.decision_run_id, run.status,
                             list(run.suppression_reasons), run.ruleset_version, as_of,
                             reused_previous_run=False, case_created=created)


def as_dict(o: EvaluationOutcome) -> dict[str, Any]:
    return {"caseId": str(o.case_id), "quoteId": o.quote_id,
            "decision": {"decisionRunId": str(o.decision_run_id), "status": o.status,
                         "suppressionReasons": o.suppression_reasons, "rulesetVersion": o.ruleset_version,
                         "asOf": o.as_of.isoformat(), "reusedPreviousRun": o.reused_previous_run},
            "caseCreated": o.case_created}
