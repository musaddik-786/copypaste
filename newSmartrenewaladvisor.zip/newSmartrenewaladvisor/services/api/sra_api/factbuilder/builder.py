"""Fact Builder: raw source snapshot -> Decision Context (the shape of rules/golden/personas.json).

Pure function - no I/O, no clock (`as_of` is passed in). Business thresholds come from the ruleset parameters
(e.g. `grievance_lookback_days`), never from code (ADR-002). Facts that cannot be established are left as
``None`` so the engine's Data Integrity Gate fails closed on them (invariant 5); facts declared but not
verified are listed in ``unverified_facts``.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from sra_rules.dates import months_between

from sra_api.adapters.ports import Row, SourceSnapshot

FACT_BUILDER_VERSION = "1.0.0"

OPEN_COMPLAINT_STATUSES = ("OPEN", "ESCALATED", "OMBUDSMAN")
UNSETTLED_CLAIM_STATUSES = ("OPEN", "IN_SETTLEMENT", "DISPUTED", "LITIGATION")
HOME_LOBS = ("HOME_BUILDING", "HOME_CONTENTS")
PET_COMPREHENSIVE_MODULE = "PET_HEALTH_COMPREHENSIVE"
DECLARED_CUSTOMER_FLAGS = ("dog_owner", "cat_owner", "horse_owner", "high_value_bike_owner")
DWELLING_LABELS = {"APARTMENT": "Apartment", "DETACHED": "Detached house",
                   "SEMI_DETACHED": "Semi-detached house", "TERRACED": "Terraced house"}

# Which system a top-level fact group comes from (for sra.snapshot_fact provenance).
SOURCE_SYSTEM = {"quote": "PAS", "policy": "PAS", "vehicle": "PAS", "motor": "PAS", "property": "PAS",
                 "pet": "PAS", "portfolio": "PAS", "pas_quotes": "PAS", "customer": "CRM", "consent": "CRM",
                 "account": "CRM", "external": "CRM", "claims": "CLAIMS", "history": "SRA"}
CONDUCT_SOURCE = {"open_complaint": "CRM", "vulnerability_hold": "CRM"}  # other conduct facts: CLAIMS


@dataclass(frozen=True)
class Fact:
    path: str
    value: Any
    quality: str          # OK | MISSING | UNVERIFIED
    source_system: str


@dataclass
class BuiltContext:
    context: dict[str, Any]
    facts: list[Fact]
    rating_quote_refs: dict[str, str] = field(default_factory=dict)  # product_code -> rating_quote_id


def _d(v: Any) -> date | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    return date.fromisoformat(str(v)[:10])


def _within(loss_date: Any, months: int, as_of: date) -> bool:
    d = _d(loss_date)
    return d is not None and months_between(d, as_of) < months


def _declared(snap: SourceSnapshot) -> dict[str, Row]:
    return {f["fact_key"]: f for f in snap.declared_facts}


def _quote(snap: SourceSnapshot, as_of: date, letter_dispatched: bool) -> dict[str, Any]:
    q = snap.quote
    due = _d(q["letter_due_date"])
    created = _d(q["created_at"])
    return {"quote_id": q["quote_id"], "policy_id": q["policy_id"], "status": q["status"],
            "created_at": created.isoformat() if created else None,
            "letter_due": due.isoformat() if due else None,
            "letter_dispatched": letter_dispatched,
            "days_to_letter_due": (due - as_of).days if due else None}


def _customer(snap: SourceSnapshot) -> dict[str, Any]:
    c, declared = snap.customer, _declared(snap)
    out: dict[str, Any] = {"customer_id": c["customer_id"], "occupancy": c.get("occupancy"),
                           "dwelling_type": c.get("dwelling_type"), "household_type": c.get("household_type"),
                           "primary_earner": c.get("primary_earner"), "has_dependants": c.get("has_dependants")}
    for key in DECLARED_CUSTOMER_FLAGS:
        out[key] = declared[key]["value"] if key in declared else None
    out["household_vehicle_count"] = c.get("household_vehicle_count")
    return out


def _conduct(snap: SourceSnapshot, params: Mapping[str, Any], as_of: date) -> dict[str, Any]:
    lookback_days: int = params["grievance_lookback_days"]
    claims = snap.claims

    def recent_dispute(cl: Row) -> bool:
        changed = _d(cl.get("status_changed_at"))
        return cl["status"] == "DISPUTED" and changed is not None and (as_of - changed).days <= lookback_days

    return {"open_complaint": any(x["status"] in OPEN_COMPLAINT_STATUSES for x in snap.complaints),
            "disputed_claim_in_lookback": any(recent_dispute(x) for x in claims),
            "open_litigation": any(x["status"] == "LITIGATION" for x in claims),
            "open_claim_in_settlement": any(x["status"] in UNSETTLED_CLAIM_STATUSES for x in claims),
            "vulnerability_hold": snap.customer.get("vulnerability_hold")}


def _policy(snap: SourceSnapshot) -> dict[str, Any]:
    p, q = snap.policy, snap.quote
    out: dict[str, Any] = {"lob": p["lob_code"]}
    if p["lob_code"] == "CAR":
        out["coverage_level"] = p.get("coverage_level")
    out["tier"] = p.get("package_tier")
    out["expiring_premium"] = q.get("expiring_premium_gross")
    out["renewal_premium"] = q.get("renewal_premium_gross")
    return out


def _vehicle_and_motor(v: Row, as_of: date) -> tuple[dict[str, Any], dict[str, Any]]:
    value = v.get("market_value")
    vehicle = {"description": f"{v['build_year']} {v['make_model']}",
               "market_value": int(value) if value is not None else None,
               "age_years": as_of.year - v["build_year"] if v.get("build_year") else None,
               "annual_km": v.get("annual_km")}
    return vehicle, {"bonus_tier": v.get("bonus_tier")}


def _property(pr: Row, as_of: date) -> dict[str, Any]:
    by, area = pr.get("build_year"), pr.get("floor_area_sqm")
    label = DWELLING_LABELS.get(pr.get("dwelling_type") or "", "Property")
    return {"description": f"{label}, built {by}, {area} sqm",
            "zuers_zone": pr.get("zuers_zone"),
            "backwater_valve_certified": pr.get("backwater_valve_certified"),
            "building_age_years": as_of.year - by if by else None,
            "has_solar_or_heatpump": pr.get("has_solar_or_heatpump"),
            "floor_area_sqm": area,
            "basement_or_ground_floor_storage": pr.get("basement_or_ground_floor_storage")}


def _pet(snap: SourceSnapshot, as_of: date) -> dict[str, Any]:
    a = snap.animals[0]
    modules = {m["product_code"] for m in snap.modules if m["policy_id"] == snap.policy["policy_id"]}
    return {"species": a.get("species"), "breed": a.get("breed"),
            "age_years": as_of.year - a["birth_year"] if a.get("birth_year") else None,
            "cover_tier": "COMPREHENSIVE" if PET_COMPREHENSIVE_MODULE in modules else "SURGERY"}


def _claims(snap: SourceSnapshot, as_of: date) -> dict[str, Any]:
    cl = snap.claims
    out: dict[str, Any] = {"claims_12m": sum(_within(x["loss_date"], 12, as_of) for x in cl),
                           "claims_36m": sum(_within(x["loss_date"], 36, as_of) for x in cl),
                           "at_fault_24m": sum(bool(x.get("at_fault")) and _within(x["loss_date"], 24, as_of)
                                               for x in cl),
                           "at_fault_36m": sum(bool(x.get("at_fault")) and _within(x["loss_date"], 36, as_of)
                                               for x in cl)}
    lob = snap.policy["lob_code"]
    if lob in HOME_LOBS:
        out["open_water_claim_24m"] = any(x.get("peril") == "WATER" and _within(x["loss_date"], 24, as_of)
                                          for x in cl)
    if lob == "PET_HEALTH":
        pet_policies = {p["policy_id"] for p in snap.policies if p["lob_code"] == "PET_HEALTH"}
        out["pet_claims_24m"] = sum(x["policy_id"] in pet_policies and _within(x["loss_date"], 24, as_of)
                                    for x in cl)
    return out


def _portfolio(snap: SourceSnapshot) -> dict[str, Any]:
    ids = {p["policy_id"] for p in snap.policies}
    active = {p["base_product_code"] for p in snap.policies} | {m["product_code"] for m in snap.modules
                                                                 if m["policy_id"] in ids}
    embedded: set[str] = set()
    for p in snap.policies:
        held = {p["base_product_code"]} | {m["product_code"] for m in snap.modules if m["policy_id"] == p["policy_id"]}
        for e in snap.embeddings:
            if e["parent_product_code"] in held and e.get("parent_tier") in (None, p.get("package_tier")):
                embedded.add(e["embedded_product_code"])
    return {"active_products": sorted(active), "embedded_covers": sorted(embedded - active)}


def _external(snap: SourceSnapshot, as_of: date) -> dict[str, Any]:
    f = _declared(snap).get("external_vehicle")
    value = f["value"] if f else {}
    out: dict[str, Any] = {"declared_external_vehicle": bool(value.get("declared", False))}
    if value.get("declared") and f is not None:
        declared_at = _d(f["declared_at"])
        out.update({"vehicle_description": value.get("vehicle"), "external_cover": value.get("cover"),
                    "declared_at": declared_at.isoformat() if declared_at else None,
                    "declared_via": f["source"],
                    "declaration_age_months": months_between(declared_at, as_of) if declared_at else None})
    return out


def _pas_quotes(snap: SourceSnapshot, as_of: date) -> tuple[dict[str, Any], dict[str, str]]:
    """One verified-price entry per product; a quote is verified while it is still valid on `as_of`."""
    quotes: dict[str, Any] = {}
    refs: dict[str, str] = {}
    by_product: dict[str, list[Row]] = {}
    for rq in snap.rating_quotes:
        by_product.setdefault(rq["product_code"], []).append(rq)
    for pc, rows in sorted(by_product.items()):
        rq = next((r for r in rows if r.get("variant") == "STANDARD"), rows[0])
        valid_until = _d(rq.get("valid_until"))
        quotes[pc] = {"annual_gross": rq["annual_gross"],
                      "verified": valid_until is not None and valid_until >= as_of}
        refs[pc] = rq["rating_quote_id"]
    return quotes, refs


def _unverified(snap: SourceSnapshot) -> list[str]:
    out = [f"customer.{f['fact_key']}" for f in snap.declared_facts
           if f["fact_key"] in DECLARED_CUSTOMER_FLAGS and not f.get("verified")]
    ext = _declared(snap).get("external_vehicle")
    if ext is not None and not ext.get("verified"):
        out.append("external.declared_external_vehicle")
    if snap.vehicle is not None and not snap.vehicle.get("annual_km_verified"):
        out.append("vehicle.annual_km")
    return sorted(out)


def _flatten(prefix: str, value: Any, out: list[tuple[str, Any]]) -> None:
    if isinstance(value, Mapping) and value:
        for k, v in value.items():
            _flatten(f"{prefix}.{k}" if prefix else str(k), v, out)
    else:
        out.append((prefix, value))


def _facts(context: Mapping[str, Any]) -> list[Fact]:
    unverified = set(context.get("unverified_facts", []))
    leaves: list[tuple[str, Any]] = []
    for group, value in context.items():
        if group != "unverified_facts":
            _flatten(group, value, leaves)
    facts = []
    for path, value in leaves:
        group, _, rest = path.partition(".")
        system = CONDUCT_SOURCE.get(rest, "CLAIMS") if group == "conduct" else SOURCE_SYSTEM.get(group, "SRA")
        quality = "MISSING" if value is None else "UNVERIFIED" if path in unverified else "OK"
        facts.append(Fact(path, value, quality, system))
    return facts


def build_context(snap: SourceSnapshot, params: Mapping[str, Any], as_of: date, *,
                  letter_dispatched: bool = False) -> BuiltContext:
    """Derive the Decision Context for one renewal quote."""
    consent = next((c for c in snap.consents if c["purpose"] == "ADVISORY_RENEWAL"), None)
    ctx: dict[str, Any] = {
        "quote": _quote(snap, as_of, letter_dispatched),
        "customer": _customer(snap),
        "consent": {"advisory_renewal": consent["status"] if consent else None},
        "account": {"payment_status": snap.customer.get("payment_status")},
        "conduct": _conduct(snap, params, as_of),
        "policy": _policy(snap),
    }
    if snap.vehicle is not None:
        ctx["vehicle"], ctx["motor"] = _vehicle_and_motor(snap.vehicle, as_of)
    if snap.property is not None:
        ctx["property"] = _property(snap.property, as_of)
    if snap.animals:
        ctx["pet"] = _pet(snap, as_of)
    ctx["claims"] = _claims(snap, as_of)
    ctx["portfolio"] = _portfolio(snap)
    ctx["external"] = _external(snap, as_of)
    ctx["history"] = {"declines": [{"product_code": d["product_code"],
                                    "declined_at": _d(d["declined_at"]).isoformat(),  # type: ignore[union-attr]
                                    "source": d["source"]} for d in snap.declines]}
    ctx["pas_quotes"], refs = _pas_quotes(snap, as_of)
    ctx["unverified_facts"] = _unverified(snap)
    return BuiltContext(context=ctx, facts=_facts(ctx), rating_quote_refs=refs)

