"""JSON helpers. Money (Decimal) is always written as a string - never a float (CLAUDE.md invariant 4)."""
from __future__ import annotations

import hashlib
import json
from datetime import date, datetime
from decimal import Decimal
from typing import Any
from uuid import UUID


def to_jsonable(obj: Any) -> Any:
    """Recursively convert Decimal -> str, date/datetime -> ISO string, UUID -> str."""
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list | tuple | set):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, Decimal):
        return str(obj)
    if isinstance(obj, datetime | date):
        return obj.isoformat()
    if isinstance(obj, UUID):
        return str(obj)
    return obj


def dumps(obj: Any) -> str:
    """Serializer used for every jsonb column."""
    return json.dumps(to_jsonable(obj), ensure_ascii=False)


def canonical(obj: Any) -> str:
    """Stable text form for hashing: sorted keys, compact separators, UTF-8."""
    return json.dumps(to_jsonable(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
