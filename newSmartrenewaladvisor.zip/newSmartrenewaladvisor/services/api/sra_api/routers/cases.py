"""Case details, recommendation cards and the decision trace."""
from __future__ import annotations

import uuid
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session

from sra_api.auth import READ_ROLES, User, require_role
from sra_api.cases import queries
from sra_api.db import get_session

router = APIRouter(tags=["cases"])


@router.get("/cases/{case_id}")
def get_case(case_id: uuid.UUID, response: Response, session: Annotated[Session, Depends(get_session)],
             _: Annotated[User, Depends(require_role(*READ_ROLES))]) -> dict[str, Any]:
    detail = queries.case_detail(session, case_id)
    response.headers["ETag"] = f'"{detail["rowVersion"]}"'  # send back as If-Match on officer actions
    return detail


@router.get("/cases/{case_id}/recommendations")
def get_recommendations(case_id: uuid.UUID, session: Annotated[Session, Depends(get_session)],
                        _: Annotated[User, Depends(require_role(*READ_ROLES))],
                        lang: Literal["en", "de"] = "en") -> list[dict[str, Any]]:
    return queries.recommendation_cards(session, case_id, lang)


@router.get("/decision-runs/{decision_run_id}/trace")
def get_trace(decision_run_id: uuid.UUID, session: Annotated[Session, Depends(get_session)],
              _: Annotated[User, Depends(require_role(*READ_ROLES))]) -> dict[str, Any]:
    return queries.decision_trace(session, decision_run_id)
