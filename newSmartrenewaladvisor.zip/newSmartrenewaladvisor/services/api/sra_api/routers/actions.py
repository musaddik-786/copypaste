"""Human-in-the-loop endpoints: open a case for review, Include / Skip / Defer, undo. All require If-Match."""
from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, Header, Response
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from sra_api.auth import OFFICER_ROLES, User, require_role
from sra_api.cases import actions
from sra_api.cases.action_rules import ActionRequest
from sra_api.clock import business_date
from sra_api.db import get_session
from sra_api.settings import get_settings

router = APIRouter(tags=["officer actions"])


class OfficerActionBody(BaseModel):
    """contracts/openapi.v1.yaml#/components/schemas/OfficerAction"""
    model_config = ConfigDict(extra="forbid")
    action: Literal["INCLUDE", "SKIP", "DEFER"]
    skipReasonCode: str | None = None
    deferReasonCode: str | None = None
    followUpAt: datetime | date | None = None
    comment: Annotated[str | None, Field(max_length=1000)] = None
    narrativeIdShown: uuid.UUID | None = None

    def to_request(self) -> ActionRequest:
        follow = self.followUpAt.date() if isinstance(self.followUpAt, datetime) else self.followUpAt
        return ActionRequest(self.action, self.skipReasonCode, self.deferReasonCode, follow, self.comment)


def _etag(response: Response, row_version: int) -> None:
    response.headers["ETag"] = f'"{row_version}"'


@router.post("/cases/{case_id}/review", status_code=200)
def start_review(case_id: uuid.UUID, response: Response, session: Annotated[Session, Depends(get_session)],
                 user: Annotated[User, Depends(require_role(*OFFICER_ROLES))],
                 if_match: Annotated[str | None, Header()] = None) -> dict[str, Any]:
    """The officer opens the case (READY_FOR_REVIEW -> IN_REVIEW)."""
    change = actions.start_review(session, case_id, actions.parse_if_match(if_match), user.actor)
    _etag(response, change.row_version)
    return actions.change_as_dict(change)


@router.post("/recommendations/{recommendation_id}/actions", status_code=201)
def act(recommendation_id: uuid.UUID, body: OfficerActionBody, response: Response,
        session: Annotated[Session, Depends(get_session)],
        user: Annotated[User, Depends(require_role(*OFFICER_ROLES))],
        if_match: Annotated[str | None, Header()] = None) -> dict[str, Any]:
    change = actions.record_action(session, recommendation_id, body.to_request(), actions.parse_if_match(if_match),
                                   user.actor, today=business_date(), jurisdiction=get_settings().sra_jurisdiction,
                                   narrative_id_shown=body.narrativeIdShown)
    _etag(response, change.row_version)
    return actions.change_as_dict(change)


@router.post("/recommendations/{recommendation_id}/actions/{action_id}/reversal", status_code=201)
def reverse(recommendation_id: uuid.UUID, action_id: uuid.UUID, response: Response,
            session: Annotated[Session, Depends(get_session)],
            user: Annotated[User, Depends(require_role(*OFFICER_ROLES))],
            if_match: Annotated[str | None, Header()] = None) -> dict[str, Any]:
    change = actions.reverse_action(session, recommendation_id, action_id, actions.parse_if_match(if_match),
                                    user.actor, today=business_date())
    _etag(response, change.row_version)
    return actions.change_as_dict(change)
