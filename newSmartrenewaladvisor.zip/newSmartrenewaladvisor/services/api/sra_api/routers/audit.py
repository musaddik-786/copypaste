"""Audit trail of a case, with verification of the whole hash chain (ADR-005)."""
from __future__ import annotations

import uuid
from typing import Annotated, Any

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from sra_api.audit.ledger import verify_chain
from sra_api.auth import READ_ROLES, User, require_role
from sra_api.db import get_session

router = APIRouter(tags=["audit"])


@router.get("/audit/cases/{case_id}")
def case_audit(case_id: uuid.UUID, session: Annotated[Session, Depends(get_session)],
               _: Annotated[User, Depends(require_role(*READ_ROLES))]) -> dict[str, Any]:
    rows = session.execute(text("SELECT event_seq, occurred_at, actor_type, actor_id, entity_type, event_type, "
                                "payload, hash FROM audit.audit_event WHERE case_id = :c ORDER BY event_seq"),
                           {"c": case_id}).mappings()
    chain = verify_chain(session)
    return {"caseId": str(case_id),
            "chain": {"valid": chain.valid, "eventsChecked": chain.events_checked,
                      "firstBrokenSeq": chain.first_broken_seq, "reason": chain.reason},
            "events": [{"seq": r["event_seq"], "at": r["occurred_at"].isoformat(), "actor": r["actor_id"],
                        "actorType": r["actor_type"], "entity": r["entity_type"], "event": r["event_type"],
                        "payload": r["payload"], "hash": r["hash"][:16]} for r in rows]}
