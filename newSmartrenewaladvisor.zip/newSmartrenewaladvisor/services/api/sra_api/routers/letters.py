"""Letter endpoints: compose a draft, read it (JSON sections + PDF), approve, dispatch. All mutations need If-Match."""
from __future__ import annotations

import uuid
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, Header, Response
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from sra_api.auth import OFFICER_ROLES, READ_ROLES, User, require_role
from sra_api.cases.actions import parse_if_match
from sra_api.clock import business_date
from sra_api.db import get_session
from sra_api.letters import service

router = APIRouter(tags=["letters"])


@router.post("/cases/{case_id}/letter-draft", status_code=201)
def compose(case_id: uuid.UUID, response: Response, session: Annotated[Session, Depends(get_session)],
            user: Annotated[User, Depends(require_role(*OFFICER_ROLES))],
            if_match: Annotated[str | None, Header()] = None, lang: Literal["en", "de"] = "en") -> dict[str, Any]:
    change = service.compose_draft(session, case_id, parse_if_match(if_match), user.actor, today=business_date(),
                                   language=lang)
    response.headers["ETag"] = f'"{change.row_version}"'
    return service.as_dict(change)


@router.get("/cases/{case_id}/letter-draft")
def get_letter(case_id: uuid.UUID, session: Annotated[Session, Depends(get_session)],
               _: Annotated[User, Depends(require_role(*READ_ROLES))]) -> dict[str, Any]:
    return service.current_letter(session, case_id)


@router.get("/cases/{case_id}/letter-draft/pdf")
def get_letter_pdf(case_id: uuid.UUID, session: Annotated[Session, Depends(get_session)],
                   _: Annotated[User, Depends(require_role(*READ_ROLES))]) -> FileResponse:
    path = service.letter_pdf_path(session, case_id)
    return FileResponse(path, media_type="application/pdf", filename=path.name)


@router.post("/cases/{case_id}/letter-draft/approve")
def approve(case_id: uuid.UUID, response: Response, session: Annotated[Session, Depends(get_session)],
            user: Annotated[User, Depends(require_role(*OFFICER_ROLES))],
            if_match: Annotated[str | None, Header()] = None) -> dict[str, Any]:
    change = service.approve(session, case_id, parse_if_match(if_match), user.actor)
    response.headers["ETag"] = f'"{change.row_version}"'
    return service.as_dict(change)


@router.post("/cases/{case_id}/dispatch", status_code=202)
def dispatch(case_id: uuid.UUID, response: Response, session: Annotated[Session, Depends(get_session)],
             user: Annotated[User, Depends(require_role(*OFFICER_ROLES))],
             if_match: Annotated[str | None, Header()] = None) -> dict[str, Any]:
    change, reference = service.dispatch(session, case_id, parse_if_match(if_match), user.actor)
    response.headers["ETag"] = f'"{change.row_version}"'
    return {**service.as_dict(change), "omsReference": reference}
