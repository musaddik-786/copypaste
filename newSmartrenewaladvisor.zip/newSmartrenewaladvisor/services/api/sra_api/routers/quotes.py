"""Renewal queue and the "Generate Possible Opportunities" trigger."""
from __future__ import annotations

import uuid
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, Header, Path, Query
from sqlalchemy.orm import Session

from sra_api.auth import OFFICER_ROLES, READ_ROLES, User, require_role
from sra_api.cases import evaluate, queries
from sra_api.clock import business_date
from sra_api.db import get_session
from sra_api.settings import get_settings

router = APIRouter(tags=["queue"])
QUOTE_ID = r"^QUO-\d{4}-\d{5}$"


@router.get("/renewal-quotes")
def list_quotes(session: Annotated[Session, Depends(get_session)],
                _: Annotated[User, Depends(require_role(*READ_ROLES))],
                q: str | None = None, lob: str | None = None,
                status: Literal["PENDING_REVIEW", "CONDUCT_HOLD", "DISPATCHED", "ALL"] = "ALL",
                page: Annotated[int, Query(ge=1)] = 1) -> dict[str, Any]:
    return queries.queue(session, business_date(), q=q, lob=lob, status=status, page=page)


@router.get("/renewal-quotes/kpis")
def queue_kpis(session: Annotated[Session, Depends(get_session)],
               _: Annotated[User, Depends(require_role(*READ_ROLES))]) -> dict[str, int]:
    return queries.kpis(session, business_date())


@router.post("/renewal-quotes/{quote_id}/evaluations")
def generate_possible_opportunities(
        quote_id: Annotated[str, Path(pattern=QUOTE_ID)],
        session: Annotated[Session, Depends(get_session)],
        user: Annotated[User, Depends(require_role(*OFFICER_ROLES))],
        lang: Literal["en", "de"] = "en",
        x_request_id: Annotated[str | None, Header()] = None) -> dict[str, Any]:
    outcome = evaluate.evaluate_quote(session, quote_id, user.actor, as_of=business_date(),
                                      jurisdiction=get_settings().sra_jurisdiction,
                                      request_id=x_request_id or str(uuid.uuid4()))
    body = evaluate.as_dict(outcome)
    body["recommendations"] = queries.recommendation_cards(session, outcome.case_id, lang)
    body["language"] = lang
    return body
