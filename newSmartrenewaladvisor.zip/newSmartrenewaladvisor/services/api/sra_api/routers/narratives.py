"""Officer edits of the narrative (new version, origin OFFICER_EDIT, re-validated)."""
from __future__ import annotations

import uuid
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, Header, Response
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from sra_api.auth import OFFICER_ROLES, User, require_role
from sra_api.cases.actions import parse_if_match
from sra_api.cases.queries import recommendation_cards
from sra_api.db import get_session
from sra_api.narrative.edit import edit

router = APIRouter(tags=["narratives"])


class ComparisonRow(BaseModel):
    label: str
    current: str
    improved: str


class NarrativeEdit(BaseModel):
    model_config = ConfigDict(extra="forbid")
    audience: Literal["OFFICER", "CUSTOMER_LETTER"] = "OFFICER"
    language: Literal["en", "de"] = "en"
    whyRecommended: Annotated[str | None, Field(max_length=700)] = None
    currentGap: Annotated[str | None, Field(max_length=500)] = None
    howItHelps: Annotated[str | None, Field(max_length=600)] = None
    keyBenefitKeys: Annotated[list[str] | None, Field(max_length=5)] = None
    comparisonRows: Annotated[list[ComparisonRow] | None, Field(max_length=4)] = None
    letterRationale: Annotated[str | None, Field(max_length=600)] = None

    def changes(self) -> dict[str, Any]:
        return {"why_recommended": self.whyRecommended, "current_gap": self.currentGap,
                "how_it_helps": self.howItHelps, "key_benefit_keys": self.keyBenefitKeys,
                "comparison_rows": [r.model_dump() for r in self.comparisonRows] if self.comparisonRows else None,
                "letter_rationale": self.letterRationale}


@router.put("/recommendations/{recommendation_id}/narrative")
def edit_narrative(recommendation_id: uuid.UUID, body: NarrativeEdit, response: Response,
                   session: Annotated[Session, Depends(get_session)],
                   user: Annotated[User, Depends(require_role(*OFFICER_ROLES))],
                   if_match: Annotated[str | None, Header()] = None) -> dict[str, Any]:
    n, row_version = edit(session, recommendation_id, body.audience, body.language, body.changes(),
                          parse_if_match(if_match), user.actor)
    response.headers["ETag"] = f'"{row_version}"'
    card = next(c for c in recommendation_cards(session, n_case(session, recommendation_id), body.language)
                if c["recommendationId"] == str(recommendation_id))
    return {"narrativeId": str(n.narrative_id), "version": n.version, "origin": n.origin, "rowVersion": row_version,
            "card": card}


def n_case(session: Session, recommendation_id: uuid.UUID) -> uuid.UUID:
    from sra_api.models import Recommendation
    rec = session.get(Recommendation, recommendation_id)
    assert rec is not None
    return rec.case_id
