"""Loads the PUBLISHED ruleset (rules.ruleset) and verifies its integrity before use - fail closed."""
from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.orm import Session

from sra_api.decisioning.ruleset import LoadedRuleset, catalog_sha256
from sra_api.errors import ProblemError


def load_published_ruleset(session: Session, jurisdiction: str) -> LoadedRuleset:
    row = session.execute(text("SELECT ruleset_version, catalog_json, catalog_sha256 FROM rules.ruleset "
                               "WHERE status = 'PUBLISHED' AND jurisdiction = :j"), {"j": jurisdiction}).one_or_none()
    if row is None:
        raise ProblemError(503, "No published ruleset", f"no PUBLISHED ruleset for jurisdiction {jurisdiction}",
                           code="NO_PUBLISHED_RULESET")
    version, catalog, stored = row
    if catalog_sha256(catalog) != stored:
        raise ProblemError(500, "Ruleset integrity check failed",
                           f"catalog of ruleset {version} does not match its recorded sha256",
                           code="RULESET_TAMPERED")
    return LoadedRuleset(version=version, catalog=catalog, sha256=stored)
