"""FastAPI application. Run locally:  uvicorn sra_api.main:app --reload  (from services/api)."""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from sra_api import __version__, errors
from sra_api.routers import actions, audit, cases, letters, narratives, quotes
from sra_api.settings import REPO_ROOT, get_settings

CONSOLE_DIR = REPO_ROOT / "apps" / "console"


def create_app() -> FastAPI:
    settings = get_settings()  # validates config at startup (e.g. dev auth only when SRA_ENV is local/test)
    app = FastAPI(title="Smart Renewal Advisor API", version=__version__,
                  description="On-demand renewal opportunity evaluation. No events, no copilot.")
    errors.install(app)
    app.include_router(quotes.router)
    app.include_router(cases.router)
    app.include_router(actions.router)
    app.include_router(narratives.router)
    app.include_router(letters.router)
    app.include_router(audit.router)
    if CONSOLE_DIR.is_dir():  # demo console (static, same origin as the API)
        app.mount("/console", StaticFiles(directory=CONSOLE_DIR, html=True), name="console")

        @app.get("/", include_in_schema=False)
        def root() -> RedirectResponse:
            return RedirectResponse("/console/")

    @app.get("/health", tags=["ops"])
    def health() -> dict[str, str]:
        return {"status": "ok", "version": __version__, "env": settings.sra_env, "auth": settings.sra_auth_mode}

    return app


app = create_app()
