"""Maps a priced engine candidate onto a sra.pricing_scenario row. No arithmetic beyond parsing: every amount
was computed and rounded by sra_pricing (invariant 4); this module only converts wire strings to Decimal."""
from __future__ import annotations

from decimal import Decimal
from typing import Any

from sra_rules import Candidate


def scenario_values(candidate: Candidate, rating_quote_refs: dict[str, str]) -> dict[str, Any]:
    p = candidate.pricing
    is_upsell = candidate.type == "UPSELL"
    return {
        "expiring_premium": Decimal(p["expiring_premium"]),
        "base_renewal_premium": Decimal(p["base_renewal_premium"]),
        "upsell_increment_annual": Decimal(p["incremental_annual"]) if is_upsell else Decimal("0.00"),
        "companion_standalone_annual": Decimal("0.00") if is_upsell else Decimal(p["companion_standalone_annual"]),
        "bundle_discount_pct": Decimal(p["bundle_discount_pct"]),
        "bundle_saving_annual": Decimal(p["bundle_saving_annual"]),
        "net_annual_total": Decimal(p["net_annual_total"]),
        # monthly equivalent of the add-on / companion premium (API: incrementalMonthlyEquivalent)
        "monthly_equivalent": Decimal(p["incremental_monthly_equiv"]),
        "rating_quote_refs": [rating_quote_refs[candidate.product_code]]
        if candidate.product_code in rating_quote_refs else [],
    }
