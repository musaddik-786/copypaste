"""ORM mappings for the tables the API writes (CLAUDE.md: ORM for writes, Core for reads).

db/001_sra_schema.sql is authoritative - these classes mirror it and are never used to create tables.
Columns with server defaults are declared with `server_default` so the ORM lets the database fill them.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import Date, ForeignKey, Integer, Numeric, Text, text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, TIMESTAMP, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

Money = Numeric(12, 2, asdecimal=True)
TZ = TIMESTAMP(timezone=True)
NOW = text("now()")


class Base(DeclarativeBase):
    pass


class RenewalCase(Base):
    __tablename__ = "renewal_case"
    __table_args__ = {"schema": "sra"}
    case_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, server_default=text("gen_random_uuid()"))
    quote_id: Mapped[str] = mapped_column(Text, unique=True)
    quote_version: Mapped[int] = mapped_column(Integer, server_default=text("1"))
    policy_id: Mapped[str] = mapped_column(Text)
    customer_id: Mapped[str] = mapped_column(Text)
    lob_code: Mapped[str] = mapped_column(Text)
    customer_display_name: Mapped[str] = mapped_column(Text)  # [PII] queue display only
    renewal_date: Mapped[date] = mapped_column(Date)
    letter_due_date: Mapped[date] = mapped_column(Date)
    expiring_premium: Mapped[Decimal] = mapped_column(Money)
    renewal_premium: Mapped[Decimal] = mapped_column(Money)
    state: Mapped[str] = mapped_column(Text)
    opportunity_signal: Mapped[str | None] = mapped_column(Text)
    suppression_reason_codes: Mapped[list[str]] = mapped_column(ARRAY(Text), server_default=text("'{}'"))
    current_decision_run_id: Mapped[uuid.UUID | None] = mapped_column(UUID)
    assigned_officer: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)
    updated_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)
    row_version: Mapped[int] = mapped_column(Integer, server_default=text("1"))


class PolicySnapshot(Base):
    __tablename__ = "policy_snapshot"
    __table_args__ = {"schema": "sra"}
    snapshot_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    case_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.renewal_case.case_id"))
    captured_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)
    request_id: Mapped[str | None] = mapped_column(Text)
    raw_payload: Mapped[dict[str, Any]] = mapped_column(JSONB)
    decision_context: Mapped[dict[str, Any]] = mapped_column(JSONB)
    context_sha256: Mapped[str] = mapped_column(Text)
    fact_builder_version: Mapped[str] = mapped_column(Text)


class SnapshotFact(Base):
    __tablename__ = "snapshot_fact"
    __table_args__ = {"schema": "sra"}
    snapshot_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.policy_snapshot.snapshot_id"),
                                                   primary_key=True)
    fact_path: Mapped[str] = mapped_column(Text, primary_key=True)
    value: Mapped[Any] = mapped_column(JSONB)
    quality: Mapped[str] = mapped_column(Text)
    source_system: Mapped[str] = mapped_column(Text)
    source_ref: Mapped[str | None] = mapped_column(Text)
    as_of: Mapped[date | None] = mapped_column(Date)


class DecisionRun(Base):
    __tablename__ = "decision_run"
    __table_args__ = {"schema": "sra"}
    decision_run_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    case_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.renewal_case.case_id"))
    snapshot_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.policy_snapshot.snapshot_id"))
    ruleset_version: Mapped[str] = mapped_column(Text)
    engine_version: Mapped[str] = mapped_column(Text)
    trigger: Mapped[str] = mapped_column(Text, server_default=text("'OFFICER_REQUEST'"))
    as_of: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(Text)
    suppression_reasons: Mapped[list[str]] = mapped_column(ARRAY(Text), server_default=text("'{}'"))
    input_sha256: Mapped[str] = mapped_column(Text)
    output_sha256: Mapped[str] = mapped_column(Text)
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    requested_by: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)


class RuleEvaluation(Base):
    __tablename__ = "rule_evaluation"
    __table_args__ = {"schema": "sra"}
    decision_run_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.decision_run.decision_run_id"),
                                                       primary_key=True)
    seq: Mapped[int] = mapped_column(Integer, primary_key=True)
    rule_id: Mapped[str] = mapped_column(Text)
    stage: Mapped[str] = mapped_column(Text)
    product_code: Mapped[str | None] = mapped_column(Text)
    outcome: Mapped[str] = mapped_column(Text)
    detail: Mapped[str | None] = mapped_column(Text)
    clauses: Mapped[list[dict[str, Any]]] = mapped_column(JSONB)


class Recommendation(Base):
    __tablename__ = "recommendation"
    __table_args__ = {"schema": "sra"}
    recommendation_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    recommendation_ref: Mapped[str] = mapped_column(Text, unique=True)
    decision_run_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.decision_run.decision_run_id"))
    case_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.renewal_case.case_id"))
    rule_id: Mapped[str] = mapped_column(Text)
    opportunity_type: Mapped[str] = mapped_column(Text)
    product_code: Mapped[str] = mapped_column(Text)
    product_variant: Mapped[str | None] = mapped_column(Text)
    priority_tier: Mapped[str] = mapped_column(Text)
    selection: Mapped[str] = mapped_column(Text)
    rank: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(Text, server_default=text("'PENDING'"))
    superseded_by: Mapped[uuid.UUID | None] = mapped_column(UUID, ForeignKey("sra.recommendation.recommendation_id"))
    created_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)


class PricingScenario(Base):
    __tablename__ = "pricing_scenario"
    __table_args__ = {"schema": "sra"}
    pricing_scenario_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    case_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.renewal_case.case_id"))
    decision_run_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.decision_run.decision_run_id"))
    included_recommendation_ids: Mapped[list[uuid.UUID]] = mapped_column(ARRAY(UUID))
    expiring_premium: Mapped[Decimal] = mapped_column(Money)
    base_renewal_premium: Mapped[Decimal] = mapped_column(Money)
    upsell_increment_annual: Mapped[Decimal] = mapped_column(Money)
    companion_standalone_annual: Mapped[Decimal] = mapped_column(Money)
    bundle_discount_pct: Mapped[Decimal] = mapped_column(Numeric(5, 2, asdecimal=True))
    bundle_saving_annual: Mapped[Decimal] = mapped_column(Money)
    net_annual_total: Mapped[Decimal] = mapped_column(Money)
    monthly_equivalent: Mapped[Decimal] = mapped_column(Money)
    instalment_note: Mapped[str | None] = mapped_column(Text)
    rating_quote_refs: Mapped[list[str]] = mapped_column(ARRAY(Text))
    calc_version: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)


class OfficerAction(Base):
    """Human-in-the-loop decisions (BR-10 / BR-11). Append-only by convention: undo is a REVERSAL row."""
    __tablename__ = "officer_action"
    __table_args__ = {"schema": "sra"}
    action_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    recommendation_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.recommendation.recommendation_id"))
    case_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.renewal_case.case_id"))
    action: Mapped[str] = mapped_column(Text)
    skip_reason_code: Mapped[str | None] = mapped_column(Text)
    defer_reason_code: Mapped[str | None] = mapped_column(Text)
    follow_up_at: Mapped[datetime | None] = mapped_column(TZ)
    comment: Mapped[str | None] = mapped_column(Text)
    reverses_action_id: Mapped[uuid.UUID | None] = mapped_column(UUID, ForeignKey("sra.officer_action.action_id"))
    narrative_id_shown: Mapped[uuid.UUID | None] = mapped_column(UUID)
    acted_by: Mapped[str] = mapped_column(Text)
    acted_at: Mapped[datetime] = mapped_column(TZ)


class RecommendationDecline(Base):
    """Cooldown ledger (EL-03), durable across renewal cycles."""
    __tablename__ = "recommendation_decline"
    __table_args__ = {"schema": "sra"}
    decline_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    customer_id: Mapped[str] = mapped_column(Text)
    product_code: Mapped[str] = mapped_column(Text)
    declined_at: Mapped[date] = mapped_column(Date)
    source: Mapped[str] = mapped_column(Text)
    recommendation_id: Mapped[uuid.UUID | None] = mapped_column(UUID)
    cooldown_until: Mapped[date] = mapped_column(Date)


class Narrative(Base):
    """Versioned GenAI / template / officer-edited text for one recommendation, audience and language."""
    __tablename__ = "narrative"
    __table_args__ = {"schema": "sra"}
    narrative_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    recommendation_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.recommendation.recommendation_id"))
    audience: Mapped[str] = mapped_column(Text)
    language: Mapped[str] = mapped_column(Text)
    version: Mapped[int] = mapped_column(Integer)
    origin: Mapped[str] = mapped_column(Text)
    content: Mapped[dict[str, Any]] = mapped_column(JSONB)
    fact_pack_sha256: Mapped[str] = mapped_column(Text)
    prompt_template_id: Mapped[str | None] = mapped_column(Text)
    model_deployment: Mapped[str | None] = mapped_column(Text)
    llm_call_id: Mapped[uuid.UUID | None] = mapped_column(UUID)
    validation_status: Mapped[str] = mapped_column(Text)
    edited_by: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)


class NarrativeValidation(Base):
    __tablename__ = "narrative_validation"
    __table_args__ = {"schema": "sra"}
    narrative_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.narrative.narrative_id"), primary_key=True)
    validator: Mapped[str] = mapped_column(Text, primary_key=True)
    passed: Mapped[bool] = mapped_column()
    findings: Mapped[list[dict[str, Any]]] = mapped_column(JSONB)


class LlmCall(Base):
    """One model call. The full prompt is not stored here (only its hash) - data minimisation."""
    __tablename__ = "llm_call"
    __table_args__ = {"schema": "sra"}
    llm_call_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    purpose: Mapped[str] = mapped_column(Text)
    deployment_name: Mapped[str] = mapped_column(Text)
    prompt_template_id: Mapped[str | None] = mapped_column(Text)
    data_class: Mapped[str] = mapped_column(Text)
    request_sha256: Mapped[str] = mapped_column(Text)
    input_tokens: Mapped[int | None] = mapped_column(Integer)
    output_tokens: Mapped[int | None] = mapped_column(Integer)
    latency_ms: Mapped[int | None] = mapped_column(Integer)
    finish_reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)


class LetterDraft(Base):
    __tablename__ = "letter_draft"
    __table_args__ = {"schema": "sra"}
    letter_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    case_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.renewal_case.case_id"))
    version: Mapped[int] = mapped_column(Integer)
    language: Mapped[str] = mapped_column(Text)
    template_version: Mapped[str] = mapped_column(Text)
    letter_type: Mapped[str] = mapped_column(Text)
    pricing_scenario_id: Mapped[uuid.UUID | None] = mapped_column(UUID)
    status: Mapped[str] = mapped_column(Text)
    rendered_html_uri: Mapped[str | None] = mapped_column(Text)
    rendered_pdf_uri: Mapped[str | None] = mapped_column(Text)
    content_sha256: Mapped[str | None] = mapped_column(Text)   # sha256 of the rendered PDF bytes
    approved_by: Mapped[str | None] = mapped_column(Text)
    approved_at: Mapped[datetime | None] = mapped_column(TZ)
    created_at: Mapped[datetime] = mapped_column(TZ, server_default=NOW)


class LetterSection(Base):
    __tablename__ = "letter_section"
    __table_args__ = {"schema": "sra"}
    letter_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.letter_draft.letter_id"), primary_key=True)
    seq: Mapped[int] = mapped_column(Integer, primary_key=True)
    section_type: Mapped[str] = mapped_column(Text)
    recommendation_id: Mapped[uuid.UUID | None] = mapped_column(UUID)
    content: Mapped[dict[str, Any]] = mapped_column(JSONB)


class LetterDispatch(Base):
    __tablename__ = "letter_dispatch"
    __table_args__ = {"schema": "sra"}
    dispatch_id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True, default=uuid.uuid4)
    letter_id: Mapped[uuid.UUID] = mapped_column(UUID, ForeignKey("sra.letter_draft.letter_id"))
    channel: Mapped[str] = mapped_column(Text)
    oms_reference: Mapped[str | None] = mapped_column(Text)
    dispatched_at: Mapped[datetime] = mapped_column(TZ)
    dispatched_by: Mapped[str] = mapped_column(Text)


class AuditEvent(Base):
    __tablename__ = "audit_event"
    __table_args__ = {"schema": "audit"}
    event_seq: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    event_id: Mapped[uuid.UUID] = mapped_column(UUID, default=uuid.uuid4)
    occurred_at: Mapped[datetime] = mapped_column(TZ)
    actor_type: Mapped[str] = mapped_column(Text)
    actor_id: Mapped[str] = mapped_column(Text)
    case_id: Mapped[uuid.UUID | None] = mapped_column(UUID)
    entity_type: Mapped[str] = mapped_column(Text)
    entity_id: Mapped[str] = mapped_column(Text)
    event_type: Mapped[str] = mapped_column(Text)
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB)
    prev_hash: Mapped[str] = mapped_column(Text)
    hash: Mapped[str] = mapped_column(Text)
