"""Letter composer - typed sections in a fixed order (ADR-012, BR-13, docs/05 §5.5). Pure: no I/O, no clock.

CORE_RENEWAL_TERMS -> PREMIUM_CHANGE_NOTICE -> ADVISORY_BLOCK* -> BUNDLE_SAVINGS* -> OPT_IN_INSTRUCTION ->
OBJECTION_NOTICE -> ATTACHMENTS

* An ADVISORY letter has one advisory block per recommendation the officer INCLUDED - nothing else is ever
  offered. Without an included recommendation the letter is STANDARD (core terms only).
* GenAI fills only the rationale slot (the validated CUSTOMER_LETTER narrative). Everything else is template text
  with values from the decision record; money values are sra_pricing strings, never recomputed here.
* No reply form and no pre-ticked choices: the opt-in is an instruction to contact the insurer.
* Cross-sell prices are itemised and the policy is stated to be separately purchasable (IDD Art. 24).
* Two included recommendations get two separate price tables; a combined total is not shown because the rule
  for combining bundle discounts is not defined yet.
"""
from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any

from sra_api import jsonutil
from sra_api.settings import REPO_ROOT

SECTION_ORDER = ("CORE_RENEWAL_TERMS", "PREMIUM_CHANGE_NOTICE", "ADVISORY_BLOCK", "BUNDLE_SAVINGS",
                 "OPT_IN_INSTRUCTION", "OBJECTION_NOTICE", "ATTACHMENTS")
TEMPLATE_FILE = REPO_ROOT / "ai" / "content" / "letter_templates.draft.v1.json"


@lru_cache
def template() -> dict[str, Any]:
    data: dict[str, Any] = json.loads(TEMPLATE_FILE.read_text(encoding="utf-8"))
    return data


@dataclass(frozen=True)
class LetterRecommendation:
    recommendation_id: str
    recommendation_ref: str
    opportunity_type: str        # UPSELL | CROSS_SELL
    product_name: str
    status: str                  # only INCLUDED ones reach the letter
    rank: int
    pricing: Mapping[str, str]
    letter_rationale: str | None  # validated CUSTOMER_LETTER narrative, tokens already re-inserted
    rationale_origin: str | None = None
    draft_wording: bool = False


@dataclass(frozen=True)
class LetterInputs:
    first_name: str
    last_name: str
    policy_id: str
    lob_code: str
    renewal_date: str
    expiring_premium: str
    renewal_premium: str
    recommendations: Sequence[LetterRecommendation] = ()
    language: str = "en"


@dataclass(frozen=True)
class Section:
    section_type: str
    content: dict[str, Any]
    recommendation_id: str | None = None


@dataclass(frozen=True)
class Composition:
    letter_type: str                       # STANDARD | ADVISORY
    template_version: str
    sections: list[Section] = field(default_factory=list)
    draft_wording: bool = True

    @property
    def content_sha256(self) -> str:
        return jsonutil.sha256_hex(jsonutil.canonical(
            {"letter_type": self.letter_type, "template_version": self.template_version,
             "sections": [[s.section_type, s.recommendation_id, s.content] for s in self.sections]}))


def _fill(text: str, values: Mapping[str, Any]) -> str:
    return text.format_map({k: ("" if v is None else v) for k, v in values.items()})


def compose(inputs: LetterInputs) -> Composition:
    t = template()
    included = sorted((r for r in inputs.recommendations if r.status == "INCLUDED"), key=lambda r: r.rank)
    base = {"first_name": inputs.first_name, "last_name": inputs.last_name, "policy_id": inputs.policy_id,
            "lob_label": t["lob_labels"].get(inputs.lob_code, "insurance"), "renewal_date": inputs.renewal_date,
            "expiring_premium": inputs.expiring_premium, "renewal_premium": inputs.renewal_premium}
    core = t["core_renewal_terms"]
    sections = [
        Section("CORE_RENEWAL_TERMS", {"salutation": _fill(core["salutation"], base),
                                       "paragraphs": [_fill(core["renewal"], base), core["vvg40_notice"],
                                                      core["payment"]]}),
        Section("PREMIUM_CHANGE_NOTICE", {"text": _fill(t["premium_change_notice"]["line"], base)}),
    ]
    if not included:
        sections.append(Section("ATTACHMENTS", {"items": [t["attachments"]["standard"]]}))
        return Composition("STANDARD", t["template_version"], sections, draft_wording=t["status"] == "DRAFT")

    adv = t["advisory_block"]
    for r in included:
        if not r.letter_rationale:
            raise ValueError(f"recommendation {r.recommendation_ref} has no validated letter rationale")
        cross = r.opportunity_type == "CROSS_SELL"
        values = {**base, **r.pricing, "product_name": r.product_name}
        rows = adv["table_rows_cross_sell" if cross else "table_rows_upsell"]
        content: dict[str, Any] = {
            "separator_heading": adv["separator_heading"],
            "heading": _fill(adv["heading_cross_sell" if cross else "heading_upsell"], values),
            "rationale": r.letter_rationale, "rationale_origin": r.rationale_origin,
            "table": [[label, r.pricing[key]] for label, key in rows if r.pricing.get(key) is not None],
            "notes": ([_fill(adv["separately_purchasable"], values)] if cross else []) + [adv["instalment_note"]],
        }
        sections.append(Section("ADVISORY_BLOCK", content, r.recommendation_id))
    for r in included:
        saving = r.pricing.get("bundle_saving_annual")
        if r.opportunity_type == "CROSS_SELL" and saving and saving != "0.00":
            sections.append(Section("BUNDLE_SAVINGS", {"text": _fill(t["bundle_savings"]["line"], {
                **r.pricing, "product_name": r.product_name})}, r.recommendation_id))
    sections.append(Section("OPT_IN_INSTRUCTION", {"text": t["opt_in_instruction"]["text"]}))
    sections.append(Section("OBJECTION_NOTICE", {"text": t["objection_notice"]["text"]}))
    att = t["attachments"]
    items = [_fill(att[k], {"product_name": r.product_name}) for r in included for k in ("ipid", "avb")]
    if any(r.opportunity_type == "CROSS_SELL" for r in included):
        items.append(att["withdrawal"])
    sections.append(Section("ATTACHMENTS", {"items": items}))
    draft = t["status"] == "DRAFT" or any(r.draft_wording for r in included)
    return Composition("ADVISORY", t["template_version"], sections, draft_wording=draft)


def section_order_is_valid(sections: Sequence[Section]) -> bool:
    idx = [SECTION_ORDER.index(s.section_type) for s in sections]
    return idx == sorted(idx)
