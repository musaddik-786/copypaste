"""Letter workflow: compose (draft) -> approve (freeze) -> dispatch. Human in the loop throughout (invariant 10).

* compose: allowed when every surfaced recommendation is decided (DECIDED), for SUPPRESSED / EVALUATED cases (standard
  notice), or for an open case once the SLA cut-off is reached - then PENDING / DEFERRED items expire and are not
  included (ADR-012, D-15). Idempotent: the same content gives the same PDF bytes and hash.
* approve: the officer approves the latest draft. It is re-composed from the current record and must match the
  draft byte for byte (otherwise 409 - stale draft). The PDF and its sha256 are frozen.
* dispatch: only an APPROVED letter whose frozen PDF still matches its hash; every advisory block must belong to a
  recommendation that is still INCLUDED. Dispatch closes the operational window.
"""
from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

from sqlalchemy import select, text, update
from sqlalchemy.orm import Session

from sra_api.audit import ledger
from sra_api.cases.action_rules import sla_cutoff
from sra_api.cases.actions import SURFACED, bump, lock_case
from sra_api.cases.state_machine import IllegalTransition, OfficerEvent, transition
from sra_api.clock import utcnow
from sra_api.errors import ProblemError, not_found
from sra_api.letters.composer import Composition, LetterInputs, LetterRecommendation, compose, section_order_is_valid
from sra_api.letters.pdf import render
from sra_api.models import LetterDispatch, LetterDraft, LetterSection, Recommendation, RenewalCase
from sra_api.narrative import service as narrative_service
from sra_api.settings import get_settings

COMPOSE_STATES = ("DECIDED", "SUPPRESSED", "EVALUATED", "LETTER_DRAFTED")
CUTOFF_STATES = ("READY_FOR_REVIEW", "IN_REVIEW")
OPEN_AT_CUTOFF = ("PENDING", "DEFERRED")


@dataclass(frozen=True)
class LetterChange:
    letter_id: uuid.UUID
    version: int
    status: str
    letter_type: str
    content_sha256: str
    case_state: str
    row_version: int
    reused: bool = False


def _move(session: Session, case: RenewalCase, event: OfficerEvent, actor: ledger.Actor) -> None:
    try:
        nxt = transition(case.state, event)
    except IllegalTransition as e:
        raise ProblemError(409, "Illegal state transition", str(e), code="ILLEGAL_TRANSITION", state=case.state) \
            from None
    if nxt != case.state:
        before, case.state = case.state, nxt
        ledger.append(session, actor, case_id=case.case_id, entity_type="CASE", entity_id=str(case.case_id),
                      event_type="STATE_CHANGED", payload={"from": before, "to": nxt, "event": event})


def _surfaced(session: Session, case: RenewalCase) -> list[Recommendation]:
    return list(session.scalars(select(Recommendation).where(
        Recommendation.case_id == case.case_id, Recommendation.decision_run_id == case.current_decision_run_id,
        Recommendation.selection.in_(SURFACED), Recommendation.status != "SUPERSEDED").order_by(Recommendation.rank)))


def _customer(session: Session, case: RenewalCase) -> dict[str, Any]:
    raw = session.execute(text("SELECT raw_payload -> 'customer' FROM sra.policy_snapshot WHERE case_id = :c "
                               "ORDER BY captured_at DESC LIMIT 1"), {"c": case.case_id}).scalar_one_or_none()
    return dict(raw or {})


def _letter_rationale(session: Session, rec: Recommendation, language: str,
                      tokens: dict[str, str]) -> tuple[str | None, str | None, bool]:
    row = session.execute(text(
        "SELECT content, origin FROM sra.narrative WHERE recommendation_id = :r AND audience = 'CUSTOMER_LETTER' "
        "AND language = :l AND validation_status = 'PASSED' ORDER BY version DESC LIMIT 1"),
        {"r": rec.recommendation_id, "l": language}).first()
    if row is None:
        return None, None, False
    rationale = narrative_service.render(row.content.get("letter_rationale"), tokens)
    return rationale, row.origin, bool(row.content.get("draft_wording"))


def build_inputs(session: Session, case: RenewalCase, actor: ledger.Actor, language: str = "en") -> LetterInputs:
    """Everything the composer needs, read from the decision record. Missing letter narratives are generated."""
    cust = _customer(session, case)
    tokens = narrative_service.tokens_for(session, case.case_id)
    recs = []
    for rec in _surfaced(session, case):
        if rec.status != "INCLUDED":
            continue
        rationale, origin, draft = _letter_rationale(session, rec, language, tokens)
        if rationale is None:
            narrative_service.generate(session, rec, "CUSTOMER_LETTER", language, actor)
            rationale, origin, draft = _letter_rationale(session, rec, language, tokens)
        inputs = narrative_service.recommendation_inputs(session, rec)
        recs.append(LetterRecommendation(str(rec.recommendation_id), rec.recommendation_ref, rec.opportunity_type,
                                         inputs["product_name"], rec.status, rec.rank, inputs["pricing"], rationale,
                                         origin, draft))
    name = str(cust.get("full_name") or case.customer_display_name).split(" ")
    return LetterInputs(first_name=name[0], last_name=" ".join(name[1:]), policy_id=case.policy_id,
                        lob_code=case.lob_code, renewal_date=case.renewal_date.isoformat(),
                        expiring_premium=f"{case.expiring_premium:.2f}", renewal_premium=f"{case.renewal_premium:.2f}",
                        recommendations=recs, language=language)


def _pdf_path(case: RenewalCase, version: int) -> Path:
    return get_settings().sra_letter_storage_dir / str(case.case_id) / f"letter-v{version}.pdf"


def _render(case: RenewalCase, comp: Composition) -> bytes:
    if not section_order_is_valid(comp.sections):
        raise ProblemError(500, "Letter sections out of order", code="SECTION_ORDER")  # composer bug - never ship
    return render(comp, title=f"Renewal {case.policy_id}")


def _latest(session: Session, case: RenewalCase, statuses: tuple[str, ...]) -> LetterDraft | None:
    return session.scalars(select(LetterDraft).where(LetterDraft.case_id == case.case_id,
                                                     LetterDraft.status.in_(statuses))
                           .order_by(LetterDraft.version.desc()).limit(1)).first()


def cancel_open_drafts(session: Session, case: RenewalCase, actor: ledger.Actor, reason: str) -> int:
    ids = session.scalars(update(LetterDraft).where(LetterDraft.case_id == case.case_id, LetterDraft.status == "DRAFT")
                          .values(status="CANCELLED").returning(LetterDraft.letter_id)).all()
    for letter_id in ids:
        ledger.append(session, actor, case_id=case.case_id, entity_type="LETTER", entity_id=str(letter_id),
                      event_type="LETTER_CANCELLED", payload={"reason": reason})
    return len(ids)


def _expire_open_items_at_cutoff(session: Session, case: RenewalCase, actor: ledger.Actor) -> int:
    n = 0
    for rec in _surfaced(session, case):
        if rec.status in OPEN_AT_CUTOFF:
            previous, rec.status = rec.status, "EXPIRED"
            n += 1
            ledger.append(session, ledger.SYSTEM, case_id=case.case_id, entity_type="RECOMMENDATION",
                          entity_id=str(rec.recommendation_id), event_type="EXPIRED_AT_SLA_CUTOFF",
                          payload={"recommendation_ref": rec.recommendation_ref, "previous_status": previous,
                                   "sla_cutoff": sla_cutoff(case.letter_due_date).isoformat(),
                                   "triggered_by": actor.actor_id})
    session.flush()
    return n


def compose_draft(session: Session, case_id: uuid.UUID, if_match: int, actor: ledger.Actor, *, today: date,
                  language: str = "en") -> LetterChange:
    case = lock_case(session, case_id, if_match)
    at_cutoff = today >= sla_cutoff(case.letter_due_date)
    if case.state in CUTOFF_STATES and at_cutoff:
        _expire_open_items_at_cutoff(session, case, actor)
        event: OfficerEvent = "SLA_CUTOFF"
    elif case.state in COMPOSE_STATES:
        event = "COMPOSE"
    else:
        detail = (f"case is {case.state}; decide every recommendation first (or wait for the SLA cut-off "
                  f"{sla_cutoff(case.letter_due_date).isoformat()})") if case.state in CUTOFF_STATES \
            else f"case is {case.state}"
        raise ProblemError(409, "Letter cannot be composed", detail, code="LETTER_NOT_COMPOSABLE", state=case.state)

    comp = compose(build_inputs(session, case, actor, language))
    pdf = _render(case, comp)
    sha = hashlib.sha256(pdf).hexdigest()
    current = _latest(session, case, ("DRAFT",))
    if current is not None and current.content_sha256 == sha and current.language == language:
        _move(session, case, event, actor)
        bump(session, case)
        return LetterChange(current.letter_id, current.version, current.status, current.letter_type, sha, case.state,
                            case.row_version, reused=True)

    cancel_open_drafts(session, case, actor, "superseded by a new draft")
    version = int(session.execute(text("SELECT COALESCE(max(version), 0) FROM sra.letter_draft WHERE case_id = :c"),
                                  {"c": case.case_id}).scalar_one()) + 1
    path = _pdf_path(case, version)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(pdf)
    first = next((s.recommendation_id for s in comp.sections if s.section_type == "ADVISORY_BLOCK"), None)
    scenario = None
    if first is not None:
        scenario = session.execute(text("SELECT pricing_scenario_id FROM sra.pricing_scenario "
                                        "WHERE included_recommendation_ids = ARRAY[CAST(:r AS uuid)]"),
                                   {"r": first}).scalar_one_or_none()
    letter = LetterDraft(case_id=case.case_id, version=version, language=language,
                         template_version=comp.template_version, letter_type=comp.letter_type,
                         pricing_scenario_id=scenario, status="DRAFT", rendered_pdf_uri=str(path), content_sha256=sha)
    session.add(letter)
    session.flush()
    session.add_all(LetterSection(letter_id=letter.letter_id, seq=i, section_type=s.section_type,
                                  recommendation_id=uuid.UUID(s.recommendation_id) if s.recommendation_id else None,
                                  content=s.content) for i, s in enumerate(comp.sections, 1))
    ledger.append(session, actor, case_id=case.case_id, entity_type="LETTER", entity_id=str(letter.letter_id),
                  event_type="LETTER_DRAFTED",
                  payload={"version": version, "letter_type": comp.letter_type, "content_sha256": sha,
                           "template_version": comp.template_version, "draft_wording": comp.draft_wording,
                           "advisory_recommendations": [s.recommendation_id for s in comp.sections
                                                        if s.section_type == "ADVISORY_BLOCK"]})
    _move(session, case, event, actor)
    bump(session, case)
    return LetterChange(letter.letter_id, version, "DRAFT", comp.letter_type, sha, case.state, case.row_version)


def _verify_frozen(letter: LetterDraft) -> None:
    path = Path(letter.rendered_pdf_uri or "")
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != letter.content_sha256:
        raise ProblemError(409, "Letter integrity check failed", "the stored PDF does not match its recorded hash",
                           code="LETTER_TAMPERED")


def approve(session: Session, case_id: uuid.UUID, if_match: int, actor: ledger.Actor) -> LetterChange:
    case = lock_case(session, case_id, if_match)
    if case.state != "LETTER_DRAFTED":
        raise ProblemError(409, "Nothing to approve", f"case is {case.state}", code="NOT_DRAFTED", state=case.state)
    pending = [r.recommendation_ref for r in _surfaced(session, case) if r.status in OPEN_AT_CUTOFF]
    if pending:
        raise ProblemError(409, "Recommendations still pending", ", ".join(pending), code="PENDING_RECOMMENDATIONS")
    letter = _latest(session, case, ("DRAFT",))
    if letter is None:
        raise ProblemError(409, "Nothing to approve", "no current draft", code="NOT_DRAFTED")
    _verify_frozen(letter)
    fresh = hashlib.sha256(_render(case, compose(build_inputs(session, case, actor, letter.language)))).hexdigest()
    if fresh != letter.content_sha256:
        raise ProblemError(409, "Draft is stale", "the record changed since the draft was composed; compose again",
                           code="STALE_DRAFT")
    letter.status, letter.approved_by, letter.approved_at = "APPROVED", actor.actor_id, utcnow()
    ledger.append(session, actor, case_id=case.case_id, entity_type="LETTER", entity_id=str(letter.letter_id),
                  event_type="LETTER_APPROVED", payload={"version": letter.version, "letter_type": letter.letter_type,
                                                         "content_sha256": letter.content_sha256})
    _move(session, case, "APPROVE", actor)
    bump(session, case)
    return LetterChange(letter.letter_id, letter.version, letter.status, letter.letter_type,
                        letter.content_sha256 or "", case.state, case.row_version)


def dispatch(session: Session, case_id: uuid.UUID, if_match: int, actor: ledger.Actor) -> tuple[LetterChange, str]:
    case = lock_case(session, case_id, if_match)
    if case.state != "LETTER_APPROVED":
        raise ProblemError(409, "Letter not approved", f"case is {case.state}", code="NOT_APPROVED", state=case.state)
    letter = _latest(session, case, ("APPROVED",))
    if letter is None or not letter.approved_by:
        raise ProblemError(409, "Letter not approved", "no officer-approved letter", code="NOT_APPROVED")
    _verify_frozen(letter)
    # Invariant 10: an advisory block is only sent for a recommendation an officer INCLUDED.
    advisory = session.execute(text(
        "SELECT r.recommendation_ref, r.status FROM sra.letter_section s JOIN sra.recommendation r "
        "USING (recommendation_id) WHERE s.letter_id = :l AND s.section_type = 'ADVISORY_BLOCK'"),
        {"l": letter.letter_id}).all()
    not_included = [ref for ref, status in advisory if status != "INCLUDED"]
    if not_included or (letter.letter_type == "ADVISORY" and not advisory):
        raise ProblemError(409, "Advisory block not authorised", ", ".join(not_included) or "no advisory block",
                           code="ADVISORY_NOT_INCLUDED")
    channel = str(_customer(session, case).get("preferred_channel") or "POST")
    reference = f"OMS-SIM-{letter.letter_id.hex[:12].upper()}"  # POC: no output-management system yet
    session.add(LetterDispatch(letter_id=letter.letter_id, channel=channel, oms_reference=reference,
                               dispatched_at=utcnow(), dispatched_by=actor.actor_id))
    letter.status = "SENT"
    ledger.append(session, actor, case_id=case.case_id, entity_type="LETTER", entity_id=str(letter.letter_id),
                  event_type="LETTER_DISPATCHED", payload={"version": letter.version, "channel": channel,
                                                           "oms_reference": reference,
                                                           "content_sha256": letter.content_sha256})
    _move(session, case, "DISPATCH", actor)
    bump(session, case)
    return (LetterChange(letter.letter_id, letter.version, letter.status, letter.letter_type,
                         letter.content_sha256 or "", case.state, case.row_version), reference)


def current_letter(session: Session, case_id: uuid.UUID) -> dict[str, Any]:
    case = session.get(RenewalCase, case_id)
    if case is None:
        raise not_found("Case", str(case_id))
    letter = _latest(session, case, ("DRAFT", "APPROVED", "SENT"))
    if letter is None:
        raise not_found("Letter draft for case", str(case_id))
    sections = session.execute(text("SELECT seq, section_type, recommendation_id, content FROM sra.letter_section "
                                    "WHERE letter_id = :l ORDER BY seq"), {"l": letter.letter_id}).all()
    return {"letterId": str(letter.letter_id), "caseId": str(case.case_id), "version": letter.version,
            "status": letter.status, "letterType": letter.letter_type, "language": letter.language,
            "templateVersion": letter.template_version, "contentSha256": letter.content_sha256,
            "approvedBy": letter.approved_by,
            "approvedAt": letter.approved_at.isoformat() if letter.approved_at else None,
            "pdfUrl": f"/cases/{case.case_id}/letter-draft/pdf", "pricingScenarioId":
                str(letter.pricing_scenario_id) if letter.pricing_scenario_id else None,
            "sections": [{"seq": s.seq, "sectionType": s.section_type,
                          "recommendationId": str(s.recommendation_id) if s.recommendation_id else None,
                          "content": s.content} for s in sections]}


def letter_pdf_path(session: Session, case_id: uuid.UUID) -> Path:
    case = session.get(RenewalCase, case_id)
    if case is None:
        raise not_found("Case", str(case_id))
    letter = _latest(session, case, ("DRAFT", "APPROVED", "SENT"))
    if letter is None or not letter.rendered_pdf_uri:
        raise not_found("Letter PDF for case", str(case_id))
    _verify_frozen(letter)
    return Path(letter.rendered_pdf_uri)


def as_dict(c: LetterChange) -> dict[str, Any]:
    return {"letterId": str(c.letter_id), "version": c.version, "status": c.status, "letterType": c.letter_type,
            "contentSha256": c.content_sha256, "caseState": c.case_state, "rowVersion": c.row_version,
            "reusedDraft": c.reused}
