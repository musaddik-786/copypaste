"""PDF rendering with reportlab in `invariant` mode: the same composition always yields the same bytes, so the
sha256 recorded at approval can be re-verified at dispatch (the approved letter is frozen - ADR-012)."""
from __future__ import annotations

import io
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import HRFlowable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from reportlab.platypus.flowables import Flowable

from sra_api.letters.composer import Composition, template


def _p(text: str, style: object) -> Paragraph:
    return Paragraph(escape(text), style)


def render(comp: Composition, *, title: str) -> bytes:
    styles = getSampleStyleSheet()
    body, h2, small = styles["BodyText"], styles["Heading2"], styles["Italic"]
    story: list[Flowable] = []
    if comp.draft_wording:
        story += [_p(template()["draft_notice"], small), Spacer(1, 4 * mm)]
    for s in comp.sections:
        c = s.content
        if s.section_type == "CORE_RENEWAL_TERMS":
            story += [_p(c["salutation"], body)] + [_p(x, body) for x in c["paragraphs"]]
        elif s.section_type == "PREMIUM_CHANGE_NOTICE":
            story.append(_p(c["text"], body))
        elif s.section_type == "ADVISORY_BLOCK":
            # BR-13 demarcation: visual separator + "not part of your renewal" heading before every advisory block
            story += [Spacer(1, 6 * mm), HRFlowable(width="100%", thickness=1.2, color=colors.black),
                      _p(c["separator_heading"], h2), _p(c["heading"], styles["Heading3"]), _p(c["rationale"], body)]
            table = Table([[label, f"EUR {value}" if "pct" not in label.lower() and "%" not in label else value]
                           for label, value in c["table"]], colWidths=[110 * mm, 40 * mm])
            table.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
                                       ("ALIGN", (1, 0), (1, -1), "RIGHT"), ("FONTSIZE", (0, 0), (-1, -1), 9)]))
            story += [Spacer(1, 2 * mm), table] + [_p(n, small) for n in c["notes"]]
        elif s.section_type in ("BUNDLE_SAVINGS", "OPT_IN_INSTRUCTION", "OBJECTION_NOTICE"):
            story.append(_p(c["text"], body))
        elif s.section_type == "ATTACHMENTS":
            story += [Spacer(1, 4 * mm), _p("Documents", styles["Heading4"])] + [_p(f"- {i}", body) for i in c["items"]]
        story.append(Spacer(1, 2 * mm))
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title=title, author="Smart Renewal Advisor", invariant=1,
                            leftMargin=20 * mm, rightMargin=20 * mm, topMargin=20 * mm, bottomMargin=20 * mm)
    doc.build(story)
    return buf.getvalue()
