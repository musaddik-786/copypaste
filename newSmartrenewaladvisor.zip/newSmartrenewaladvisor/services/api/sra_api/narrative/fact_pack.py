"""Fact Pack builder - the ONLY data sent to a model (CLAUDE.md invariant 7, contracts/llm/fact_pack.v1).

Pure function over data the decision record already holds:
* recommendation: rule, type, product, tier - no case, policy, customer or quote ids;
* pricing: the strings computed by sra_pricing;
* facts: the fact paths that drove the rule (its rule_evaluation clauses), allow-listed and human-labelled;
* approved benefit / current-gap statements from the catalogue;
* tokens {{FIRST_NAME}} / {{CITY}} instead of any personal reference.
The result is validated against the JSON schema; its sha256 is the narrative cache key.
"""
from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from decimal import Decimal
from functools import lru_cache
from typing import Any

from jsonschema import Draft202012Validator

from sra_api import jsonutil
from sra_api.settings import REPO_ROOT

FACT_PACK_VERSION = "1"
MAX_WORDS_RATIONALE = 60
# Only these fact groups may reach a model; identifiers, prices from PAS and history never do.
ALLOWED_FACT_GROUPS = frozenset({"policy", "vehicle", "motor", "claims", "customer", "property", "pet",
                                 "external", "portfolio", "conduct"})
DENIED_FACTS = frozenset({"customer.customer_id", "policy.expiring_premium", "policy.renewal_premium",
                          "external.vehicle_description", "external.declared_at"})
LABELS = {
    "policy.lob": "Line of business", "policy.coverage_level": "Current motor cover", "policy.tier": "Package tier",
    "vehicle.market_value": "Vehicle market value (EUR)", "vehicle.age_years": "Vehicle age (years)",
    "vehicle.annual_km": "Annual mileage (km)", "motor.bonus_tier": "No-claims class",
    "claims.claims_12m": "Claims in last 12 months", "claims.claims_36m": "Claims in last 36 months",
    "claims.at_fault_24m": "At-fault claims in last 24 months",
    "claims.at_fault_36m": "At-fault claims in last 36 months",
    "claims.open_water_claim_24m": "Water claim in last 24 months",
    "claims.pet_claims_24m": "Pet claims in last 24 months",
    "customer.occupancy": "Occupancy", "customer.dwelling_type": "Dwelling type",
    "customer.household_type": "Household type", "customer.primary_earner": "Primary earner",
    "customer.has_dependants": "Has dependants", "customer.dog_owner": "Dog owner", "customer.cat_owner": "Cat owner",
    "customer.horse_owner": "Horse owner", "customer.household_vehicle_count": "Vehicles in household",
    "customer.high_value_bike_owner": "Owns a high-value bicycle",
    "property.zuers_zone": "Flood hazard zone (ZUeRS)",
    "property.backwater_valve_certified": "Backwater valve certified",
    "property.building_age_years": "Building age (years)",
    "property.has_solar_or_heatpump": "Solar panels or heat pump",
    "property.floor_area_sqm": "Floor area (sqm)", "property.basement_or_ground_floor_storage": "Basement storage",
    "pet.species": "Pet species", "pet.age_years": "Pet age (years)", "pet.cover_tier": "Current pet cover",
    "external.declared_external_vehicle": "Declared a vehicle insured elsewhere",
    "external.declaration_age_months": "Months since the declaration",
    "portfolio.active_products": "Products held", "portfolio.embedded_covers": "Covers already included",
}
PRICING_KEYS = ("expiring_premium", "base_renewal_premium", "incremental_annual", "incremental_monthly_equiv",
                "companion_standalone_annual", "bundle_discount_pct", "bundle_saving_annual", "net_annual_total")


@dataclass(frozen=True)
class Statement:
    key: str
    text: str
    status: str            # APPROVED | DRAFT

    @property
    def is_gap(self) -> bool:
        return self.key.endswith(".GAP")


@dataclass(frozen=True)
class FactPack:
    pack: dict[str, Any]
    sha256: str
    uses_draft_content: bool


@lru_cache
def _schema() -> Draft202012Validator:
    return Draft202012Validator(json.loads((REPO_ROOT / "contracts/llm/fact_pack.v1.schema.json").read_text(
        encoding="utf-8")))


def _label(path: str) -> str:
    return LABELS.get(path, path.split(".")[-1].replace("_", " ").capitalize())


def _facts(clauses: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for cl in clauses:
        path = cl.get("left")
        if not isinstance(path, str) or path in DENIED_FACTS or path in out:
            continue
        if path.split(".")[0] not in ALLOWED_FACT_GROUPS:
            continue
        value = cl.get("left_value")
        out[path] = {"key": path, "label": _label(path),
                     "value": str(value) if isinstance(value, Decimal) else value}
    return list(out.values())


def build(*, rule_id: str, opportunity_type: str, product_code: str, product_name: str, priority_tier: str,
          pricing: Mapping[str, str], clauses: Sequence[Mapping[str, Any]], statements: Sequence[Statement],
          audience: str, language: str = "en") -> FactPack:
    officer = audience == "OFFICER"
    pack: dict[str, Any] = {
        "fact_pack_version": FACT_PACK_VERSION,
        "language": language,
        "audience": audience,
        "tokens": {"first_name": "{{FIRST_NAME}}", "city": "{{CITY}}"},
        "recommendation": {"rule_id": rule_id, "opportunity_type": opportunity_type, "product_code": product_code,
                           "product_name": product_name, "priority_tier": priority_tier},
        "pricing": {k: pricing[k] for k in PRICING_KEYS if pricing.get(k) is not None},
        "facts": _facts(clauses),
        "current_gap": [s.text for s in statements if s.is_gap],
        "approved_benefits": [{"statement_key": s.key, "text": s.text} for s in statements if not s.is_gap],
        "style": {"person": "THIRD_PERSON_OFFICER" if officer else "SECOND_PERSON_CUSTOMER",
                  "max_words_rationale": MAX_WORDS_RATIONALE,
                  "formality": "Sie" if language == "de" else "neutral_en"},
    }
    errors = list(_schema().iter_errors(pack))
    if errors:
        raise ValueError(f"fact pack violates fact_pack.v1: {errors[0].message}")
    return FactPack(pack, jsonutil.sha256_hex(jsonutil.canonical(pack)),
                    uses_draft_content=any(s.status == "DRAFT" for s in statements))
