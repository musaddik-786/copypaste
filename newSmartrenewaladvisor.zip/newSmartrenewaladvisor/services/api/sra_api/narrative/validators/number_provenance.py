"""2. NUMBER_PROVENANCE - every number in the text must come from the fact pack (pricing or facts).

EN ("€45.60", "1,234.56") and DE ("45,60 €", "1.234,56") formats are normalised to a Decimal before comparing,
so 45.6 == 45.60. Numbers glued to letters or hyphens (rule ids such as CS-LIA-01) are not treated as amounts.
The self-declared `used_numbers` must also be fact-pack numbers, and must list every number the text uses.
"""
from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from decimal import Decimal, InvalidOperation
from typing import Any

from sra_api.narrative.validators.base import Finding, ValidationContext, ValidatorResult, strip_tokens, texts

NAME = "NUMBER_PROVENANCE"
NUMBER = re.compile(r"(?<![\w.,-])\d+(?:[.,\u00a0]\d+)*")  # no plain space: "2026 12" is two numbers


def normalise(raw: str) -> Decimal | None:
    s = raw.replace("\u00a0", "")
    if "." in s and "," in s:  # the later separator is the decimal mark
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        head, _, tail = s.rpartition(",")
        s = f"{head.replace(',', '')}.{tail}" if len(tail) <= 2 else s.replace(",", "")
    elif s.count(".") == 1:
        head, _, tail = s.partition(".")
        s = s if len(tail) <= 2 else head + tail  # 1.234 (DE thousands) vs 45.60
    else:
        s = s.replace(".", "")
    try:
        return Decimal(s)
    except InvalidOperation:
        return None


def numbers_in(text: str) -> list[tuple[str, Decimal]]:
    out = []
    for m in NUMBER.finditer(strip_tokens(text)):
        raw = m.group(0)
        value = normalise(raw)
        if value is not None:
            out.append((raw, value))
    return out


def _collect(values: Iterable[Any]) -> set[Decimal]:
    found: set[Decimal] = set()
    for v in values:
        if isinstance(v, bool) or v is None:
            continue
        if isinstance(v, int | float | Decimal):
            found.add(Decimal(str(v)))
        elif isinstance(v, str):
            found.update(n for _, n in numbers_in(v))
        elif isinstance(v, list | tuple):
            found |= _collect(v)
    return found


def allowed_numbers(pack: Mapping[str, Any]) -> set[Decimal]:
    vals: list[Any] = list((pack.get("pricing") or {}).values())
    vals += [f.get("value") for f in pack.get("facts") or []]
    vals += [b.get("text") for b in pack.get("approved_benefits") or []]
    vals += list(pack.get("current_gap") or [])
    return _collect(vals)


def check(output: Mapping[str, Any], pack: Mapping[str, Any], ctx: ValidationContext, *,
          require_used_numbers: bool = True) -> ValidatorResult:
    allowed = allowed_numbers(pack)
    declared = {n for raw in output.get("used_numbers") or [] for _, n in numbers_in(str(raw))}
    findings = [Finding(f"used_numbers lists {n} which is not in the fact pack", "used_numbers")
                for n in sorted(declared - allowed)]
    for fld, text in texts(output):
        for raw, value in numbers_in(text):
            if value not in allowed:
                findings.append(Finding(f"number {raw!r} does not appear in pricing or facts", fld))
            elif require_used_numbers and value not in declared:
                findings.append(Finding(f"number {raw!r} is used but missing from used_numbers", fld))
    return ValidatorResult(NAME, findings)
