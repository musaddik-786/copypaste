"""Narrative validators (CLAUDE.md invariant 9). Generated text is shown only if every validator passes;
otherwise the service retries once and then falls back to the static template.

Validators 8 (CONTENT_SAFETY) and 9 (GROUNDEDNESS) need Azure AI Content Safety, which the POC does not have yet;
they are not run and therefore not recorded.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

from sra_api.narrative.validators import (
    approved_claims,
    length_readability,
    number_provenance,
    pii_leak,
    prohibited_phrases,
    protected_attributes,
    schema,
)
from sra_api.narrative.validators.base import Finding, ValidationContext, ValidatorResult

Check = Callable[[Mapping[str, Any], Mapping[str, Any], ValidationContext], ValidatorResult]

ALL: list[tuple[str, Check]] = [
    (schema.NAME, schema.check),
    (number_provenance.NAME, number_provenance.check),
    (approved_claims.NAME, approved_claims.check),
    (prohibited_phrases.NAME, prohibited_phrases.check),
    (pii_leak.NAME, pii_leak.check),
    (protected_attributes.NAME, protected_attributes.check),
    (length_readability.NAME, length_readability.check),
]


def run_all(output: Any, pack: Mapping[str, Any], ctx: ValidationContext) -> list[ValidatorResult]:
    """Runs SCHEMA first; the content validators only run on schema-valid output."""
    first = schema.check(output, pack, ctx)
    if not first.passed:
        return [first]
    return [first] + [check(output, pack, ctx) for name, check in ALL[1:]]


def run_officer_edit(output: Mapping[str, Any], pack: Mapping[str, Any], ctx: ValidationContext
                     ) -> list[ValidatorResult]:
    """Officer edits are re-validated with validators 2-6 (docs/04 §4.2); numbers need no used_numbers list."""
    return [number_provenance.check(output, pack, ctx, require_used_numbers=False),
            approved_claims.check(output, pack, ctx), prohibited_phrases.check(output, pack, ctx),
            pii_leak.check(output, pack, ctx), protected_attributes.check(output, pack, ctx)]


def passed(results: list[ValidatorResult]) -> bool:
    return all(r.passed for r in results)


def findings(results: list[ValidatorResult]) -> list[dict[str, Any]]:
    return [{"validator": r.validator, **f.as_dict()} for r in results for f in r.findings]


__all__ = ["ALL", "Finding", "ValidationContext", "ValidatorResult", "findings", "passed", "run_all",
           "run_officer_edit"]
