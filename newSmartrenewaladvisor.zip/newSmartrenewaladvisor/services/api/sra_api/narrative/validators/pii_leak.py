"""5. PII_LEAK - no personal data in generated text (invariant 7). Tokens {{FIRST_NAME}} / {{CITY}} are exempt.

Checks business identifiers, IBANs, e-mail addresses, phone numbers and German number plates, plus the real
personal values of this case (names, street, postcode, city, date of birth) that only the server knows.
"""
from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from sra_api.narrative.validators.base import Finding, ValidationContext, ValidatorResult, strip_tokens, texts

NAME = "PII_LEAK"
ISO_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")
PATTERNS = {
    "business identifier": re.compile(r"\b(?:POL|CUST|QUO|REC|CLM|CMP)-[A-Z0-9-]{3,}\b", re.IGNORECASE),
    "IBAN": re.compile(r"\b[A-Z]{2}\d{2}(?:\s?[A-Z0-9]{4}){3,7}(?:\s?[A-Z0-9]{1,3})?\b"),
    "e-mail address": re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"),
    "phone number": re.compile(r"(?<![\d.,])\+?\d[\d /-]{8,}\d(?![\d.,])"),
    "number plate": re.compile(r"\b[A-ZÄÖÜ]{1,3}-[A-Z]{1,2}\s?\d{1,4}[EH]?\b"),
}


def check(output: Mapping[str, Any], pack: Mapping[str, Any], ctx: ValidationContext) -> ValidatorResult:
    findings: list[Finding] = []
    known = [v for v in ctx.sensitive_values if v and len(v) >= 2]
    for fld, raw in texts(output):
        text = strip_tokens(raw)
        for kind, pattern in PATTERNS.items():
            hits = [m.group(0) for m in pattern.finditer(text)]
            if kind == "phone number":
                hits = [h for h in hits if not ISO_DATE.fullmatch(h.strip())]  # 2026-10-13 is a date, not a phone
            if hits:
                findings.append(Finding(f"contains a {kind}", fld))
        for value in known:
            if re.search(r"(?<!\w)" + re.escape(value) + r"(?!\w)", text, re.IGNORECASE):
                findings.append(Finding("contains personal data of the customer (use the tokens instead)", fld))
                break
    return ValidatorResult(NAME, findings)
