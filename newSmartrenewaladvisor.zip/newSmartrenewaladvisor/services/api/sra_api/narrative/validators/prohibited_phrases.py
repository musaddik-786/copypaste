"""4. PROHIBITED_PHRASES - Compliance lexicon ai/guardrails/prohibited_phrases.yaml (DE + EN, case-insensitive,
word boundary). BLOCK fails the narrative; WARN passes but is flagged to the officer.

Lexicon exceptions: `allow_if_approved_statement` (the phrase appears in an approved statement of the fact pack)
and `allow_if_fact: jurisdiction.mandatory == true`.
"""
from __future__ import annotations

from collections.abc import Mapping
from functools import lru_cache
from typing import Any

import yaml

from sra_api.narrative.validators.base import Finding, ValidationContext, ValidatorResult, term_pattern, texts
from sra_api.settings import REPO_ROOT

NAME = "PROHIBITED_PHRASES"


@lru_cache
def lexicon() -> dict[str, Any]:
    data: dict[str, Any] = yaml.safe_load((REPO_ROOT / "ai/guardrails/prohibited_phrases.yaml").read_text(
        encoding="utf-8"))
    return data


def _mandatory_fact(pack: Mapping[str, Any]) -> bool:
    return any(f.get("key") == "jurisdiction.mandatory" and f.get("value") is True for f in pack.get("facts") or [])


def check(output: Mapping[str, Any], pack: Mapping[str, Any], ctx: ValidationContext) -> ValidatorResult:
    statements = " ".join(b.get("text", "") for b in pack.get("approved_benefits") or [])
    findings: list[Finding] = []
    for rule in lexicon()["rules"]:
        for term in list(rule.get("en", [])) + list(rule.get("de", [])):
            pattern = term_pattern(term)
            if rule.get("allow_if_approved_statement") and pattern.search(statements):
                continue
            if rule.get("allow_if_fact") and _mandatory_fact(pack):
                continue
            for fld, text in texts(output):
                if pattern.search(text):
                    findings.append(Finding(f"{rule['id']}: {term!r}", fld, rule.get("severity", "BLOCK")))
    return ValidatorResult(NAME, findings)
