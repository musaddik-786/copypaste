"""Shared types and text helpers for the narrative validators (CLAUDE.md invariant 9, docs/04 §4.2).

Validators are pure functions: (narrative output, fact pack, context) -> ValidatorResult. They never call a model.
"""
from __future__ import annotations

import re
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, field
from typing import Any

TOKENS = ("{{FIRST_NAME}}", "{{CITY}}")
TEXT_FIELDS = ("why_recommended", "current_gap", "how_it_helps", "letter_rationale")


@dataclass(frozen=True)
class Finding:
    message: str
    field: str | None = None
    severity: str = "BLOCK"   # BLOCK fails the validator; WARN is shown to the officer but passes

    def as_dict(self) -> dict[str, Any]:
        return {"message": self.message, "field": self.field, "severity": self.severity}


@dataclass(frozen=True)
class ValidatorResult:
    validator: str
    findings: list[Finding] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not any(f.severity == "BLOCK" for f in self.findings)


@dataclass(frozen=True)
class ValidationContext:
    """Server-side knowledge the model never sees: real personal values that must not appear in the text."""
    sensitive_values: tuple[str, ...] = ()


def texts(output: Mapping[str, Any]) -> Iterator[tuple[str, str]]:
    """(field, text) for every free-text field, including comparison rows."""
    for f in TEXT_FIELDS:
        v = output.get(f)
        if isinstance(v, str):
            yield f, v
    for i, row in enumerate(output.get("comparison_rows") or []):
        if isinstance(row, Mapping):
            for k in ("label", "current", "improved"):
                if isinstance(row.get(k), str):
                    yield f"comparison_rows[{i}].{k}", row[k]


def strip_tokens(text: str) -> str:
    for t in TOKENS:
        text = text.replace(t, " ")
    return text


def sentences(text: str) -> list[str]:
    """Split on sentence-ending punctuation followed by whitespace or the end (decimals like 543.40 survive)."""
    parts = re.split(r"(?<=[.!?])\s+", strip_tokens(text).strip())
    return [p for p in parts if re.search(r"\w", p)]


def words(text: str) -> list[str]:
    return re.findall(r"[^\W\d_]+(?:['\u2019-][^\W\d_]+)*", strip_tokens(text))  # also curly apostrophes


def term_pattern(term: str) -> re.Pattern[str]:
    """Case-insensitive, word-boundary match. A term ending in '*' (or the stems 'pregnan'/'schwanger') matches
    as a prefix."""
    prefix = term.endswith("*") or term.lower() in ("pregnan", "schwanger")
    body = re.escape(term.rstrip("*"))
    return re.compile(r"(?<!\w)" + body + (r"\w*" if prefix else r"(?!\w)"), re.IGNORECASE)
