"""6. PROTECTED_ATTRIBUTES - no age, health, nationality, religion, gender or pregnancy references.

Exceptions from the lexicon (`except_fact_keys`): when the fact pack contains pet.age_years, vehicle.age_years or
property.building_age_years, the age terms are allowed (they describe the insured object, not the customer).
Terms that are part of the recommended product's name (e.g. "Pet Health & Surgery Cover") are domain words and
allowed too.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from sra_api.narrative.validators.base import Finding, ValidationContext, ValidatorResult, term_pattern, texts
from sra_api.narrative.validators.prohibited_phrases import lexicon

NAME = "PROTECTED_ATTRIBUTES"
AGE_TERMS = frozenset({"age", "years old", "alter", "jahre alt"})


def check(output: Mapping[str, Any], pack: Mapping[str, Any], ctx: ValidationContext) -> ValidatorResult:
    cfg = lexicon()["protected_attribute_terms"]
    exempt_keys = set(cfg.get("except_fact_keys", []))
    object_age_present = any(f.get("key") in exempt_keys for f in pack.get("facts") or [])
    product_name = str((pack.get("recommendation") or {}).get("product_name", ""))
    findings: list[Finding] = []
    for term in list(cfg.get("en", [])) + list(cfg.get("de", [])):
        if object_age_present and term.lower() in AGE_TERMS:
            continue
        pattern = term_pattern(term)
        if pattern.search(product_name):
            continue
        for fld, text in texts(output):
            if pattern.search(text):
                findings.append(Finding(f"protected attribute term {term!r}", fld, cfg.get("severity", "BLOCK")))
    return ValidatorResult(NAME, findings)
