"""7. LENGTH_READABILITY - sentence limits from the prompt (narrative_system.v1.md) and plain-language readability.

why_recommended <= 3 sentences, current_gap <= 2, how_it_helps <= 3, letter_rationale exactly 2 and at most
`style.max_words_rationale` words; 3-5 benefit keys (fewer only if fewer are approved). Readability: Flesch reading
ease (EN) / Flesch-Amstad (DE) of the whole text (product name excluded) must reach MIN_READING_EASE.
"""
from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from sra_api.narrative.validators.base import Finding, ValidationContext, ValidatorResult, sentences, texts, words

NAME = "LENGTH_READABILITY"
MAX_SENTENCES = {"why_recommended": 3, "current_gap": 2, "how_it_helps": 3}
LETTER_SENTENCES = 2
MIN_KEYS, MAX_KEYS = 3, 5
MIN_READING_EASE = 30.0


def syllables(word: str) -> int:
    groups = re.findall(r"[aeiouyäöü]+", word.lower())
    n = len(groups)
    if word.lower().endswith("e") and n > 1:
        n -= 1
    return max(n, 1)


def reading_ease(text: str, language: str) -> float:
    ws = words(text)
    sents = max(len(sentences(text)), 1)
    if not ws:
        return 100.0
    asl = len(ws) / sents
    asw = sum(syllables(w) for w in ws) / len(ws)
    if language == "de":
        return 180 - asl - 58.5 * asw          # Flesch-Amstad
    return 206.835 - 1.015 * asl - 84.6 * asw  # Flesch reading ease


def check(output: Mapping[str, Any], pack: Mapping[str, Any], ctx: ValidationContext) -> ValidatorResult:
    findings: list[Finding] = []
    for fld, limit in MAX_SENTENCES.items():
        n = len(sentences(str(output.get(fld, ""))))
        if n == 0:
            findings.append(Finding("must not be empty", fld))
        elif n > limit:
            findings.append(Finding(f"{n} sentences, at most {limit} allowed", fld))
    letter = str(output.get("letter_rationale", ""))
    if len(sentences(letter)) != LETTER_SENTENCES:
        findings.append(Finding(f"must be exactly {LETTER_SENTENCES} sentences", "letter_rationale"))
    max_words = int((pack.get("style") or {}).get("max_words_rationale") or 0)
    if max_words and len(words(letter)) > max_words:
        findings.append(Finding(f"{len(words(letter))} words, at most {max_words} allowed", "letter_rationale"))

    available = len(pack.get("approved_benefits") or [])
    keys = len(output.get("key_benefit_keys") or [])
    lo, hi = min(MIN_KEYS, available), min(MAX_KEYS, available)
    if not lo <= keys <= hi:
        findings.append(Finding(f"{keys} benefit keys, expected {lo}-{hi}", "key_benefit_keys"))

    # The product name is fixed catalogue vocabulary, not the model's wording - it is left out of the score.
    whole = " ".join(t for _, t in texts(output))
    product = str((pack.get("recommendation") or {}).get("product_name", ""))
    if product:
        whole = re.sub(re.escape(product), "it", whole, flags=re.IGNORECASE)
    score = reading_ease(whole, str(pack.get("language", "en")))
    if score < MIN_READING_EASE:
        findings.append(Finding(f"reading ease {score:.0f} below {MIN_READING_EASE:.0f}", None))
    return ValidatorResult(NAME, findings)
