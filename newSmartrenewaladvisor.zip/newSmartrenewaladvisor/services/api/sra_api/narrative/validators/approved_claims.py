"""3. APPROVED_CLAIMS - benefits may only come from the approved (or, for synthetic demos, draft) catalogue.

* every `key_benefit_keys` entry must be a statement_key from the fact pack's `approved_benefits`;
* each `how_it_helps` sentence must be lexically supported by an approved benefit statement (POC: content-word
  overlap with light stemming, calibrated so paraphrases (>= 0.5)
  pass and invented benefits (~0.3) fail; the embedding similarity check of docs/04 §4.2 replaces this later);
* without approved benefits, no benefit keys and no `how_it_helps` claims beyond the product name are allowed.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from sra_api.narrative.validators.base import Finding, ValidationContext, ValidatorResult, sentences, words

NAME = "APPROVED_CLAIMS"
MIN_SUPPORT = 0.5    # share of a sentence's content words (stemmed) found in one approved statement
STOPWORDS = frozenset("""a an and are as at be by can for from has have if in into is it its of on or that the
their them they this to with without your you our we will would also which who when where while than then
there these those such any all not but been being do does more most other over under after before about
""".split())  # noqa: SIM905 - a word list reads better as text


# Words that point to the documents or the price without asserting any benefit. A sentence made only of these
# (e.g. "The details of the cover are set out in the product information document.") is not a claim.
NEUTRAL = frozenset({"detail", "cover", "product", "information", "document", "policy", "term", "condition",
                     "price", "shown", "below", "separately", "optional", "insurance", "out"})
SUFFIXES = ("ingly", "edly", "ing", "ies", "ied", "ed", "es", "ly", "s")


def _stem(word: str) -> str:
    w = word.lower()
    for suf in SUFFIXES:
        if w.endswith(suf) and len(w) - len(suf) >= 4:
            return w[: -len(suf)]
    return w


def _content(text: str) -> set[str]:
    return {_stem(w) for w in words(text) if len(w) > 3 and w.lower() not in STOPWORDS}


def check(output: Mapping[str, Any], pack: Mapping[str, Any], ctx: ValidationContext) -> ValidatorResult:
    approved = {b["statement_key"]: b["text"] for b in pack.get("approved_benefits") or []}
    findings: list[Finding] = []
    keys = list(output.get("key_benefit_keys") or [])
    if len(set(keys)) != len(keys):
        findings.append(Finding("key_benefit_keys contains duplicates", "key_benefit_keys"))
    findings += [Finding(f"{k!r} is not an approved benefit statement", "key_benefit_keys")
                 for k in keys if k not in approved]

    support = [_content(t) for t in approved.values()]
    product = _content(str((pack.get("recommendation") or {}).get("product_name", "")))
    for s in sentences(str(output.get("how_it_helps", ""))):
        words_ = _content(s) - product
        if not words_ or words_ <= NEUTRAL:
            continue
        best = max((len(words_ & sup) / len(words_) for sup in support), default=0.0)
        if best < MIN_SUPPORT:
            findings.append(Finding(f"benefit claim not supported by an approved statement: {s!r}", "how_it_helps"))
    return ValidatorResult(NAME, findings)
