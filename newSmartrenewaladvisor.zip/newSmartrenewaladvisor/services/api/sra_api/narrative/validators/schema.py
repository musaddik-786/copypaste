"""1. SCHEMA - the output must match contracts/llm/narrative_output.v1.schema.json exactly."""
from __future__ import annotations

import json
from collections.abc import Mapping
from functools import lru_cache
from typing import Any

from jsonschema import Draft202012Validator

from sra_api.narrative.validators.base import Finding, ValidationContext, ValidatorResult
from sra_api.settings import REPO_ROOT

NAME = "SCHEMA"


@lru_cache
def _validator() -> Draft202012Validator:
    schema = json.loads((REPO_ROOT / "contracts/llm/narrative_output.v1.schema.json").read_text(encoding="utf-8"))
    return Draft202012Validator(schema)


def check(output: Any, pack: Mapping[str, Any], ctx: ValidationContext) -> ValidatorResult:
    if not isinstance(output, Mapping):
        return ValidatorResult(NAME, [Finding("output is not a JSON object")])
    errors = sorted(_validator().iter_errors(dict(output)), key=lambda e: list(e.path))
    return ValidatorResult(NAME, [Finding(e.message, ".".join(str(p) for p in e.path) or None) for e in errors])
