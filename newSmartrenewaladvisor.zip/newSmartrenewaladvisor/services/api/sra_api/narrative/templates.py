"""Static fallback narrative ("standard wording") - used whenever the model is unavailable, the route is refused,
or the generated text fails validation twice (docs/04 §4.2). Deterministic and built only from the fact pack, so it
passes the same validators. The wording is a POC placeholder until Compliance approves templates per product.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def fallback(pack: Mapping[str, Any]) -> dict[str, Any]:
    rec = pack["recommendation"]
    product = rec["product_name"]
    cross_sell = rec["opportunity_type"] == "CROSS_SELL"
    benefits = list(pack.get("approved_benefits") or [])
    gaps = list(pack.get("current_gap") or [])
    officer = pack.get("audience") == "OFFICER"
    who = "{{FIRST_NAME}}'s" if officer else "your"
    return {
        "why_recommended": f"The rules engine selected {product} because {who} verified record meets the "
                           "criteria for this recommendation.",
        "current_gap": gaps[0] if gaps else f"The current cover does not include {product}.",
        "how_it_helps": benefits[0]["text"] if benefits else "The details of the cover are set out in the product "
                                                               "information document.",
        "key_benefit_keys": [b["statement_key"] for b in benefits[:3]],
        "letter_rationale": (f"Based on the information we hold, {product} could complement your existing cover. "
                             "It is a separate, optional policy and its price is shown below.") if cross_sell else
                            (f"Based on the information we hold, {product} could be added to your renewal. "
                             "It is optional and its price is shown separately below."),
        "used_numbers": [],
    }
