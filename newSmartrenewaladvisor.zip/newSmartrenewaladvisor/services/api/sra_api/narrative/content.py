"""Catalogue content for narratives: benefit / current-gap statements and the prompt template.

APPROVED content is always usable. DRAFT content (not yet Compliance-approved) is used only when
SRA_ALLOW_DRAFT_STATEMENTS=true AND the data class is SYNTHETIC; cards then say "draft wording".
"""
from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import text
from sqlalchemy.orm import Session

from sra_api.narrative.fact_pack import Statement
from sra_api.settings import Settings

PROMPT_PURPOSE = {"OFFICER": "NARRATIVE_OFFICER", "CUSTOMER_LETTER": "NARRATIVE_LETTER"}


@dataclass(frozen=True)
class Prompt:
    template_id: str
    body: str
    status: str


def draft_allowed(settings: Settings, data_class: str) -> bool:
    return settings.sra_allow_draft_statements and data_class == "SYNTHETIC"


def _statuses(allow_draft: bool) -> list[str]:
    return ["APPROVED", "DRAFT"] if allow_draft else ["APPROVED"]


def statements(session: Session, product_code: str, language: str, *, allow_draft: bool) -> list[Statement]:
    """Latest version of each statement key for the product, approved first."""
    rows = session.execute(text(
        "SELECT DISTINCT ON (statement_key) statement_key, statement_text, status "
        "FROM ref.product_benefit_statement WHERE product_code = :p AND language = :l AND status = ANY(:s) "
        "ORDER BY statement_key, (status = 'APPROVED') DESC, version DESC"),
        {"p": product_code, "l": language, "s": _statuses(allow_draft)}).all()
    return [Statement(r.statement_key, r.statement_text, r.status) for r in rows]


def prompt(session: Session, audience: str, *, allow_draft: bool) -> Prompt | None:
    row = session.execute(text(
        "SELECT prompt_template_id, body, status FROM sra.prompt_template WHERE purpose = :p AND status = ANY(:s) "
        "ORDER BY (status = 'APPROVED') DESC, prompt_template_id DESC LIMIT 1"),
        {"p": PROMPT_PURPOSE[audience], "s": _statuses(allow_draft)}).first()
    return Prompt(row.prompt_template_id, row.body, row.status) if row else None
