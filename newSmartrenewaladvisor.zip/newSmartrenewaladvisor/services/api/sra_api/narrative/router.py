"""ModelRouter - which deployment may receive which class of data (CLAUDE.md invariant 8, ADR-008). Fails closed.

* Real or pseudonymised customer data only to deployments with data_boundary = EU.
* Claude on Foundry only for SYNTHETIC data and only with SRA_ALLOW_SYNTHETIC_CLAUDE=true.
* The data class must be listed in the deployment's allowed_data_classes, and the deployment must be active.
A refused route never calls a model: the caller uses the static template.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from sqlalchemy import text
from sqlalchemy.orm import Session

DataClass = Literal["SYNTHETIC", "PSEUDONYMISED"]


@dataclass(frozen=True)
class Deployment:
    name: str
    provider: str
    model_id: str
    deployment_type: str
    data_boundary: str
    allowed_data_classes: tuple[str, ...]
    active: bool


@dataclass(frozen=True)
class RouteDecision:
    deployment: Deployment | None
    reason: str

    @property
    def allowed(self) -> bool:
        return self.deployment is not None


def route(dep: Deployment | None, data_class: DataClass, *, allow_synthetic_claude: bool) -> RouteDecision:
    """Pure routing decision for one deployment row."""
    if dep is None:
        return RouteDecision(None, "narrative model is not registered in sra.model_deployment")
    if not dep.active:
        return RouteDecision(None, f"deployment {dep.name} is inactive")
    if data_class not in dep.allowed_data_classes:
        return RouteDecision(None, f"{data_class} data is not allowed for {dep.name} "
                                   f"(allowed: {', '.join(dep.allowed_data_classes)})")
    if data_class != "SYNTHETIC" and dep.data_boundary != "EU":
        return RouteDecision(None, f"{data_class} data requires an EU data boundary; {dep.name} is {dep.data_boundary}")
    if dep.provider == "ANTHROPIC_FOUNDRY" and (data_class != "SYNTHETIC" or not allow_synthetic_claude):
        return RouteDecision(None, "Claude on Foundry is allowed only for SYNTHETIC data "
                                   "with SRA_ALLOW_SYNTHETIC_CLAUDE")
    return RouteDecision(dep, "ok")


def load_deployment(session: Session, name: str) -> Deployment | None:
    if not name:
        return None
    row: Any = session.execute(text(
        "SELECT * FROM sra.model_deployment WHERE deployment_name = :n"), {"n": name}).mappings().first()
    if row is None:
        return None
    return Deployment(row["deployment_name"], row["provider"], row["model_id"], row["deployment_type"],
                      row["data_boundary"], tuple(row["allowed_data_classes"]), row["active"])
