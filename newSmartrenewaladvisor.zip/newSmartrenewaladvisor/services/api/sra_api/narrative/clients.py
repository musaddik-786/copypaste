"""Model clients behind one small interface. Only the Narrative Service imports this module - never the decision
path (enforced by tests/architecture).

* AzureOpenAIClient: keyless - Microsoft Entra token from DefaultAzureCredential (az login locally, managed
  identity in Azure). No API key is read or stored anywhere.
* FakeClient: deterministic test double that answers from the fact pack itself.
"""
from __future__ import annotations

import json
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Protocol, cast

from sra_api.settings import Settings

COGNITIVE_SCOPE = "https://cognitiveservices.azure.com/.default"
TEMPERATURE = 0.2


@dataclass(frozen=True)
class Completion:
    text: str
    input_tokens: int | None
    output_tokens: int | None
    finish_reason: str | None
    latency_ms: int


class NarrativeClient(Protocol):
    def complete(self, deployment: str, messages: Sequence[dict[str, str]]) -> Completion: ...


class AzureOpenAIClient:
    def __init__(self, settings: Settings) -> None:
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        from openai import AzureOpenAI

        if not settings.azure_openai_endpoint:
            raise RuntimeError("AZURE_OPENAI_ENDPOINT is not configured")
        token_provider = get_bearer_token_provider(
            DefaultAzureCredential(exclude_interactive_browser_credential=True), COGNITIVE_SCOPE)
        self._client = AzureOpenAI(azure_endpoint=settings.azure_openai_endpoint,
                                   api_version=settings.azure_openai_api_version,
                                   azure_ad_token_provider=token_provider,
                                   timeout=settings.sra_narrative_timeout_s, max_retries=1)

    def complete(self, deployment: str, messages: Sequence[dict[str, str]]) -> Completion:
        t0 = time.perf_counter()
        r = self._client.chat.completions.create(model=deployment, messages=cast(Any, list(messages)),
                                                 temperature=TEMPERATURE, response_format={"type": "json_object"})
        choice = r.choices[0]
        return Completion(choice.message.content or "", r.usage.prompt_tokens if r.usage else None,
                          r.usage.completion_tokens if r.usage else None, choice.finish_reason,
                          int((time.perf_counter() - t0) * 1000))


class FakeClient:
    """Answers with valid narrative JSON built from the fact pack in the prompt. `script` can override replies
    (e.g. to simulate invalid output or failures) - each call pops the next entry."""

    def __init__(self, script: list[str | Exception | Callable[[dict[str, Any]], str]] | None = None) -> None:
        self.script = list(script or [])
        self.calls: list[Sequence[dict[str, str]]] = []

    def complete(self, deployment: str, messages: Sequence[dict[str, str]]) -> Completion:
        self.calls.append(messages)
        pack = _pack_from_prompt(messages[0]["content"])
        reply: str | Exception | Callable[[dict[str, Any]], str] = self.script.pop(0) if self.script else valid_reply
        if isinstance(reply, Exception):
            raise reply
        text = reply(pack) if callable(reply) else reply
        return Completion(text, 100, 80, "stop", 1)


def _pack_from_prompt(system_prompt: str) -> dict[str, Any]:
    start, end = system_prompt.rfind("```json"), system_prompt.rfind("```")
    data: dict[str, Any] = json.loads(system_prompt[start + len("```json"):end])
    return data


def valid_reply(pack: dict[str, Any]) -> str:
    """A compliant answer that uses only fact-pack content (what a well-behaved model should return)."""
    rec = pack["recommendation"]
    product = rec["product_name"]
    benefits = pack["approved_benefits"]
    gap =pack["current_gap"][0] if pack["current_gap"] else f"The current cover does not include {product}."
    optional = " It is optional and can be taken out separately." if rec["opportunity_type"] == "CROSS_SELL" else ""
    return json.dumps({
        "why_recommended": f"{{{{FIRST_NAME}}}}'s verified record matches the criteria for {product}.",
        "current_gap": gap,
        "how_it_helps": benefits[0]["text"] if benefits else f"{product} adds to the existing cover.",
        "key_benefit_keys": [b["statement_key"] for b in benefits[:3]],
        "letter_rationale": f"Based on the information we hold, {product} could suit your situation.{optional}"
                            + ("" if optional else " The price is shown separately below."),
        "used_numbers": [],  # this reply quotes no numbers
    })


@lru_cache
def _azure(settings_key: tuple[str, str, float]) -> AzureOpenAIClient:
    from sra_api.settings import get_settings
    return AzureOpenAIClient(get_settings())


_override: NarrativeClient | None = None


def set_client_override(client: NarrativeClient | None) -> None:
    """Tests inject a FakeClient here."""
    global _override
    _override = client


def get_client(settings: Settings) -> NarrativeClient:
    if _override is not None:
        return _override
    if settings.sra_narrative_client == "fake":
        return FakeClient()
    return _azure((settings.azure_openai_endpoint, settings.azure_openai_api_version,
                   settings.sra_narrative_timeout_s))
