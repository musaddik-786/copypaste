"""Officer edits of narrative text (`PUT /recommendations/{id}/narrative`).

The edit is merged onto the latest validated version, re-checked with validators 2-6 (number provenance,
approved claims, prohibited phrases, PII, protected attributes) against the same Fact Pack, and stored as a new
version with origin OFFICER_EDIT. Failing edits are rejected with the findings (422) and nothing is stored.
Officers write {{FIRST_NAME}} / {{CITY}} for personal references - real names are blocked by the PII check.
"""
from __future__ import annotations

import uuid
from collections.abc import Mapping
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from sra_api.audit import ledger
from sra_api.cases.actions import SURFACED, bump, lock_case
from sra_api.errors import ProblemError, not_found
from sra_api.models import Narrative, Recommendation
from sra_api.narrative import content, validators
from sra_api.narrative.fact_pack import build
from sra_api.narrative.service import _store, recommendation_inputs, sensitive_values
from sra_api.narrative.validators import ValidationContext
from sra_api.narrative.validators.number_provenance import numbers_in
from sra_api.settings import get_settings

EDITABLE_STATES = ("READY_FOR_REVIEW", "IN_REVIEW", "DECIDED", "LETTER_DRAFTED")  # a drafted letter then needs
# re-composing: approval re-composes and rejects a stale draft
EDITABLE_FIELDS = ("why_recommended", "current_gap", "how_it_helps", "key_benefit_keys", "comparison_rows",
                   "letter_rationale")
LIVE_STATUSES = ("PENDING", "INCLUDED", "SKIPPED", "DEFERRED")


def edit(session: Session, rec_id: uuid.UUID, audience: str, language: str, changes: Mapping[str, Any],
         if_match: int, actor: ledger.Actor) -> tuple[Narrative, int]:
    rec = session.get(Recommendation, rec_id)
    if rec is None:
        raise not_found("Recommendation", str(rec_id))
    case = lock_case(session, rec.case_id, if_match)
    session.refresh(rec)
    if case.state not in EDITABLE_STATES or rec.decision_run_id != case.current_decision_run_id \
            or rec.selection not in SURFACED or rec.status not in LIVE_STATUSES:
        raise ProblemError(409, "Narrative not editable", f"case is {case.state}, recommendation is {rec.status}",
                           code="NARRATIVE_NOT_EDITABLE")
    base = session.scalars(select(Narrative).where(
        Narrative.recommendation_id == rec.recommendation_id, Narrative.audience == audience,
        Narrative.language == language, Narrative.validation_status == "PASSED")
        .order_by(Narrative.version.desc()).limit(1)).first()
    if base is None:
        raise ProblemError(409, "No narrative to edit", "generate the narrative first", code="NO_NARRATIVE")

    output = {k: v for k, v in base.content.items() if k in EDITABLE_FIELDS}
    output.update({k: v for k, v in changes.items() if k in EDITABLE_FIELDS and v is not None})
    output["used_numbers"] = sorted({raw for k in ("why_recommended", "current_gap", "how_it_helps",
                                                    "letter_rationale")
                                     for raw, _ in numbers_in(str(output.get(k, "")))})

    settings = get_settings()
    inputs = recommendation_inputs(session, rec)
    stmts = content.statements(session, rec.product_code, language,
                               allow_draft=content.draft_allowed(settings, settings.sra_source_data_class))
    fp = build(rule_id=rec.rule_id, opportunity_type=rec.opportunity_type, product_code=rec.product_code,
               product_name=inputs["product_name"], priority_tier=rec.priority_tier, pricing=inputs["pricing"],
               clauses=inputs["clauses"], statements=stmts, audience=audience, language=language)
    results = [validators.schema.check(output, fp.pack, ValidationContext()),
               *validators.run_officer_edit(output, fp.pack, ValidationContext(sensitive_values(session, rec.case_id)))]
    if not validators.passed(results):
        raise ProblemError(422, "Edited text failed validation", "fix the findings and save again",
                           code="NARRATIVE_VALIDATION_FAILED", findings=validators.findings(results))
    n = _store(session, rec, audience, language, fp, output, stmts, results, origin="OFFICER_EDIT",
               prompt_id=None, deployment=None, llm_call_id=None, edited_by=actor.actor_id)
    ledger.append(session, actor, case_id=case.case_id, entity_type="NARRATIVE", entity_id=str(n.narrative_id),
                  event_type="NARRATIVE_EDITED", payload={"recommendation_id": str(rec.recommendation_id),
                                                          "audience": audience, "language": language,
                                                          "version": n.version, "previous_version": base.version})
    bump(session, case)
    return n, case.row_version
