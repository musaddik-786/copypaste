"""Narrative Service - GenAI writes the explanation of a decision that is already made (ADR-001, ADR-006).

Per recommendation x audience (OFFICER, CUSTOMER_LETTER) x language:
1. build the Fact Pack (the only model input; tokens instead of personal data) and its sha256;
2. cache: an earlier validated LLM narrative with the same fact pack, audience and language is reused - no call;
3. route through the ModelRouter (data class vs deployment boundary) - refused -> template;
4. call the model, run all validators; on failure retry once with the findings; still failing -> template;
5. store the narrative (versioned), every validator result, the llm_call log and an audit event.
Text is never shown unless it passed every validator (invariant 9). Tokens are re-inserted only when rendering.
"""
from __future__ import annotations

import json
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from sra_api import jsonutil
from sra_api.audit import ledger
from sra_api.models import LlmCall, Narrative, NarrativeValidation, Recommendation
from sra_api.narrative import content, templates, validators
from sra_api.narrative.clients import get_client
from sra_api.narrative.fact_pack import FactPack, Statement, build
from sra_api.narrative.router import load_deployment, route
from sra_api.narrative.validators import ValidationContext, ValidatorResult
from sra_api.settings import Settings, get_settings

AUDIENCES = ("OFFICER", "CUSTOMER_LETTER")
PURPOSE = {"OFFICER": "NARRATIVE_OFFICER", "CUSTOMER_LETTER": "NARRATIVE_LETTER"}


@dataclass(frozen=True)
class Generated:
    narrative_id: uuid.UUID
    origin: str
    validation_status: str
    reason: str


# ----------------------------------------------------------------------------- inputs from the decision record
def recommendation_inputs(session: Session, rec: Recommendation) -> dict[str, Any]:
    row = session.execute(text(
        "SELECT p.name_en, ps.expiring_premium, ps.base_renewal_premium, ps.upsell_increment_annual, "
        "       ps.companion_standalone_annual, ps.bundle_discount_pct, ps.bundle_saving_annual, ps.net_annual_total, "
        "       ps.monthly_equivalent, re.clauses "
        "FROM sra.recommendation r JOIN ref.product p ON p.product_code = r.product_code "
        "JOIN sra.pricing_scenario ps ON ps.decision_run_id = r.decision_run_id "
        "     AND ps.included_recommendation_ids = ARRAY[r.recommendation_id] "
        "LEFT JOIN sra.rule_evaluation re ON re.decision_run_id = r.decision_run_id AND re.rule_id = r.rule_id "
        "WHERE r.recommendation_id = :r"), {"r": rec.recommendation_id}).mappings().one()
    upsell = rec.opportunity_type == "UPSELL"
    pricing = {
        "expiring_premium": f"{row['expiring_premium']:.2f}",
        "base_renewal_premium": f"{row['base_renewal_premium']:.2f}",
        "incremental_annual": f"{row['upsell_increment_annual' if upsell else 'companion_standalone_annual']:.2f}",
        "incremental_monthly_equiv": f"{row['monthly_equivalent']:.2f}",
        "bundle_discount_pct": f"{row['bundle_discount_pct'].normalize():f}",
        "bundle_saving_annual": f"{row['bundle_saving_annual']:.2f}",
        "net_annual_total": f"{row['net_annual_total']:.2f}",
    }
    if not upsell:
        pricing["companion_standalone_annual"] = f"{row['companion_standalone_annual']:.2f}"
    return {"product_name": row["name_en"], "pricing": pricing, "clauses": row["clauses"] or []}


def sensitive_values(session: Session, case_id: uuid.UUID) -> tuple[str, ...]:
    """Real personal values of the case (from the snapshot as received) that must never appear in model text."""
    raw = session.execute(text("SELECT ps.raw_payload FROM sra.policy_snapshot ps WHERE ps.case_id = :c "
                               "ORDER BY ps.captured_at DESC LIMIT 1"), {"c": case_id}).scalar_one_or_none() or {}
    cust, quote = raw.get("customer") or {}, raw.get("quote") or {}
    values = [*str(cust.get("full_name") or "").split(), cust.get("full_name"), cust.get("street_address"),
              cust.get("postal_code"), cust.get("city"), cust.get("customer_id"), quote.get("quote_id"),
              (raw.get("vehicle") or {}).get("registration_plate")]
    dob = cust.get("date_of_birth")
    if dob:
        y, m, d = str(dob)[:10].split("-")
        values += [str(dob)[:10], f"{d}.{m}.{y}"]
    values += [p.get("policy_id") for p in raw.get("policies") or []]
    return tuple(str(v) for v in values if v)


def tokens_for(session: Session, case_id: uuid.UUID) -> dict[str, str]:
    """Server-side values for {{FIRST_NAME}} / {{CITY}} - re-inserted only when rendering."""
    row = session.execute(text(
        "SELECT rc.customer_display_name, ps.raw_payload -> 'customer' ->> 'city' AS city FROM sra.renewal_case rc "
        "LEFT JOIN LATERAL (SELECT raw_payload FROM sra.policy_snapshot s WHERE s.case_id = rc.case_id "
        "                   ORDER BY captured_at DESC LIMIT 1) ps ON true WHERE rc.case_id = :c"),
        {"c": case_id}).first()
    if row is None:
        return {}
    return {"{{FIRST_NAME}}": (row.customer_display_name or "").split(" ")[0], "{{CITY}}": row.city or ""}


def render(value: Any, tokens: Mapping[str, str]) -> Any:
    if isinstance(value, str):
        for k, v in tokens.items():
            value = value.replace(k, v)
        return value
    if isinstance(value, list):
        return [render(v, tokens) for v in value]
    if isinstance(value, dict):
        return {k: render(v, tokens) for k, v in value.items()}
    return value


# ----------------------------------------------------------------------------- generation
def _system_prompt(body: str, pack: Mapping[str, Any]) -> str:
    return body.replace("{{FACT_PACK_JSON}}", json.dumps(pack, ensure_ascii=False, indent=2))


def _parse(text_: str) -> Any:
    try:
        return json.loads(text_)
    except (TypeError, ValueError):
        return None


def _next_version(session: Session, rec_id: uuid.UUID, audience: str, language: str) -> int:
    current = session.execute(select(func.max(Narrative.version)).where(
        Narrative.recommendation_id == rec_id, Narrative.audience == audience,
        Narrative.language == language)).scalar()
    return int(current or 0) + 1


def _store(session: Session, rec: Recommendation, audience: str, language: str, fp: FactPack, output: Mapping[str, Any],
           statements: list[Statement], results: list[ValidatorResult], *, origin: str,
           prompt_id: str | None, deployment: str | None, llm_call_id: uuid.UUID | None,
           edited_by: str | None = None) -> Narrative:
    by_key = {s.key: s for s in statements}
    stored = dict(output)
    stored["key_benefits"] = [{"key": k, "text": by_key[k].text} for k in output.get("key_benefit_keys") or []
                              if k in by_key]   # text frozen with the narrative (approved letters never change)
    stored["draft_wording"] = fp.uses_draft_content
    n = Narrative(recommendation_id=rec.recommendation_id, audience=audience, language=language,
                  version=_next_version(session, rec.recommendation_id, audience, language), origin=origin,
                  content=jsonutil.to_jsonable(stored), fact_pack_sha256=fp.sha256, prompt_template_id=prompt_id,
                  model_deployment=deployment, llm_call_id=llm_call_id,
                  validation_status="PASSED" if validators.passed(results) else "FAILED", edited_by=edited_by)
    session.add(n)
    session.flush()
    session.add_all(NarrativeValidation(narrative_id=n.narrative_id, validator=r.validator, passed=r.passed,
                                        findings=[f.as_dict() for f in r.findings]) for r in results)
    session.flush()
    return n


def _cached(session: Session, fp: FactPack, audience: str, language: str) -> Narrative | None:
    return session.scalars(select(Narrative).where(
        Narrative.fact_pack_sha256 == fp.sha256, Narrative.audience == audience, Narrative.language == language,
        Narrative.origin == "LLM", Narrative.validation_status == "PASSED").order_by(Narrative.created_at)
        .limit(1)).first()


def _log_call(session: Session, settings: Settings, audience: str, deployment: str, prompt_id: str,
              data_class: str, messages: list[dict[str, str]], completion: Any, error: str | None) -> uuid.UUID:
    call = LlmCall(purpose=PURPOSE[audience], deployment_name=deployment, prompt_template_id=prompt_id,
                   data_class=data_class, request_sha256=jsonutil.sha256_hex(jsonutil.canonical(messages)),
                   input_tokens=getattr(completion, "input_tokens", None),
                   output_tokens=getattr(completion, "output_tokens", None),
                   latency_ms=getattr(completion, "latency_ms", None),
                   finish_reason=error or getattr(completion, "finish_reason", None))
    session.add(call)
    session.flush()
    return call.llm_call_id


def generate(session: Session, rec: Recommendation, audience: str, language: str, actor: ledger.Actor,
             *, settings: Settings | None = None) -> Generated:
    settings = settings or get_settings()
    data_class = settings.sra_source_data_class
    allow_draft = content.draft_allowed(settings, data_class)
    inputs = recommendation_inputs(session, rec)
    stmts = content.statements(session, rec.product_code, language, allow_draft=allow_draft)
    fp = build(rule_id=rec.rule_id, opportunity_type=rec.opportunity_type, product_code=rec.product_code,
               product_name=inputs["product_name"], priority_tier=rec.priority_tier, pricing=inputs["pricing"],
               clauses=inputs["clauses"], statements=stmts, audience=audience, language=language)
    ctx = ValidationContext(sensitive_values(session, rec.case_id))

    def done(n: Narrative, reason: str, event: str = "NARRATIVE_GENERATED") -> Generated:
        ledger.append(session, actor, case_id=rec.case_id, entity_type="NARRATIVE", entity_id=str(n.narrative_id),
                      event_type=event, payload={"recommendation_id": str(rec.recommendation_id), "audience": audience,
                                                 "language": language, "origin": n.origin, "version": n.version,
                                                 "validation_status": n.validation_status,
                                                 "fact_pack_sha256": fp.sha256, "model_deployment": n.model_deployment,
                                                 "draft_wording": fp.uses_draft_content, "reason": reason})
        return Generated(n.narrative_id, n.origin, n.validation_status, reason)

    def fallback(reason: str, llm_call_id: uuid.UUID | None = None) -> Generated:
        out = templates.fallback(fp.pack)
        n = _store(session, rec, audience, language, fp, out, stmts, validators.run_all(out, fp.pack, ctx),
                   origin="TEMPLATE_FALLBACK", prompt_id=None, deployment=None, llm_call_id=llm_call_id)
        return done(n, reason)

    hit = _cached(session, fp, audience, language)
    if hit is not None:
        out = {k: v for k, v in hit.content.items() if k not in ("key_benefits", "draft_wording")}
        results = validators.run_all(out, fp.pack, ctx)  # re-checked for this case (e.g. its personal data)
        if validators.passed(results):
            n = _store(session, rec, audience, language, fp, out, stmts, results, origin="LLM",
                       prompt_id=hit.prompt_template_id, deployment=hit.model_deployment, llm_call_id=hit.llm_call_id)
            return done(n, f"cache hit (narrative {hit.narrative_id})")

    decision = route(load_deployment(session, settings.narrative_deployment), data_class,
                     allow_synthetic_claude=settings.sra_allow_synthetic_claude)
    if not decision.allowed or decision.deployment is None:
        return fallback(f"route refused: {decision.reason}")
    prompt = content.prompt(session, audience, allow_draft=allow_draft)
    if prompt is None:
        return fallback("no usable prompt template (APPROVED, or DRAFT with SRA_ALLOW_DRAFT_STATEMENTS)")

    deployment = decision.deployment.name
    messages = [{"role": "system", "content": _system_prompt(prompt.body, fp.pack)},
                {"role": "user", "content": "Write the narrative JSON for this fact pack."}]
    call_id: uuid.UUID | None = None
    for attempt in (1, 2):
        try:
            completion = get_client(settings).complete(deployment, messages)
        except Exception as exc:  # any model failure falls back to the template
            call_id = _log_call(session, settings, audience, deployment, prompt.template_id, data_class, messages,
                                None, f"ERROR:{type(exc).__name__}")
            return fallback(f"model call failed: {type(exc).__name__}", call_id)
        call_id = _log_call(session, settings, audience, deployment, prompt.template_id, data_class, messages,
                            completion, None)
        output = _parse(completion.text)
        results = validators.run_all(output, fp.pack, ctx)
        if validators.passed(results):
            n = _store(session, rec, audience, language, fp, output, stmts, results, origin="LLM",
                       prompt_id=prompt.template_id, deployment=deployment, llm_call_id=call_id)
            return done(n, f"generated (attempt {attempt})")
        if attempt == 1:  # one retry with the findings appended (docs/04 §4.2)
            messages = [*messages, {"role": "assistant", "content": completion.text},
                        {"role": "user", "content": "Your answer failed these checks; return corrected JSON only: "
                                                    + json.dumps(validators.findings(results))}]
    return fallback("validation failed twice", call_id)


def generate_for_recommendations(session: Session, recs: list[Recommendation], actor: ledger.Actor) -> list[Generated]:
    settings = get_settings()
    return [generate(session, rec, audience, language, actor, settings=settings)
            for rec in recs for audience in AUDIENCES for language in settings.languages]
