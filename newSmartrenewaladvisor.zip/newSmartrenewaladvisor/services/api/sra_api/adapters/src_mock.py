"""POC adapter: implements the PAS / CRM / Claims ports over the `src` mock schema (SQLAlchemy Core reads).
Only this module (via the Fact Builder) reads `src`; nothing else in sra/rules does (db/001 header)."""
from __future__ import annotations

from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from sra_api.adapters.ports import Row


class _Sql:
    def __init__(self, session: Session) -> None:
        self.session = session

    def _all(self, sql: str, **params: Any) -> list[Row]:
        return [dict(r) for r in self.session.execute(text(sql), params).mappings()]

    def _one(self, sql: str, **params: Any) -> Row | None:
        rows = self._all(sql, **params)
        return rows[0] if rows else None


class SrcMockPas(_Sql):
    def renewal_quote(self, quote_id: str) -> Row | None:
        # customer_id is joined in so the collector can find the customer without a second lookup
        return self._one("SELECT q.*, p.customer_id FROM src.renewal_quote q JOIN src.policy p USING (policy_id) "
                         "WHERE q.quote_id = :q", q=quote_id)

    def policies_of_customer(self, customer_id: str) -> list[Row]:
        return self._all("SELECT * FROM src.policy WHERE customer_id = :c AND status = 'ACTIVE' ORDER BY policy_id",
                         c=customer_id)

    def policy_modules(self, policy_ids: list[str]) -> list[Row]:
        if not policy_ids:
            return []
        return self._all("SELECT * FROM src.policy_module WHERE policy_id = ANY(:ids) ORDER BY policy_id, product_code",
                         ids=policy_ids)

    def insured_vehicle(self, policy_id: str) -> Row | None:
        return self._one("SELECT * FROM src.insured_vehicle WHERE policy_id = :p", p=policy_id)

    def insured_property(self, policy_id: str) -> Row | None:
        return self._one("SELECT * FROM src.insured_property WHERE policy_id = :p", p=policy_id)

    def insured_animals(self, policy_id: str) -> list[Row]:
        return self._all("SELECT * FROM src.insured_animal WHERE policy_id = :p ORDER BY animal_ref", p=policy_id)

    def rating_quotes(self, quote_id: str) -> list[Row]:
        return self._all("SELECT * FROM src.rating_quote WHERE quote_id = :q ORDER BY product_code, rating_quote_id",
                         q=quote_id)


class SrcMockCrm(_Sql):
    def customer(self, customer_id: str) -> Row | None:
        return self._one("SELECT * FROM src.customer WHERE customer_id = :c", c=customer_id)

    def declared_facts(self, customer_id: str) -> list[Row]:
        return self._all("SELECT * FROM src.customer_declared_fact WHERE customer_id = :c ORDER BY fact_key",
                         c=customer_id)

    def consents(self, customer_id: str) -> list[Row]:
        return self._all("SELECT * FROM src.consent WHERE customer_id = :c ORDER BY purpose", c=customer_id)

    def complaints(self, customer_id: str) -> list[Row]:
        return self._all("SELECT * FROM src.complaint WHERE customer_id = :c ORDER BY complaint_id", c=customer_id)


class SrcMockClaims(_Sql):
    def claims_of_customer(self, customer_id: str) -> list[Row]:
        return self._all("SELECT * FROM src.claim WHERE customer_id = :c ORDER BY claim_id", c=customer_id)


class SraReference(_Sql):
    """Reference data (ref schema) and SRA's own cooldown ledger."""

    def product_embeddings(self) -> list[Row]:
        return self._all("SELECT * FROM ref.product_embedding ORDER BY parent_product_code, embedded_product_code")

    def declines(self, customer_id: str, exclude_case_id: Any = None) -> list[Row]:
        """Cooldown history. Declines recorded by the case being evaluated are excluded: within that case they
        are already represented by the officer's actions, and counting them would make a repeat click look like
        changed source data (wiping the officer's other decisions). They apply to *future* renewals."""
        return self._all(
            "SELECT d.product_code, d.declined_at, d.source FROM sra.recommendation_decline d "
            "WHERE d.customer_id = :c AND (CAST(:case AS uuid) IS NULL OR d.recommendation_id IS NULL OR NOT EXISTS ("
            "  SELECT 1 FROM sra.recommendation r WHERE r.recommendation_id = d.recommendation_id "
            "  AND r.case_id = CAST(:case AS uuid))) ORDER BY d.declined_at, d.product_code",
            c=customer_id, case=str(exclude_case_id) if exclude_case_id else None)
