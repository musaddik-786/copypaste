"""Ports to the systems of record. The Fact Builder depends only on these; the POC implementation reads the
`src` mock schema (src_mock.py) and is replaced by PAS / CRM / Claims integration adapters in production.

Rows are plain dicts with the column names of the corresponding src tables (dates as `date`, money as
`Decimal`, jsonb as parsed JSON).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

Row = dict[str, Any]


class PasPort(Protocol):
    def renewal_quote(self, quote_id: str) -> Row | None: ...
    def policies_of_customer(self, customer_id: str) -> list[Row]: ...
    def policy_modules(self, policy_ids: list[str]) -> list[Row]: ...
    def insured_vehicle(self, policy_id: str) -> Row | None: ...
    def insured_property(self, policy_id: str) -> Row | None: ...
    def insured_animals(self, policy_id: str) -> list[Row]: ...
    def rating_quotes(self, quote_id: str) -> list[Row]: ...


class CrmPort(Protocol):
    def customer(self, customer_id: str) -> Row | None: ...
    def declared_facts(self, customer_id: str) -> list[Row]: ...
    def consents(self, customer_id: str) -> list[Row]: ...
    def complaints(self, customer_id: str) -> list[Row]: ...


class ClaimsPort(Protocol):
    def claims_of_customer(self, customer_id: str) -> list[Row]: ...


class ReferencePort(Protocol):
    def product_embeddings(self) -> list[Row]: ...


class DeclineLedgerPort(Protocol):
    def declines(self, customer_id: str, exclude_case_id: Any = None) -> list[Row]: ...


@dataclass
class SourceSnapshot:
    """Everything read for one renewal quote, as received (the raw payload of sra.policy_snapshot)."""
    quote: Row
    policy: Row
    customer: Row
    policies: list[Row]
    modules: list[Row]
    vehicle: Row | None
    property: Row | None
    animals: list[Row]
    claims: list[Row]
    complaints: list[Row]
    declared_facts: list[Row]
    consents: list[Row]
    rating_quotes: list[Row]
    embeddings: list[Row]
    declines: list[Row] = field(default_factory=list)


def collect_source(quote_id: str, pas: PasPort, crm: CrmPort, claims: ClaimsPort, ref: ReferencePort,
                   ledger: DeclineLedgerPort) -> SourceSnapshot | None:
    """Pull the snapshot for one quote from the ports. ``None`` if the quote is unknown."""
    quote = pas.renewal_quote(quote_id)
    if quote is None:
        return None
    policies = pas.policies_of_customer(_customer_of(quote))
    policy = next((p for p in policies if p["policy_id"] == quote["policy_id"]), None)
    if policy is None:
        raise LookupError(f"renewing policy {quote['policy_id']} of quote {quote_id} not found")
    customer_id = policy["customer_id"]
    customer = crm.customer(customer_id)
    if customer is None:
        raise LookupError(f"customer {customer_id} of quote {quote_id} not found")
    return SourceSnapshot(
        quote=quote, policy=policy, customer=customer, policies=policies,
        modules=pas.policy_modules([p["policy_id"] for p in policies]),
        vehicle=pas.insured_vehicle(policy["policy_id"]),
        property=pas.insured_property(policy["policy_id"]),
        animals=pas.insured_animals(policy["policy_id"]),
        claims=claims.claims_of_customer(customer_id),
        complaints=crm.complaints(customer_id),
        declared_facts=crm.declared_facts(customer_id),
        consents=crm.consents(customer_id),
        rating_quotes=pas.rating_quotes(quote_id),
        embeddings=ref.product_embeddings(),
        declines=ledger.declines(customer_id),
    )


def _customer_of(quote: Row) -> str:
    customer_id = quote.get("customer_id")
    if not customer_id:
        raise LookupError(f"quote {quote.get('quote_id')} has no customer")
    return str(customer_id)
