"""Authentication and role checks behind ONE dependency, so the source can change without touching routers.

* SRA_AUTH_MODE=dev (local / test only, enforced in settings): the `X-Dev-User` header names one of the
  synthetic users below. No passwords; never enabled outside a developer machine.
* SRA_AUTH_MODE=entra: Entra ID JWT validation - not implemented yet; the API refuses requests.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Header

from sra_api.audit.ledger import Actor
from sra_api.errors import ProblemError
from sra_api.settings import get_settings

ROLES = ("RENEWAL_OFFICER", "SUPERVISOR", "RULE_AUTHOR", "RULE_APPROVER", "COMPLIANCE_REVIEWER", "AUDITOR")


@dataclass(frozen=True)
class User:
    user_id: str
    display_name: str
    roles: frozenset[str]

    @property
    def actor(self) -> Actor:
        return Actor("RULE_ADMIN" if self.roles & {"RULE_AUTHOR", "RULE_APPROVER"} else "OFFICER", self.user_id)


# Two officers so maker-checker / concurrency can be demoed with different people.
DEV_USERS: dict[str, User] = {u.user_id: u for u in (
    User("officer.anna", "Anna (Renewal Officer)", frozenset({"RENEWAL_OFFICER"})),
    User("officer.ben", "Ben (Renewal Officer)", frozenset({"RENEWAL_OFFICER"})),
    User("supervisor.sam", "Sam (Supervisor)", frozenset({"SUPERVISOR"})),
    User("auditor.ada", "Ada (Auditor)", frozenset({"AUDITOR"})),
    User("rules.rita", "Rita (Rule Author)", frozenset({"RULE_AUTHOR"})),
    User("rules.raj", "Raj (Rule Approver)", frozenset({"RULE_APPROVER"})),
    User("compliance.cora", "Cora (Compliance Reviewer)", frozenset({"COMPLIANCE_REVIEWER"})),
)}


def current_user(x_dev_user: Annotated[str | None, Header()] = None) -> User:
    if get_settings().sra_auth_mode != "dev":
        raise ProblemError(501, "Authentication not configured", "Entra ID token validation is not implemented yet",
                           code="AUTH_NOT_CONFIGURED")
    if not x_dev_user:
        raise ProblemError(401, "Unauthenticated", "send the X-Dev-User header (dev mode)", code="UNAUTHENTICATED")
    user = DEV_USERS.get(x_dev_user)
    if user is None:
        raise ProblemError(401, "Unauthenticated", f"unknown dev user {x_dev_user!r}", code="UNAUTHENTICATED")
    return user


def require_role(*roles: str) -> Callable[[User], User]:
    allowed = frozenset(roles)

    def check(user: Annotated[User, Depends(current_user)]) -> User:
        if not user.roles & allowed:
            raise ProblemError(403, "Forbidden", f"requires one of {sorted(allowed)}", code="FORBIDDEN")
        return user

    return check


OFFICER_ROLES = ("RENEWAL_OFFICER", "SUPERVISOR")
READ_ROLES = ("RENEWAL_OFFICER", "SUPERVISOR", "AUDITOR", "COMPLIANCE_REVIEWER")
