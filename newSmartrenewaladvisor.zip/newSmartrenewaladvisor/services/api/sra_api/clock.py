"""The business clock. The pure engine never reads the clock; the service layer asks this module."""
from __future__ import annotations

from datetime import UTC, date, datetime

from sra_api.settings import get_settings


def business_date() -> date:
    """The `as_of` date for decisions: SRA_AS_OF if pinned (demos, tests), otherwise today."""
    pinned = get_settings().sra_as_of
    return pinned if pinned is not None else datetime.now(UTC).date()


def utcnow() -> datetime:
    return datetime.now(UTC)
