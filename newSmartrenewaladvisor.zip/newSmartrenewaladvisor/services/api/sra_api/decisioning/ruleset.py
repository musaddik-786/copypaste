"""The ruleset as the decision path sees it: plain data plus its integrity hash. No I/O here - loading from
the database lives in sra_api.admin.ruleset_store, outside the decision path."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class LoadedRuleset:
    version: str
    catalog: dict[str, Any]
    sha256: str

    @property
    def params(self) -> dict[str, Any]:
        return {k: v["value"] for k, v in self.catalog["parameters"].items()}


def catalog_sha256(catalog: dict[str, Any]) -> str:
    """Same serialisation as tools/generate_seeds.py, which computed the stored hash."""
    return hashlib.sha256(json.dumps(catalog, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
