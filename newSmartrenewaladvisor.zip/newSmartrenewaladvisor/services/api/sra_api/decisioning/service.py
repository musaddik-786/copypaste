"""Decision Service: runs the pure engine on a Decision Context. No LLM, no network (ADR-001).

This module must only import the deterministic packages - enforced by tests/architecture.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import date
from importlib.metadata import version
from typing import Any

import sra_pricing
import sra_rules

from sra_api import jsonutil
from sra_api.decisioning.ruleset import LoadedRuleset

ENGINE_VERSION = f"sra-rules {version('sra-rules')} / sra-pricing {version('sra-pricing')}"
PRICING_CALC_VERSION = f"sra-pricing {version('sra-pricing')}"


@dataclass(frozen=True)
class Decision:
    result: sra_rules.DecisionResult
    output_sha256: str
    duration_ms: int


def output_sha256(result: sra_rules.DecisionResult) -> str:
    """Reproducibility fingerprint: a replay of the same snapshot + ruleset must give the same value (CTL-12)."""
    return jsonutil.sha256_hex(jsonutil.canonical(sra_rules.result_to_dict(result)))


def decide(context: dict[str, Any], ruleset: LoadedRuleset, as_of: date) -> Decision:
    t0 = time.perf_counter()
    result = sra_rules.evaluate(context, ruleset.catalog, as_of, pricer=sra_pricing.price_candidate)
    return Decision(result, output_sha256(result), int((time.perf_counter() - t0) * 1000))
