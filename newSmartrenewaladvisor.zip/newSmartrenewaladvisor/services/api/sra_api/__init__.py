"""Smart Renewal Advisor API (modular monolith)."""
__version__ = "0.2.0"
