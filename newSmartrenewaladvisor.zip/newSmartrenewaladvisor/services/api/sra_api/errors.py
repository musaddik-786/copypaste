"""RFC 9457 problem+json errors."""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

PROBLEM_JSON = "application/problem+json"


class ProblemError(Exception):
    def __init__(self, status: int, title: str, detail: str | None = None, code: str | None = None,
                 **extra: Any) -> None:
        super().__init__(detail or title)
        self.status, self.title, self.detail, self.code, self.extra = status, title, detail, code, extra


def not_found(what: str, ident: str) -> ProblemError:
    return ProblemError(404, "Not found", f"{what} {ident} does not exist", code="NOT_FOUND")


def install(app: FastAPI) -> None:
    @app.exception_handler(RequestValidationError)
    async def _validation(request: Request, exc: RequestValidationError) -> JSONResponse:
        findings = [{"field": ".".join(str(p) for p in e.get("loc", ())[1:]), "message": e.get("msg", "")}
                    for e in exc.errors()]
        return JSONResponse({"type": "about:blank", "title": "Invalid request", "status": 422,
                             "instance": request.url.path, "code": "INVALID_REQUEST", "findings": findings},
                            status_code=422, media_type=PROBLEM_JSON)

    @app.exception_handler(ProblemError)
    async def _problem(request: Request, exc: ProblemError) -> JSONResponse:
        body: dict[str, Any] = {"type": "about:blank", "title": exc.title, "status": exc.status,
                                "instance": request.url.path}
        if exc.detail:
            body["detail"] = exc.detail
        if exc.code:
            body["code"] = exc.code
        body.update({k: v for k, v in exc.extra.items() if k not in body})  # never override the standard fields
        return JSONResponse(body, status_code=exc.status, media_type=PROBLEM_JSON)
