"""Database engine and the per-request session (one transaction per request)."""
from __future__ import annotations

from collections.abc import Iterator
from functools import lru_cache

from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session, sessionmaker

from sra_api import jsonutil
from sra_api.settings import get_settings


@lru_cache
def get_engine() -> Engine:
    url = get_settings().database_url
    if not url:
        raise RuntimeError("DATABASE_URL is not configured (set it in the environment or the repo-root .env)")
    return create_engine(url, pool_pre_ping=True, json_serializer=jsonutil.dumps)


def session_factory() -> sessionmaker[Session]:
    return sessionmaker(bind=get_engine(), expire_on_commit=False)


def get_session() -> Iterator[Session]:
    """FastAPI dependency: commit if the request succeeds, roll back otherwise.

    State changes and their audit events therefore always land in the same transaction (invariant 11).
    """
    session = session_factory()()
    try:
        yield session
        session.commit()
    except BaseException:
        session.rollback()
        raise
    finally:
        session.close()
