"""Alembic environment: online migrations only, URL from sra_api.settings."""
from __future__ import annotations

from alembic import context
from sqlalchemy import create_engine
from sra_api.settings import get_settings


def run_migrations_online() -> None:
    engine = create_engine(get_settings().database_url)
    with engine.connect() as connection:
        # PG >= 15 does not let app users create tables in `public`; keep Alembic's bookkeeping in `sra`.
        context.configure(connection=connection, version_table_schema="sra")
        with context.begin_transaction():
            context.run_migrations()


run_migrations_online()
