"""Baseline: db/001_sra_schema.sql (+ seeds 002-004), loaded by tools/db_reset.py.

Revision ID: 0001
Revises:
"""
revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass  # the baseline DDL is db/001; this revision only marks it


def downgrade() -> None:
    pass
