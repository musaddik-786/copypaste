"""Sequence for business recommendation refs (REC-2026-0041).

Revision ID: 0002
Revises: 0001
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("CREATE SEQUENCE IF NOT EXISTS sra.recommendation_ref_seq START 1")


def downgrade() -> None:
    op.execute("DROP SEQUENCE IF EXISTS sra.recommendation_ref_seq")
