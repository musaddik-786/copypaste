"""Narrative content: claimsfoundry gpt-4.1 deployment, prompt templates (DRAFT), draft benefit statements.

* sra.model_deployment: `gpt-4.1` on claimsFoundry (eastus) is a GlobalStandard deployment, i.e. NOT the EU
  Data Zone -> data_boundary GLOBAL, allowed for SYNTHETIC data only (CLAUDE.md invariant 8, ADR-008).
* sra.prompt_template: ai/prompts/narrative_system.v1.md for both audiences, status DRAFT (needs Compliance).
* ref.product_benefit_statement: ai/content/benefit_statements.draft.v1.json, status DRAFT,
  approved_by PENDING_COMPLIANCE (only used for SYNTHETIC data with SRA_ALLOW_DRAFT_STATEMENTS=true).

Revision ID: 0003
Revises: 0002
"""
import json
from pathlib import Path

import sqlalchemy as sa
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None

REPO = Path(__file__).resolve().parents[4]
PROMPT_FILE = REPO / "ai" / "prompts" / "narrative_system.v1.md"
STATEMENTS_FILE = REPO / "ai" / "content" / "benefit_statements.draft.v1.json"
OUTPUT_SCHEMA_FILE = REPO / "contracts" / "llm" / "narrative_output.v1.schema.json"
DEPLOYMENT = "gpt-4.1"


def upgrade() -> None:
    conn = op.get_bind()
    conn.execute(sa.text(
        "INSERT INTO sra.model_deployment (deployment_name, provider, model_id, deployment_type, data_boundary, "
        "allowed_data_classes, active) VALUES (:n, 'AZURE_OPENAI', 'gpt-4.1-2025-04-14', 'GlobalStandard', "
        "'GLOBAL', ARRAY['SYNTHETIC'], true) ON CONFLICT (deployment_name) DO NOTHING"), {"n": DEPLOYMENT})

    body = PROMPT_FILE.read_text(encoding="utf-8")
    schema = OUTPUT_SCHEMA_FILE.read_text(encoding="utf-8")
    for template_id, purpose in (("narrative.officer.v1", "NARRATIVE_OFFICER"),
                                 ("narrative.letter.v1", "NARRATIVE_LETTER")):
        conn.execute(sa.text(
            "INSERT INTO sra.prompt_template (prompt_template_id, purpose, body, output_schema, status) "
            "VALUES (:i, :p, :b, CAST(:s AS jsonb), 'DRAFT') ON CONFLICT (prompt_template_id) DO NOTHING"),
            {"i": template_id, "p": purpose, "b": body, "s": schema})

    content = json.loads(STATEMENTS_FILE.read_text(encoding="utf-8"))
    for product_code, statements in content["products"].items():
        for key, text in statements.items():
            conn.execute(sa.text(
                "INSERT INTO ref.product_benefit_statement (product_code, language, statement_key, statement_text, "
                "contains_limit, approved_by, approved_at, version, status) VALUES (:pc, :lang, :k, :t, false, "
                "'PENDING_COMPLIANCE', now(), :v, 'DRAFT') "
                "ON CONFLICT (product_code, language, statement_key, version) DO NOTHING"),
                {"pc": product_code, "lang": content["language"], "k": key, "t": text, "v": content["version"]})


def downgrade() -> None:
    conn = op.get_bind()
    conn.execute(sa.text("DELETE FROM ref.product_benefit_statement WHERE approved_by = 'PENDING_COMPLIANCE'"))
    conn.execute(sa.text("DELETE FROM sra.prompt_template WHERE prompt_template_id IN "
                         "('narrative.officer.v1', 'narrative.letter.v1')"))
    conn.execute(sa.text("DELETE FROM sra.model_deployment WHERE deployment_name = :n "
                         "AND NOT EXISTS (SELECT 1 FROM sra.llm_call c WHERE c.deployment_name = :n)"),
                 {"n": DEPLOYMENT})
