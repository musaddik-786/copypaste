"""pytest fixtures for the engine tests. Shared data lives in golden_support (a uniquely named module, so it
cannot collide with other suites' conftest.py when everything runs in one session)."""
from golden_support import as_of, catalog  # noqa: F401  (re-exported as fixtures)
