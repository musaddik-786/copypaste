---
description: Add or change a business rule end-to-end (catalog + golden tests + docs)
argument-hint: <BA rule id or plain-language rule>
---
Use the `rules-engineer` subagent to implement this rule change: $ARGUMENTS

Deliver:
1. The catalog diff (JsonLogic + parameters + source_refs + open_decisions).
2. New or updated golden tests (positive, negative, boundary).
3. `make golden` and `make contract-test` output.
4. A one-paragraph change-request summary for the maker-checker workflow (business rationale, regulatory reference, expected impact).
Then run the `compliance-reviewer` subagent on the diff.
