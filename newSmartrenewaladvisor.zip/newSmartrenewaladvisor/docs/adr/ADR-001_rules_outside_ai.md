# ADR-001: Deterministic decisioning is separated from the AI ("rules decide, AI explains, humans approve")

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, Head of Compliance, BA Lead, Client CTO delegate

## Context
The BRD and Rules document define a highly rule-driven process: gatekeepers (consent, arrears, complaints, disputes, open claims), eligibility (duplicates, cooldowns, target market, risk quality) and ranking. EU/DE regulation (IDD Art. 17/20/24/25, GDPR Art. 21/22, the EIOPA AI Opinion, BaFin's AI ICT guidance) expects recommendations to be suitable, explainable and reproducible. The client also wants this presented as an AI use case.

## Decision
Eligibility, suppression, pricing and ranking run in a **deterministic Decision Service and Pricing module with no LLM dependency**. GenAI is used only to (a) explain the decision already made (Narrative Service) and (b) assist the officer through a read-only, case-scoped copilot. The officer decides, and nothing is dispatched without officer approval.

## Options considered
### Option A: LLM agent decides (rules in the prompt)
| Dimension | Assessment |
|---|---|
| Complexity | Low to start, high to make safe |
| Compliance | Poor: non-deterministic, unverifiable reasoning, prompt-sensitive |
| Testability | Statistical only |
| Cost | Per-decision token cost |
**Pros:** fast prototype; "agentic" narrative. **Cons:** cannot guarantee BR-04/BR-07 suppression, cannot replay, risk of hallucinated eligibility and prices (the prototype copy already shows invented numbers).

### Option B: Agent orchestrates; rules engine is one of its tools
**Pros:** flexible; impressive in demos. **Cons:** the agent can skip, misuse or misread the tool; the decision path is again non-deterministic; harder to certify. *Kept only for the copilot*, where outputs are advisory and read-only.

### Option C: Deterministic pipeline + AI explain/assist (chosen)
**Pros:** exact audit trail; golden tests; replay; BA-owned parameters; microsecond latency; AI used where it adds value. **Cons:** less "autonomous" story; needs a good explanation layer, which is exactly what the GenAI component provides.

### Option D: ML propensity model selects offers
**Pros:** optimises conversion. **Cons:** needs history the POC lacks; fairness and explainability burden; still needs rules for suitability. *Roadmap: rank within the rule-approved set only.*

## Trade-off analysis
Regulatory defensibility and reproducibility outweigh flexibility. The AI story is stronger, not weaker: the client gets grounded GenAI and an agentic copilot that it can actually deploy, rather than a demo it cannot take to production.

## Consequences
- Easier: audits, complaints handling, BaFin enquiries, rule changes, testing, cost control.
- Harder: the AI cannot "discover" new opportunity types on its own. New ideas go through the rule catalog (the roadmap item on AI-assisted rule authoring helps here).
- Revisit: when an ML ranker is introduced (ADR needed), or if the AI Act classification changes.

## Action items
1. [ ] CI check: no LLM client imports in `packages/sra_rules`, `packages/sra_pricing`, `services/api/decisioning`.
2. [ ] Present this ADR in the client demo as the architecture principle.
