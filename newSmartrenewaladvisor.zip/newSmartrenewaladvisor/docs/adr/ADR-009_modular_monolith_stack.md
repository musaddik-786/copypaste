# ADR-009: Modular monolith (Python FastAPI + React) on Azure Container Apps with PostgreSQL

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, Engineering Manager, Cloud team

## Context
The POC must reach a demo in ~6 weeks with a small team, then evolve into a pilot. The AI ecosystem is strongest in Python. The prototype is HTML/JS. JSONB, constraints and transactional audit are needed.

## Decision
- One backend deployable (`sra-api`) plus one worker, with strict module boundaries (ingestion, decisioning, pricing, cases, letters, narrative, copilot, admin, audit). The decision engine and pricing are separate pure packages.
- React 18 + TypeScript SPA ported from the prototype.
- Azure Container Apps (scale to zero in dev), Azure Database for PostgreSQL Flexible Server, Service Bus, APIM, Blob, AI Search, Key Vault, Entra ID. IaC with Bicep + azd.

## Options considered
| Option | Pros | Cons |
|---|---|---|
| **Modular monolith on Container Apps** (chosen) | Fast; simple ops; clear seams for later split | Single deploy unit |
| Microservices on AKS | Independent scaling and ownership | Platform overhead not justified for the POC |
| .NET backend | Strong in many insurers' estates | Weaker AI and eval tooling; reference engine is Python |
| Cosmos DB | Flexible docs | Weaker relational integrity for audit/four-eyes constraints |

## Consequences
- The rule engine can later be extracted as a service (or into PAS) without changing contracts.
- Revisit at pilot: AKS if the client's platform standard requires it.
