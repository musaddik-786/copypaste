# ADR-012: Human-in-the-loop workflow and structurally demarcated letters

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** BA Lead, Compliance, Lead Architect

## Context
BR-10 (officer authority), BR-11 (skip reasons), BR-13 (clear demarcation), BRD Stage 5 (explicit opt-in, no pre-ticked boxes), IDD Art. 24 (separately purchasable components).

## Decision
- Every surfaced recommendation needs an officer action (Include / Skip with reason / Defer with reason and date) before letter approval. Undo = reversal row. Deferred items expire at the SLA cut-off (D-15).
- Letters are composed from typed sections (`CORE_RENEWAL_TERMS`, `PREMIUM_CHANGE_NOTICE`, `ADVISORY_BLOCK`, `BUNDLE_SAVINGS`, `OPT_IN_INSTRUCTION`, `OBJECTION_NOTICE`, `ATTACHMENTS`). The template enforces order and a visual separator; AI text fills only the rationale slot.
- The approved letter is frozen (PDF + hash) before dispatch. There is no automated dispatch path for advisory letters.
- Skip reasons map to `creates_cooldown` (customer declines) vs not (timing, officer concern).

## Consequences
- Compliance can sign off a finite set of templates instead of free-form letters.
- Outcome data (skip reasons, opt-ins) feeds rule tuning.
