# ADR-008: Model hosting on Microsoft Foundry with EU data-zone routing by data class

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, DPO, Security, Procurement

## Context
The client chose Azure with Claude and/or GPT via Foundry. Per Microsoft's documentation (Claude in Foundry data-privacy page, updated June 2026) and industry reporting (July 2026), Claude models in Foundry are third-party Marketplace offerings with Anthropic as an independent data processor, and processing is limited to Global or US data-zone deployments. **No EU data zone is available yet.** Azure OpenAI GPT models support **Data Zone Standard (EU)** deployments (e.g. Germany West Central, Sweden Central). Customer data is subject to GDPR, and the client will apply DORA third-party risk management.

## Decision
- Default deployment for any real or pseudonymised customer-derived content: **Azure OpenAI GPT, Data Zone Standard EU.**
- Claude on Foundry: allowed for **synthetic** demo data and model benchmarking only, until an EU data zone is available and approved by the DPO.
- All calls go through an APIM AI Gateway and an in-code `ModelRouter`. Each deployment declares `data_boundary` and `allowed_data_classes`; each call declares its `data_class`; mismatches are refused (fail closed).
- Models are interchangeable behind the narrative and copilot contracts; switching requires a green eval run.

## Options considered
- **Claude via AWS Bedrock EU or Google Vertex EU:** EU residency available there, but outside the chosen Azure estate (multi-cloud, procurement, DORA register). Possible future option.
- **GPT only:** simplest; loses the option of Claude for the demo.
- **Self-hosted open-weight model in Azure:** full control; heavy MLOps for the POC; not justified.

## Consequences
- The demo can still show Claude on synthetic personas if desired, without a residency question.
- Re-assess quarterly; the Anthropic/Microsoft roadmap lists EU availability as "coming", with no date.
- DORA register of information: Microsoft (Azure, Foundry, Azure OpenAI); Anthropic if the Claude deployment is used.
