# ADR-004: Event-driven evaluation on quote creation, with re-evaluation on officer open

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, PAS integration lead

## Context
BR-01: trigger only when PAS creates a renewal quote; operate only until letter dispatch. BAC-02: the officer clicks "Generate Possible Opportunities". The queue must show opportunity badges and conduct holds before officers open cases. Facts such as complaints can change between quote creation and review.

## Decision
- PAS publishes a thin `RenewalQuoteCreated` CloudEvent to Service Bus; SRA pulls the snapshot and **pre-computes** the decision and narratives.
- When the officer opens the case or clicks Generate, SRA runs a **stale check** (source last-modified vs snapshot time) and re-evaluates if anything changed. This is cheap because the engine is deterministic and narratives are cached by fact-pack hash.
- Dispatch closes the window: later evaluations return `NOT_TRIGGERED`.

## Options considered
- **On-demand only:** simpler, but no queue badges or pre-generated narratives, and slower officer UX.
- **Pre-compute only:** risk of acting on stale facts (e.g. a complaint filed after the quote).
- **Fat events carrying PII:** PII in the broker; duplicated sources of truth. Rejected.
- **Pre-compute + stale-check re-evaluation (chosen).**

## Consequences
- Idempotency and ordering rules required (quote_version).
- Every re-evaluation is a new immutable `decision_run`; recommendations from older runs become `SUPERSEDED`.
