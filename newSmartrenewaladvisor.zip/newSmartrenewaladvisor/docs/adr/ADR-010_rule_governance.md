# ADR-010: Rule governance with maker-checker, golden tests and backtest gates

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** BA Lead, Head of Compliance, Lead Architect

## Context
Thresholds will change often (17 open decisions). Changes affect customer outcomes and must be controlled and evidenced.

## Decision
- Rulesets are immutable, semantically versioned (`patch` = parameters, `minor` = new or retired rules, `major` = pipeline semantics).
- Change requests are JSON Patches with justification. The system runs golden tests plus a backtest impact report automatically.
- Four-eyes: approver ≠ maker (DB constraint). Publishing requires a green golden run. One published ruleset per jurisdiction.
- Every decision stores its `ruleset_version`. Rule IDs are never reused.
- Golden test expectations change only with a referenced change request.

## Consequences
- The BA owns the business logic lifecycle; engineering owns the engine.
- The live rule change is a strong demo moment (§7.5).
