# ADR-003: Pricing is deterministic, sourced from PAS rating, and computed in one module

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, Pricing/Actuarial, BA Lead

## Context
BR-12 requires verified pricing (expiring, base renewal, increment, bundle saving, net). The prototype and the Rules document contain arithmetic errors (e.g. €37.75 vs €38.00; €25.38 vs €25.37), proof that hand-written or model-written figures are unreliable. German consumer premiums are gross incl. insurance premium tax; monthly payment may carry an instalment surcharge.

## Decision
- Rider and companion premiums come **only** from the PAS Rating API (`rating_quote`, with validity). No verified price → no recommendation (PR-01).
- `packages/sra_pricing` computes increments, bundle saving and net totals with `Decimal` and ROUND_HALF_UP to 2 dp, for each inclusion combination (primary / alternative / both), stored in `pricing_scenario` with a DB consistency CHECK.
- Bundle discounts come from `ref.bundle_discount_rule` (per companion product, basis = renewing premium + companion standalone; D-11).
- The LLM receives prices as strings and may only repeat them (number-provenance validator).

## Options considered
- **A. PAS computes everything, including bundles:** ideal long-term; PAS change lead time is too long for the demo. *Target state for the pilot if PAS supports it.*
- **B. SRA module with PAS rating inputs (chosen).**
- **C. Prices in the rule catalog (static €3.80 etc.):** simple but not "verified"; rejected except as demo mock data inside the PAS mock.

## Consequences
- Easier: one place to test; property-based tests for invariants.
- Harder: the bundle logic must be kept in sync with PAS tariff rules, so it needs Pricing sign-off.
- Revisit: move the bundle computation into PAS when available; SRA then only displays the figures.
