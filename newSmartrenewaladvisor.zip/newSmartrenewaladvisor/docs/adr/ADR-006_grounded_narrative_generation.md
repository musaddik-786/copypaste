# ADR-006: Grounded narrative generation with deterministic validators and template fallback

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, AI Lead, Compliance

## Context
Officers need talking points; customers need a clear two-sentence rationale (BRD §7.1) in German. The prototype copy shows typical LLM-style risks: invented statistics, property values, absolute claims, fear framing.

## Decision
The Narrative Service sends a **pseudonymised fact pack** (only rule-relevant facts, verified prices and Compliance-approved benefit statements) to the model, requests **structured JSON**, and runs **deterministic validators** (schema, number provenance, approved claims, prohibited phrases, PII, protected attributes, length/readability, Content Safety/groundedness). It retries once, then falls back to an approved static template. Outputs are versioned, cached by fact-pack hash, labelled as AI-drafted, and editable by the officer (edits are re-validated).

## Options considered
| Option | Quality / personalisation | Compliance risk | Effort |
|---|---|---|---|
| Static templates only | Low | Lowest | Low |
| Free-form LLM | High | High | Low |
| **Grounded LLM + validators + fallback** (chosen) | High | Low (checked) | Medium |
| Fine-tuned model | High | Medium | High; not justified for the POC |

## Consequences
- Compliance must own approved benefit copy in DE/EN (a critical-path item for week 3).
- The template fallback always exists, so the UI never blocks on the model.
- Revisit: let Compliance approve "prompt + model + eval baseline" as a bundle per release.
