# ADR-005: Immutable decision evidence and a hash-chained audit ledger in PostgreSQL

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, Security, Compliance

## Context
Complaints, the insurance ombudsman and BaFin may ask *why* a customer received (or did not receive) an offer, possibly years later. BR-11 requires skip logging. The EIOPA AI Opinion stresses record-keeping.

## Decision
- Store immutable `policy_snapshot` (with hash), `decision_run` (ruleset + engine version, input/output hashes), `rule_evaluation` (clauses), `narrative` versions shown, `officer_action` (reversals, not updates) and the frozen letter PDF hash.
- `audit.audit_event` is append-only and hash-chained (`hash = sha256(prev_hash || payload || time)`), written in the same transaction as the state change. A nightly job verifies the chain and anchors the daily head hash to immutable Blob storage.
- Append-only enforced by DB triggers; exported to Sentinel.

## Options considered
- **Azure Confidential Ledger:** stronger tamper-proofing; extra service and cost. *Option for the pilot if Security requires it* (anchor daily digests there).
- **Event-sourcing the whole system:** powerful, but too much complexity for the POC.
- **Application logs only:** not queryable or reliable enough. Rejected.

## Consequences
- Replay: any decision can be recomputed and compared (`output_sha256`).
- Storage growth is modest (JSON traces of ~30 rules per run); partition by month in the pilot.
