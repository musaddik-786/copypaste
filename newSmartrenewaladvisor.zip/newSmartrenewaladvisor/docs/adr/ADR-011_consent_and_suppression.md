# ADR-011: Purpose-specific consent and fail-closed suppression gatekeepers

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** DPO, Head of Compliance, Lead Architect

## Context
The BRD requires explicit advisory consent and universal suppression on complaints, disputes, open claims and opt-outs. German law separates channels (UWG §7: email/phone consent, the existing-customer email exception, postal advertising) and GDPR Art. 21 gives an absolute right to object to direct marketing.

## Decision
- Consent is stored per **purpose and channel** with evidence (`src.consent` → `consent.advisory_renewal`). The demo uses the BRD's strict rule: only `GRANTED` passes; `UNSPECIFIED` suppresses. Legal to confirm per channel (D-16).
- All gatekeepers are evaluated (complete audit); any hit suppresses; a missing gatekeeper fact suppresses (`SUPPRESS_DATA_INTEGRITY`).
- Vulnerability is a flag only; its reason never enters SRA (possible GDPR Art. 9 data).
- A consent change event re-evaluates open cases.

## Consequences
- Lower reach, higher defensibility: by design, the system stays silent when unsure.
