# ADR-002: Rules as a versioned JsonLogic catalog executed by an embedded deterministic engine

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, BA Lead, Engineering

## Context
There are 34 rule entries (1 window, 6 gatekeepers, 7 candidate filters, 20 opportunity rules) and 23 parameters, with frequent threshold changes expected and many open decisions (D-01..D-17). BAs need to change thresholds without deployments; auditors need clause-level traces; the demo is ~6 weeks away; the stack is Python on Azure.

## Decision
Represent rules as a **JSON catalog** (metadata, parameters, product target markets, bundle table) with conditions in **JsonLogic**. Execute them in an in-process, pure Python engine (`packages/sra_rules`) behind a `DecisionEngine` port that emits a clause-level trace. The repository's `rules/reference_evaluator` is the executable specification; the production engine must match it on all golden tests. Business users edit **parameters** (and, later, decision tables) through the Rule Admin UI with maker-checker (ADR-010).

## Options considered
| Option | Complexity | BA-editability | Trace/audit | Fit for 6-week demo | Notes |
|---|---|---|---|---|---|
| A. Hard-coded Python | Low | None | Custom | Yes | Every threshold change is a deploy; rejected |
| **B. JsonLogic catalog + embedded engine** (chosen) | Low–Med | Parameters via UI; logic via PR | Full clause trace | Yes, already running (31/31) | JsonLogic has Python/JS/.NET/Java libraries; the UI can preview rules in-browser |
| C. GoRules ZEN (JDM decision graphs, Rust core, Python bindings) | Med | Visual decision tables/graphs | Node trace | Possible | Strong option for pilot if BAs must author logic visually; open-source engine |
| D. DMN engine (Drools/Kogito, Camunda 8) | High | DMN modelers | Standard DMN audit | Risky | Java/JVM runtime; enterprise standard; consider if the client mandates DMN |
| E. Azure Logic Apps Rules Engine | Med | Rules composer | Limited | Risky | Couples rules to Logic Apps (.NET); less portable |

## Trade-off analysis
B gives the shortest path with complete traceability and zero licence cost, and the engine is tiny and auditable. Its weakness is visual authoring of *logic*. This is mitigated by parameter editing (most expected changes) and by keeping the `DecisionEngine` port so C or D can be adopted without changing callers or golden tests.

## Consequences
- Easier: diffs are plain JSON in Git and the DB; golden tests run in CI in under 1 s; identical evaluation in the browser for the admin preview.
- Harder: complex temporal logic must be pre-computed by the Fact Builder (by design, which keeps rules simple).
- Revisit at pilot: if BAs need to author new rule logic themselves, run a 2-week spike on ZEN vs DMN using the golden suite as acceptance.

## Action items
1. [ ] JSON Schema for the catalog; CI validation.
2. [ ] `make contract-test` (production engine == reference evaluator).
3. [ ] Pilot spike decision on C/D.
