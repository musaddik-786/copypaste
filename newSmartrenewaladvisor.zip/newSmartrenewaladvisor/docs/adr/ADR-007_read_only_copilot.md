# ADR-007: Officer Copilot is a read-only, case-scoped agent with sandboxed what-if

**Status:** Proposed · **Date:** 2026-10-14 · **Deciders:** Lead Architect, AI Lead, Security

## Context
The officer needs fast answers ("why not X?", "what if…?", "what does the policy cover?") to standardise advisory quality. Agentic AI is a client expectation, but excessive agency is a top LLM risk.

## Decision
Build the copilot with **Microsoft Agent Framework (Python)**, hosted in the SRA container (or Foundry Agent Service hosted agents), with six read-only tools: `get_case_summary`, `get_decision_trace`, `explain_rule`, `simulate_what_if` (sandbox `decision_run`, never persisted to recommendations), `search_product_terms` (AI Search over approved AVB/IPID), `draft_call_notes`. Session bound to one case; RBAC enforced in each tool; prompt shields; transcripts stored.

## Options considered
- **Claude Agent SDK:** excellent tool-use ergonomics; supported on Foundry hosting; constrained by data residency today (ADR-008). Keep as an alternative behind the same tool interfaces.
- **LangGraph:** flexible graph control; additional dependency; no clear advantage here.
- **Copilot with write tools (include/skip):** rejected (excessive agency, HITL dilution).

## Consequences
- The what-if tool is a strong demo moment, at little risk because it reuses the deterministic engine.
- Red-team suite is mandatory before every release.
