# Executive Summary

## What we are building

The **Smart Renewal Advisor (SRA)** supports Renewal Officers inside the renewal workflow. It is not an outbound sales engine. When the Policy Administration System (PAS) creates an annual renewal quote, SRA:

1. checks whether the customer may be approached at all (consent, arrears, complaints, disputes, open claims, vulnerability);
2. works out which upgrade (upsell) or companion policy (cross-sell) fits the verified facts and the product target market;
3. prices it deterministically, including any multi-policy bundle saving;
4. explains the recommendation in plain language for the officer and the customer letter, in German and English;
5. lets the officer **Include, Skip (with reason) or Defer** it, then produces a compliant renewal letter that keeps the optional advisory block separate from the binding renewal terms.

Scope: Germany / EU, EUR, personal lines (Car, Home Building, Home Contents, Personal Liability, Animal/Pet). The first goal is a client demo; the architecture is built so the same design can go to a pilot.

## The core architectural decision: rules decide, AI explains, humans approve

> **Eligibility, suppression, pricing and ranking are 100% deterministic and live outside the AI.** Generative AI is used only where it adds value and can be checked: explaining a decision that has already been made, and helping the officer understand it. The officer makes the final decision.

This is the answer to "should I separate the rules from the AI agent?" Yes. It is the main design choice, and the reasons are practical:

| Concern | Why rules must sit outside the LLM |
|---|---|
| Regulation | IDD Art. 20/25 (demands-and-needs, target market) and the EIOPA AI Opinion (Aug 2025) expect every offer to be traceable to the facts and rules behind it. A rule trace does this; an LLM's reasoning does not. |
| Reproducibility | The same input + ruleset version must always give the same output, for complaints, BaFin enquiries and the ombudsman (Versicherungsombudsmann). LLMs are not deterministic. |
| Business ownership | BAs and Compliance change thresholds (cooldowns, mileage, flood zones) through a maker-checker workflow. No prompt engineering, no code deploy. |
| Testability | 31 golden tests (all 10 BRD acceptance criteria that the engine covers, plus scenarios and edge cases) run in milliseconds in CI. |
| Cost and latency | Rule evaluation takes microseconds and costs nothing per call. LLM calls are kept to the narrative and copilot, and cached by fact-pack hash. |

## How this is positioned as an AI use case

SRA is a **compound AI system**: a deterministic decision core plus three AI capabilities.

- **GenAI Explain & Draft.** Personal, grounded explanations for each recommendation: the officer's "Why recommended / Current gap / How it helps" card, and the two-sentence rationale in the customer letter, in DE and EN. Every number and benefit claim is checked against the decision record and Compliance-approved product copy before anyone sees it.
- **Agentic Officer Copilot.** A case-scoped assistant that answers "Why wasn't Roadside offered?" from the rule trace, runs "What if she tells us she has a dog?" as a sandboxed re-evaluation, and quotes the policy wording (AVB/IPID) with citations. It is read-only and cannot change a decision.
- **AI-assisted delivery (AI SDLC).** Engineers build with Claude Code against an executable specification (rule catalog + golden tests + CLAUDE.md invariants), with sub-agents for rules engineering, compliance review and model evaluation.
- **Roadmap (not in the demo):** propensity-to-accept ML to rank *within* the rule-approved set, and rule-tuning analytics from skip reasons and outcomes.

The client message: *AI where language and judgement support help the officer; deterministic rules where the law expects certainty.*

## What the analysis of the BA material found

- **20 conflicts** between the BRD and the Rules document. Rule IDs BR-01 to BR-07 mean different things in each document, and the acceptance criteria cite a third numbering. Thresholds also differ: NCD bonus tier 4 vs 8, roadside 15,000 vs 12,000 km, cooldown 6/12 months vs 180 days, flood zones. Both documents reference priority tiers without defining them.
- **Prototype pricing errors**, repeated in the Rules document (e.g. bundle saving €37.75 where 5% × €760 = €38.00). This shows why money must never be computed by hand or by an LLM.
- **Prototype narrative copy that would fail a compliance review**: unsupported statistics ("18–24% increase", "statistically more exposed"), invented values ("€420,000+ property"), absolute claims ("100% all-risks", "guaranteed") and a "household profiling" disclosure.
- **Missing compliance features** in the prototype: no Defer, no explicit opt-in, no GDPR Art. 21 objection notice, no IPID for cross-sells, and no visible rule trace.
- **Missed P1 gap**: the reconciled rules find that Elena has no personal liability cover (her pet policy only includes dog-keeper liability).

All of this is resolved in a **reconciled rule catalog v1.0 (draft)**: 1 window rule, 6 gatekeepers, 7 candidate filters (plus the qualification step) and 20 opportunity rules, with namespaced IDs, parameters and source references to both BA documents. It runs on a reference evaluator and passes **31/31 golden tests**. **17 open decisions** (D-01 to D-17) need BA or Compliance sign-off; each has a proposed default, so engineering is not blocked.

## Platform

Azure, Germany West Central, run as a modular monolith on Azure Container Apps. PostgreSQL Flexible Server holds snapshots, decisions, rules and a hash-chained audit ledger. API Management acts as the REST and AI gateway, with Entra ID for sign-in. Foundry hosts the models.

**Model routing reflects a current constraint.** Azure OpenAI GPT models are available as *Data Zone EU* deployments and are the default for anything derived from real customers. Claude on Microsoft Foundry is GA but, per Microsoft's documentation as of this writing, has **no EU data zone** (Global or US only), so it is limited to synthetic demo data until that changes. Both sit behind the same gateway abstraction, so switching models is a configuration change.

## Delivery

About 6 weeks to a client-ready demo with a 6–7 person team using Claude Code (see §7), followed by an optional 8–10 week pilot hardening phase. The decision engine and golden tests already exist as an executable specification, which removes the biggest risk: misunderstood rules.

## Decisions requested now

1. Approve **ADR-001** (rules outside the AI) and **ADR-008** (EU model routing).
2. BA/Compliance to confirm the top open decisions: **D-01** Personal Accident scope, **D-02** open-claim suppression scope, **D-03** cooldown values, **D-11** bundle discount model, **D-16** consent model.
3. Confirm the client's demo branding and data. The source file name references a real insurer, while the content is German/EU. The demo must use synthetic data and neutral branding unless the client approves otherwise.
