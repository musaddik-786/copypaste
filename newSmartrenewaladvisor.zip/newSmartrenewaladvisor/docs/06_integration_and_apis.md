# 6. Integration & API Contracts

## 6.1 Integration patterns

| Integration | Direction | Pattern | Contract | POC implementation |
|---|---|---|---|---|
| Renewal quote created | PAS → SRA | Event (Service Bus topic, CloudEvents 1.0, *thin*: IDs only) | `contracts/events/renewal_quote_created.v1.schema.json` | Seeder publishes events for the demo personas |
| Policy snapshot | SRA → PAS | Sync REST pull (`GET /policies/{id}/snapshot?asOf=`) | Adapter interface `PasSnapshotPort` | Reads `src.*` |
| Rating quotes for riders/companions | SRA → PAS Rating | Sync REST (`POST /rating/quotes` with product codes + variant) | `RatingPort`; returns gross, tax, instalment surcharge, validity | Reads `src.rating_quote` |
| Consent, complaints, declared facts, vulnerability flag | SRA → CRM | Sync REST | `CrmPort` | Reads `src.consent`, `src.complaint`, `src.customer_declared_fact` |
| Claims status & history | SRA → Claims | Sync REST | `ClaimsPort` | Reads `src.claim` |
| Approved letter | SRA → Output Management | Async (Service Bus `renewal-letter-approved` + PDF in Blob, SAS link) | Letter event schema (to define with OMS team) | Writes PDF to Blob, marks dispatched |
| Customer opt-in / decline | Portal/CSR → SRA | Event or REST callback | `RecommendationResponse` | Console "simulate customer response" button |
| Endorsement / new policy | SRA → PAS | Out of POC scope (CSR completes in PAS) | — | — |
| Objection / consent change | CRM → SRA | Event `consent.changed` | Triggers re-evaluation of open cases | Manual toggle in demo |

**Why thin events + pull:** PII stays out of the broker. The snapshot is fetched once, hashed and stored in one place, and PAS remains the source of truth at evaluation time.

## 6.2 Reliability rules

- **Idempotency:** the event `id` and `quote_id` + `quote_version` are de-duplicated; re-delivery is a no-op.
- **Ordering:** a newer `quote_version` supersedes the older one; older events arriving late are ignored.
- **Retries:** exponential back-off for adapter calls; after 5 attempts the case is marked with a data-integrity error, and the officer sees "data unavailable, standard renewal only". This is fail-closed.
- **Stale check on officer open:** compare the source `last_modified` (consent, complaints, claims) with `snapshot.captured_at`; re-pull if newer.
- **Timeouts:** adapters 2 s; rating 3 s; LLM 20 s (async, never blocks the officer).
- **DLQ** monitored with alerts; a replay tool is provided.

## 6.3 Officer / admin API (summary)

Full specification: `contracts/openapi.v1.yaml`.

| Endpoint | Purpose | Roles |
|---|---|---|
| `GET /cases`, `GET /cases/kpis` | Queue, filters, KPIs | Officer, Supervisor |
| `GET /cases/{id}` | Policy details (customer, coverage, risk, data quality) | Officer, Supervisor |
| `POST /cases/{id}/evaluations` | "Generate Possible Opportunities" (re-evaluate if stale) | Officer |
| `GET /cases/{id}/recommendations?lang=` | Cards: narrative, pricing, evidence | Officer |
| `GET /decision-runs/{id}/trace` | Full trace | Supervisor, Auditor, Copilot |
| `POST /recommendations/{id}/actions` | Include / Skip (reason) / Defer (reason + date) | Officer |
| `POST /recommendations/{id}/actions/{aid}/reversal` | Undo before dispatch | Officer |
| `PUT /recommendations/{id}/narrative` | Officer edit (re-validated) | Officer |
| `GET /cases/{id}/letter-draft`, `POST …/approve`, `POST /cases/{id}/dispatch` | Letter preview, approval, dispatch | Officer |
| `POST /cases/{id}/copilot/sessions`, `POST /copilot/sessions/{sid}/messages` (SSE) | Copilot | Officer |
| `/rulesets`, `/rulesets/{v}/change-requests`, `/change-requests/{id}/decision`, `/rulesets/{v}/publish` | Rule lifecycle | Rule Author, Rule Approver |
| `GET /audit/cases/{id}` | Audit trail + hash verification | Auditor, Supervisor |

API conventions: JSON, camelCase on the wire; money as decimal strings; `If-Match` with `row_version` on mutations; problem+json errors (RFC 9457); correlation id propagated to App Insights; every mutation writes an audit event.

## 6.4 Rule lifecycle (maker-checker)

1. A **Rule Author** (BA) edits parameters or rules in the Rule Admin UI, which produces a JSON Patch against the published catalog and a justification.
2. The system automatically runs the **golden suite** and a **backtest** over the last N snapshots (sandbox). The impact report shows which decisions would change, by rule, LOB and outcome.
3. A **Rule Approver** (Compliance; must be a different person) approves or rejects the change.
4. **Publish** creates a new immutable `ruleset_version` with a SHA-256 of the catalog, effective immediately or at a set time. Open cases keep the version they were evaluated with unless re-evaluated.
5. Every decision records `ruleset_version`, so any letter can be traced to the exact rules in force.
