# 5. Regulatory Alignment, Security & Control Matrix (EU / Germany)

> This section is an architecture view of regulatory requirements, written to guide design and give the client's Legal, Compliance and DPO functions something concrete to review. It is not legal advice. Every item marked *Legal to confirm* needs the client's sign-off.

## 5.1 Regulatory landscape and how the design responds

| Framework | Relevant requirement | Design response |
|---|---|---|
| **IDD** (Directive (EU) 2016/97), Art. 17 | Act honestly, fairly and professionally in the customer's best interest; marketing must be fair, clear and not misleading; remuneration must not conflict with the customer's interest | Gatekeepers GK-01..06; prohibited-phrase lexicon; **officer KPIs must not reward include-rate** (recommendation to client HR/Sales: measure advisory quality, not conversion) |
| IDD Art. 20 | Demands and needs; proposed contracts consistent with them; IPID for non-life products before conclusion | Opportunity rules model *needs*; Data Integrity Gate; `advice_record`; IPID attached to every cross-sell advisory block |
| IDD Art. 24 | Cross-selling: say whether components can be bought separately; give separate costs | Cross-sell pricing always `SEPARATE_POLICY_ITEMISED`: standalone premium + bundle saving shown separately (BAC-10) |
| IDD Art. 25 + Delegated Reg. (EU) 2017/2358 (POG) | Distribute within the identified target market | `ref.product.target_market` enforced by EL-04; owned by Product Oversight |
| **VVG** §6 / §7 / VVG-InfoV | Advice + documentation; pre-contract information in text form | Advice documentation captured when the customer engages (CSR/portal); product documents versioned in `ref.product_document` (*Legal to confirm per channel*) |
| VVG §8 | 14-day right of withdrawal for new contracts | Letter / opt-in confirmation template includes the withdrawal information for companion policies |
| VVG §40 | Premium-increase notice and termination right | Belongs in the **core renewal section** (PAS-provided wording); SRA must not move or dilute it, so it is kept separate from the advisory block |
| **UWG** §5 / §7 | No misleading claims; advertising consent rules by channel (email/phone need consent; existing-customer exception §7(3) for email) | Narrative validators; channel-aware consent model; BRD's stricter "explicit advisory consent" kept as default (D-16, *Legal to confirm*) |
| **GDPR** Art. 5, 6, 7 | Purpose limitation, minimisation, lawful basis, demonstrable consent | Purpose-specific consent records with evidence ref; only rule-required facts derived; DOB hidden |
| GDPR Art. 13/14, 21 | Transparency; right to object to direct marketing, brought to attention explicitly at the latest with the first communication | Letter section `OBJECTION_NOTICE` is mandatory in every advisory letter; objection → consent REVOKED → GK-01 suppresses |
| GDPR Art. 22 | No solely automated decisions with legal or similarly significant effects | Officer reviews every recommendation; suppression = "no offer", with the standard renewal unaffected; document this assessment in the DPIA |
| GDPR Art. 25, 32, 35 | Privacy by design; security; DPIA for systematic evaluation/profiling at scale | Pseudonymised fact pack; crypto-shredding; **DPIA required before pilot** (template sections map to this document) |
| **GDV Code of Conduct** (Art. 40 GDPR code for German insurers) | Rules on using customer data for advertising and market research | Map SRA processing to the code's advertising provisions if the client has acceded (*Legal to confirm*) |
| **EU AI Act** (Reg. (EU) 2024/1689) | Annex III high-risk in insurance = risk assessment and pricing for **life and health** insurance. Art. 4 AI literacy (since Feb 2025). Art. 50 transparency (from Aug 2026). The Digital Omnibus (in force 27 Jul 2026) moved Annex III high-risk deadlines to 2 Dec 2027. | SRA does not price or assess risk for life or health insurance; GenAI explains P&C recommendations decided by rules → assessed as **not high-risk** (document the classification; re-assess if Personal Accident pricing or ML ranking is added). Art. 50: copilot discloses that it is AI; AI-drafted text is labelled internally and reviewed by the officer. Art. 4: officer training module. |
| **EIOPA Opinion on AI governance & risk management** (Aug 2025) | Proportionate governance: fairness, data governance, documentation & record-keeping, transparency & explainability, human oversight, accuracy/robustness/cybersecurity | See §5.2 mapping |
| **DORA** (Reg. (EU) 2022/2554) + **BaFin guidance on ICT risks in the use of AI** (Dec 2025) | ICT risk management, third-party risk (cloud, model providers), register of information, exit strategies, testing | Azure + model providers in the register of information; model abstraction = exit strategy; resilience tests; AI lifecycle controls (§5.3) |
| **Solvency II** Art. 41 (system of governance) | Sound governance incl. outsourcing | SRA covered by the client's model / IT governance; outsourcing assessment for cloud services |
| **Accessibility** (BFSG / European Accessibility Act) | Accessible digital consumer services | Console WCAG 2.1 AA; assess BFSG for customer-portal journeys (*Legal to confirm*) |

## 5.2 EIOPA AI Opinion principles → SRA controls

| Principle | Control in SRA |
|---|---|
| Risk-based, proportionate governance | AI use-case register entry; risk tiering: deterministic core = standard IT controls; GenAI narrative + copilot = AI controls below |
| Fairness & ethics | Rules use no protected attributes; protected-attribute validator on narratives; fairness review of rule outcomes by segment in the rule-effectiveness report |
| Data governance | Fact provenance (`snapshot_fact`); data-quality gate; minimised fact pack; Purview classification |
| Documentation & record-keeping | Immutable snapshot, decision run, narrative version, action, letter hash; prompt and model registries; eval records |
| Transparency & explainability | Rule trace with clause values; evidence panel; copilot citations; customer-facing rationale grounded in facts |
| Human oversight | Officer Include/Skip/Defer; letter approval; four-eyes for rule changes; Compliance approval of prompts and benefit copy |
| Accuracy, robustness, cybersecurity | Golden tests; replay determinism; validators + fallback; red-team evals; prompt shields; private networking; pen test before pilot |

## 5.3 Security architecture (summary)

- **Identity:** Entra ID SSO, MFA and Conditional Access; app roles; managed identities; no shared accounts. Rule approver ≠ author enforced in the DB.
- **Data protection:** TLS 1.2+; encryption at rest with CMK (Key Vault); column tagging; crypto-shredding for erasure.
- **Network (pilot):** private endpoints, VNet-integrated Container Apps, APIM internal mode behind Front Door/WAF; Foundry endpoints private; no public egress from the copilot.
- **AppSec:** OWASP ASVS L2 target; SAST/DAST/dependency scanning in CI; **OWASP Top 10 for LLM Applications** threat model (prompt injection, insecure output handling, excessive agency, sensitive-information disclosure) mapped to the controls above.
- **Monitoring:** audit events → Sentinel; anomaly alerts (bulk case reads, unusual what-if volume, repeated validator failures).
- **Resilience:** zone-redundant PG (pilot); RPO ≤ 15 min, RTO ≤ 4 h; degradation modes (§1.8).

## 5.4 Control matrix (used by reviewers and the `compliance-reviewer` sub-agent)

| ID | Control | Implemented by | Evidence / test |
|---|---|---|---|
| CTL-01 | Gatekeepers evaluated before any opportunity; fail closed | `sra_rules` stage 1 | BAC-06, SCN-04, X-01, X-02, X-03, X-12, X-16 |
| CTL-02 | No PII in LLM payloads | FactPackBuilder + PII validator + gateway policy | Unit tests; gateway logs; red-team |
| CTL-03 | EU-only inference for non-synthetic data | ModelRouter + APIM policy | Integration test with a SYNTHETIC/PSEUDONYMISED matrix |
| CTL-04 | BR-13 demarcation in letters (core terms → optional advisory block → opt-in → objection notice → IPID) | `letter_section` model + template | Snapshot tests of rendered PDF; Compliance sign-off |
| CTL-05 | No pre-ticked opt-ins anywhere | Console + portal + letter | UI tests; manual review |
| CTL-06 | Cross-sell prices itemised with a separate bundle saving | Pricing + template | BAC-10 |
| CTL-07 | Every narrative validated (incl. officer edits); fallback available | Narrative Service | Eval suite gates; unit tests |
| CTL-08 | Every state change audited in the same transaction | Repository layer | Integration tests; hash-chain verification job |
| CTL-09 | Copilot read-only; what-if sandboxed | Tool registry | Red-team suite |
| CTL-10 | Skip needs a reason; cooldown-creating reasons write the ledger | DB CHECK + service | BAC-04/05, X-09; API tests |
| CTL-11 | Ruleset publish requires four-eyes + green golden run + backtest report | Rule Admin | DB constraints; pipeline gate |
| CTL-12 | Replay determinism | Decision Service | Nightly replay sample; `output_sha256` match |

## 5.5 Customer letter: advisory block content (template)

1. **Core renewal section** (PAS wording, unchanged): renewal premium, premium change, VVG §40 information, payment details.
2. **Separator + heading:** "Optional recommendation (not part of your renewal)": *Recommended Coverage — [Name]* (upsell) or *Recommended Policy — [Name]* (cross-sell), per BRD §7.1.
3. **Rationale:** validated two-sentence `letter_rationale`.
4. **Financial table:** expiring premium, renewal premium, add-on or standalone premium (annual and monthly equivalent, with any instalment surcharge stated), bundle discount % and saving, resulting total. For a cross-sell: "This policy can be taken out separately at €X."
5. **Opt-in instruction:** "If you would like to add this, please contact us / select it in your customer portal." No reply form with pre-ticked boxes; nothing changes without the customer's action.
6. **Documents:** IPID (and AVB link) for the recommended product; withdrawal information for companion policies.
7. **Objection notice (GDPR Art. 21):** how to object to advisory/marketing communications; honoured immediately (GK-01).
