# 4. AI Design: Positioning, Narrative Generation & Officer Copilot

## 4.1 Positioning: why this is an AI use case

Rules alone answer *what* may be offered. The business problem in the BRD is more than that: renewals are treated as "an administrative invoicing exercise", advisory quality depends on the individual officer, and generic scripts erode trust. Closing those gaps needs **language and reasoning support at scale**, which is where AI adds value:

| Business objective (BRD §1) | AI capability | Measurable outcome |
|---|---|---|
| "Clear talking points without extra navigation" | GenAI officer card: why / gap / how it helps, grounded in the rule trace | Handling time per case; officer acceptance of AI text without edits |
| "Transparent, value-driven advisory" | GenAI customer rationale in plain German/English, personalised to verified facts | Opt-in rate per surfaced recommendation; complaint rate (target: no increase) |
| "Standardise quality regardless of agent experience" | Copilot explains rules, product wording and what-ifs on demand | Variance in include/skip rates across officers; onboarding time |
| "Continuous rule tuning" (BR-11) | Roadmap: AI summarisation of skip reasons and outcomes per rule → change-request drafts | Rule changes per quarter driven by evidence |
| "Fair and compliant" | Deterministic core + AI guardrails + full audit | Zero unsuitable offers in QA sampling; 100% traceability |

**Pitch line for the client:** *"The rules engine is the underwriter's and compliance officer's brain: deterministic and auditable. The AI is the advisor's voice and the officer's assistant: it explains, drafts and answers, and it is checked before anyone reads it."*

**Not an "autonomous agent that sells".** The design avoids an LLM agent that decides what to offer. That approach would not meet IDD demands-and-needs and target-market obligations, GDPR transparency expectations, the EIOPA AI Opinion's explainability and human-oversight principles, or the client's model risk management. See ADR-001.

## 4.2 Narrative Service ("Explain & Draft")

![Narrative guardrail pipeline](diagrams/05_narrative_guardrails.png)

### 4.2.1 Fact pack (input)

A deterministic builder assembles **only** what the selected rule used, plus approved product copy. Example for David's NCD recommendation:

```json
{
  "fact_pack_version": "1", "language": "en", "audience": "OFFICER",
  "tokens": { "first_name": "{{FIRST_NAME}}", "city": "{{CITY}}" },
  "recommendation": { "rule_id": "UP-CAR-04", "opportunity_type": "UPSELL",
                      "product_code": "CAR_NCD_PROTECTION", "product_name": "No-Claims Discount Protection", "priority_tier": "P3" },
  "pricing": { "base_renewal_premium": "445.00", "incremental_annual": "45.60",
               "incremental_monthly_equiv": "3.80", "net_annual_total": "490.60" },
  "facts": [ { "key": "motor.bonus_tier", "label": "No-claims class (SF)", "value": 12 },
             { "key": "claims.at_fault_36m", "label": "At-fault claims, last 36 months", "value": 0 },
             { "key": "policy.coverage_level", "label": "Cover", "value": "Full Comprehensive" } ],
  "current_gap": [ "No-claims discount protection is not part of the current policy." ],
  "approved_benefits": [
    { "statement_key": "NCD.ONE_CLAIM_PER_YEAR", "text": "One at-fault claim per calendar year does not downgrade the no-claims class." },
    { "statement_key": "NCD.RENEWAL_RATE", "text": "The no-claims discount applied at the next renewal is preserved after that claim." } ],
  "style": { "person": "THIRD_PERSON_OFFICER", "max_words_rationale": 60 }
}
```

The prototype's claims ("downgrade his tier by 3 levels", "+€80–100 increase", "18–24%") are **absent** because they are not in the fact pack. If the business wants that comparison, the *Pricing module* must compute it from the tariff's SF-class table, and it enters the fact pack as a verified number.

### 4.2.2 Validators (deterministic, all must pass)

| # | Validator | Fails when | Notes |
|---|---|---|---|
| 1 | Schema | Output does not match `narrative_output.v1` | Structured outputs / JSON mode |
| 2 | Number provenance | Any number in the text is not in `pricing` or `facts` (normalised for DE "45,60 €" vs EN "€45.60") | Blocks invented statistics and prices |
| 3 | Approved claims | Benefit keys not in the approved list; benefit sentences with no semantic match to approved statements (embedding similarity + LLM-judge in evals) | Keeps scope to the AVB |
| 4 | Prohibited phrases | Lexicon hit (`ai/guardrails/prohibited_phrases.yaml`), DE and EN | IDD Art. 17(2), UWG §5 |
| 5 | PII leak | Names, addresses, IBAN, plate or ID patterns appear (tokens excepted) | Defence in depth |
| 6 | Protected attributes | Age, health, nationality etc. mentioned (except whitelisted asset ages) | Fairness |
| 7 | Length & readability | Over the word limit; readability below threshold (Flesch-Amstad for DE) | Plain language |
| 8 | Content Safety + groundedness | Azure AI Content Safety categories; groundedness detection against the fact pack | Platform layer |

On failure: **one** retry with the findings appended, then fallback to the Compliance-approved **static template** for that product (always available). Officer edits go through the same validators (2–6) before saving.

### 4.2.3 Operational design

- **Pre-generation:** after the decision run, for the primary and alternative × {officer, letter} × {DE, EN}. That is up to 8 calls, cached by `fact_pack_sha256`, so a re-evaluation with unchanged facts costs nothing.
- **Determinism where it matters:** temperature ≤ 0.3, fixed prompt version, model deployment pinned; output stored, so the letter never changes after approval.
- **Language:** the customer letter defaults to German (formal *Sie*); the officer UI toggles DE/EN. German quality is an explicit eval metric.
- **Token injection:** `{{FIRST_NAME}}` and `{{CITY}}` are replaced server side after validation. The model never sees the real values.
- **Labelling:** the console shows an "AI-drafted, review before sending" badge; `narrative.origin` records LLM / TEMPLATE_FALLBACK / OFFICER_EDIT.

## 4.3 Officer Copilot (agentic)

![Copilot](diagrams/06_copilot.png)

| Tool | Input | Output | Guard |
|---|---|---|---|
| `get_case_summary` | case_id (bound by session) | Pseudonymised case view | RBAC: officer assigned or supervisor |
| `get_decision_trace` | decision_run_id (optional) | Rule outcomes + clauses | Read-only |
| `explain_rule` | rule_id | Plain-language rule definition, parameters, regulatory refs, source refs | From the published ruleset |
| `simulate_what_if` | `{fact_path: value}` overrides (allow-listed paths) | New decision summary + diff vs current | `is_sandbox = true`; never affects letters; logged |
| `search_product_terms` | query, product_code | AVB/IPID passages with doc id/version | AI Search over approved documents only |
| `draft_call_notes` | — | Draft note text | Officer must save explicitly |

Example exchange (Elena):

> **Officer:** Why didn't we offer her building insurance? She owns her home.
>
> **Copilot:** AI assistant – answers are based on the decision record for this case. Building insurance was not offered because the dwelling type is missing from her record (rule CS-HOM-02 → `DATA_INTEGRITY_FAIL` on `customer.dwelling_type`, ruleset 1.0.0-draft). The engine does not guess missing facts. If you confirm the dwelling type with her, the case can be re-evaluated. Do you want me to simulate the result for a detached house?
>
> **Officer:** Yes.
>
> **Copilot:** *(simulate_what_if: customer.dwelling_type = DETACHED)* In the simulation, Residential Building Insurance becomes eligible (P2). Personal Liability stays primary (P1) and Car Insurance stays the alternative because of its higher bundle saving (€70.80). Nothing has been changed; update the record in CRM and re-run the evaluation to make this real.

**Framework choice.** Microsoft Agent Framework (GA April 2026; Python), hosted in the SRA container, or in Foundry Agent Service hosted agents if the client prefers managed hosting. Tools are plain Python functions calling SRA's own services, which keeps the agent portable. The Claude Agent SDK is a supported alternative on the same hosting, subject to the model-routing constraint in §4.4.

**Agent safety controls.** Session bound to one case; tool allow-list; server-side RBAC on every tool; CRM/AVB content wrapped as untrusted data; Azure AI Content Safety prompt shields (direct and indirect injection); max 8 tool calls per turn; no outbound internet; transcript and tool calls stored (`sra.copilot_*`); thumbs up/down feedback.

## 4.4 Model strategy & routing

| Workload | Default deployment | Why |
|---|---|---|
| Narratives (any real or pseudonymised customer data) | **Azure OpenAI GPT, Data Zone Standard (EU)**, Germany West Central / Sweden Central | Inference stays in the EU data zone; Microsoft-operated first-party model; easiest path through the client's DPO and procurement |
| Copilot (real data) | Same EU deployment | Same reason |
| Demo with synthetic personas, eval benchmarking | Claude on Foundry *or* GPT | Per Microsoft's Claude-on-Foundry privacy documentation, Anthropic acts as an independent processor and processing is limited to Global or US data-zone deployments (no EU zone today). Use only with `data_class = SYNTHETIC`. |
| Engineering (Claude Code) | Claude via the client-approved enterprise channel | No customer data in repositories or prompts (synthetic fixtures only) |

Routing is enforced twice: by the `ModelRouter` (refuses a deployment whose `allowed_data_classes` lacks the call's data class) and by an APIM AI Gateway policy (header `x-sra-data-class`). Re-assess Claude for real data when an EU data zone is published. Because the model sits behind the gateway contract, switching is a configuration change plus an eval run.

## 4.5 Evaluation & monitoring (LLMOps)

| Suite | Content | Gate |
|---|---|---|
| `narrative_golden_v1` | 5 personas × 11 eligible recommendations × 2 audiences × 2 languages (44 items), plus adversarial facts (e.g. extreme numbers) | 100% schema, 100% number provenance, 100% approved claims, 0 prohibited phrases; groundedness ≥ 4/5; DE fluency ≥ 4/5 (judge + 10% human sample) |
| `copilot_task_v1` | 40 officer questions with expected citations / tool calls | ≥ 90% correct tool choice; 100% citations present |
| `copilot_redteam_v1` | Write-action requests, prompt injection in CRM notes, "offer it anyway", other-customer data, legal advice | 100% safe refusal |
| Online | Fallback rate, validator failure mix, officer edit distance, thumbs-down rate, latency, tokens/cost per case | Alerts on drift; weekly review with Compliance |

Evals run in CI on any change to prompts, fact-pack builder, validators or model deployment (Foundry evaluations + the repository harness). Results go to `sra.eval_run`.

## 4.6 Roadmap AI (after the demo)

1. **Propensity-to-accept ranking (ML):** rank only *within* the rule-approved set and only *after* the priority tier. Explainable features (e.g. gradient boosting + SHAP), fairness tests, and its own model risk documentation.
2. **Rule-tuning insights:** monthly AI-generated summaries of `v_rule_effectiveness` and free-text skip comments, producing draft change requests for BA review.
3. **AI-assisted rule authoring:** BA writes a rule in plain language; the assistant drafts JsonLogic + golden tests; normal maker-checker applies.
4. **Customer-portal explainer:** the same validated narrative, plus a guarded FAQ for customers reviewing their renewal online.
