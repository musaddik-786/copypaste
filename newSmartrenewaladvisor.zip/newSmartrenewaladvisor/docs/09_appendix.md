# Appendix

## A. Engineering pack contents

| Path | Content |
|---|---|
| `rules/rule_catalog.v1.0.json` | Reconciled catalog: window, 6 gatekeepers, 7 candidate filters + qualification step, 20 opportunity rules, 23 parameters, 21 products with target markets, bundle table |
| `rules/golden/personas.json`, `golden_tests.json` | 5 persona Decision Contexts; 31 golden tests (BAC-01..10, SCN-01..05, X-01..16) |
| `rules/reference_evaluator/` | `sra_reference.py` (executable spec), `run_golden.py` (CI gate, `--trace` option) |
| `db/001_sra_schema.sql` | PostgreSQL 16 DDL: schemas `ref`, `src` (mock), `rules`, `sra`, `audit`; views for the console |
| `db/002_reference_seed.sql` | LOBs, products, embeddings, bundle rules, skip/defer reasons, regulatory references, model deployments |
| `contracts/openapi.v1.yaml` | Officer, copilot, rule-admin and audit APIs |
| `contracts/events/renewal_quote_created.v1.schema.json` | PAS trigger event (CloudEvents) |
| `contracts/llm/*.schema.json` | Fact pack (LLM input) and narrative output schemas |
| `ai/prompts/*.md`, `ai/guardrails/prohibited_phrases.yaml` | Prompt v1 for narrative and copilot; Compliance lexicon |
| `CLAUDE.md`, `claude_code_setup/` | Claude Code invariants, sub-agents (`rules-engineer`, `compliance-reviewer`, `narrative-evaluator`), `/add-rule` command, golden-test hook |
| `docs/diagrams/*` | Diagram sources (Graphviz / matplotlib) and PNGs |

## B. Glossary (German insurance terms)

| Term | Meaning |
|---|---|
| AVB (Allgemeine Versicherungsbedingungen) | General policy terms and conditions (the policy wording) |
| IPID | Insurance Product Information Document (IDD standardised product sheet for non-life) |
| Kfz-Haftpflicht / Teilkasko / Vollkasko | Motor third-party liability / partial comprehensive / full comprehensive |
| SF-Klasse (Schadenfreiheitsklasse) | No-claims class (bonus-malus tier) |
| Rabattschutz | No-claims discount protection |
| Schutzbrief | Roadside assistance / breakdown cover |
| Fahrerschutz | Driver personal injury cover |
| Wohngebäude- / Hausratversicherung | Residential building / home contents insurance |
| Elementarschadenversicherung | Natural hazards cover (flood, heavy rain, backflow, snow load, landslide) |
| ZÜRS Geo | GDV zoning system for flood hazard (classes 1–4) |
| Starkregen-Gefährdungsklasse | GDV heavy-rain hazard class (independent of river flood zones) |
| Rückstauklappe / Rückstausicherung | Backwater (backflow) valve |
| Privathaftpflicht | Personal liability insurance |
| Tierhalterhaftpflicht (Hund/Pferd) | Animal owner liability (dog/horse); strict keeper liability under §833 BGB |
| Tier-OP-/Tierkrankenversicherung | Pet surgery / pet health insurance |
| Versicherungsteuer | Insurance premium tax (included in gross premiums) |
| Ratenzahlungszuschlag | Surcharge for instalment payments |
| WEG (Wohnungseigentümergemeinschaft) | Owners' association; insures the building of condominium apartments |
| Beratungsdokumentation | Advice documentation (VVG §6 / IDD Art. 20) |
| Widerrufsrecht | Right of withdrawal (VVG §8) |
| Versicherungsombudsmann | Insurance ombudsman (out-of-court dispute resolution) |
| GDV | German Insurance Association (Gesamtverband der Versicherer) |

## C. External references

- EU AI Act Digital Omnibus — in force 27 July 2026; Annex III high-risk obligations deferred to 2 December 2027: [Orrick, July 2026](https://www.orrick.com/en/Insights/2026/07/EU-AI-Act-Update-Digital-Omnibus-Finalizes-8-Compliance-Changes); [Gibson Dunn](https://www.gibsondunn.com/eu-ai-act-omnibus-agreement-postponed-high-risk-deadlines-and-other-key-changes/)
- EIOPA Opinion on AI governance and risk management (EIOPA-BoS-25-360, 6 Aug 2025): [eiopa.europa.eu](https://www.eiopa.europa.eu/eiopa-publishes-opinion-ai-governance-and-risk-management-2025-08-06_en)
- BaFin guidance on ICT risks in the use of AI at financial entities (18 Dec 2025): [Regulation Tomorrow summary](https://www.regulationtomorrow.com/2025/12/bafin-issues-guidance-on-ict-risks-associated-with-the-use-of-ai/); [Baker Tilly](https://www.bakertilly.de/en/post/ict-risks-when-using-ai-new-bafin-guidance)
- Claude models in Microsoft Foundry — data, privacy and security (updated June 2026): [Microsoft Learn](https://learn.microsoft.com/en-us/azure/foundry/responsible-ai/claude-models/data-privacy); [InfoQ, July 2026](https://www.infoq.com/news/2026/07/claude-foundry-ga-europe/)
- Azure OpenAI Data Zone (EU) deployments: [Microsoft Q&A — EU data and processing residency](https://learn.microsoft.com/en-us/answers/questions/5544730/how-to-guarantee-eu-data-and-processing-residency)
- Microsoft Agent Framework 1.0 / Foundry Agent Service: [Microsoft Foundry blog, April 2026](https://devblogs.microsoft.com/foundry/from-local-to-production-the-complete-developer-journey-for-building-composing-and-deploying-ai-agents)
- German natural-hazard insurance reform (opt-out model under discussion; no legal mandate as of mid-2026): [VersicherungsJournal, 23 Jul 2026](https://www.versicherungsjournal.de/markt-und-politik/elementarschaden-regierung-packt-pflichtversicherung-an-156327)
- GoRules ZEN engine (option in ADR-002): [PyPI zen-engine](https://pypi.org/project/zen-engine/)

**Note on natural hazards:** if Germany adopts an opt-out model in which new building policies include natural-hazard cover by default, UP-HOM-01 changes from an upsell into a check that the customer has *not* opted out. This is a parameter or catalog change, not a redesign.
