# 2. Rule Reconciliation & Decisioning Design

## 2.1 Inputs analysed

| Input | Role | Observations |
|---|---|---|
| BRD "Pre-Renewal Cross-Sell & Upsell Agent" v1.0 | Business baseline: flow, scope (4 LOBs), opportunity matrix, BR-01 to BR-13, BAC-01 to BAC-11 | Clear flow and governance; thresholds often vague ("significant market value"); priority tiers referenced but never defined. |
| "Smart Renewal Advisor — Rules" | Detailed gatekeeper and opportunity rules with thresholds and prices | More precise thresholds, but a **different rule-ID scheme**, a different cross-sell matrix, and a product (Personal Accident) outside the BRD scope. |
| `smart_renewal_advisor_prototype.html` | Click-through UI with 5 personas | Good UX baseline (queue, policy details, overlay, letter). Narratives and prices are hard-coded; it contains arithmetic errors and copy that would not pass compliance. |

**Rule of precedence used for reconciliation:** the BRD governs *scope, flow and governance*. The Rules document governs *thresholds* where it is more specific. Where neither is specific, the architect proposes a default, marked `ARCHITECT` with a decision ID. Every catalog entry carries `source_refs` back to both documents.

## 2.2 Conflict register

| ID | Topic | BRD says | Rules doc says | Resolution in catalog v1.0 | Decision |
|---|---|---|---|---|---|
| C-01 | Rule-ID collisions | BR-01 trigger, BR-02 non-duplication, BR-03 endorsement, BR-04 complaint, BR-05 claims, BR-06 cooldown, BR-07 consent | BR-01 consent, BR-02 arrears, BR-03 grievance, BR-04 cooldown, BR-05 driving, BR-06 target market | New namespaced IDs (`W-`, `GK-`, `EL-`, `UP-`, `CS-`, `PR-`) with a mapping table (§2.3). BAC references are re-pointed. | — |
| C-02 | Cooldown | 6 months riders, 12 months companion lines | 180 days for any product | BRD values (stricter for companion lines). | D-03 |
| C-03 | Grievance scope | Open formal complaint | Complaint **or** disputed claim within 180 days | Both: GK-03 (complaint), GK-04 (dispute/litigation within lookback). | — |
| C-04 | Sensitive claims | Any open, unfinalised claim suppresses all outreach | Open property litigation only *disqualifies upgrades* (BR-05) | GK-05: any claim in settlement suppresses; GK-04 **elevates** litigation and disputes to full suppression (conservative change vs Rules doc). | D-02 |
| C-05 | Adverse driving | 2–3 at-fault in 24 months: no automated tier upgrades | ≥2 at-fault in 24 months **or** ≥4 penalty points; placed among gatekeepers but the action only disqualifies upgrades | EL-05 filter applies to `MOTOR_UPGRADE` rules only. Penalty points dropped: insurers do not normally hold driver-register points, so the fact has no lawful, reliable source. | D-05 |
| C-06 | NCD protection | Bonus tier ≥4, clean 12 months | Tier ≥8, 0 at-fault in 36 months | Rules-doc values. | D-04 |
| C-07 | TPL → comprehensive | Two rules (TPL→Partial/Full, Partial→Full), no thresholds | One rule: value ≥ €8,000, age ≤ 8, ≤1 minor claim in 36 months, 0 in 12 months | UP-CAR-01 (→Full, Rules thresholds) + UP-CAR-02 (TPL→Partial, architect thresholds €4,000 / 12 years), in one exclusion group. | D-06 |
| C-08 | Roadside | ≥15,000 km | ≥12,000 km **and** exactly 1 household vehicle | Rules-doc values; new fact `household_vehicle_count`. | D-07 |
| C-09 | Flood / natural hazards | Low/medium geo-risk zones | ZÜRS zone 2–3 + certified backwater valve; zone 4 needs a survey | Zones 1–3 eligible; valve required from zone 2; zone 4 → `REFERRAL_REQUIRED` (never auto-offered). Heavy-rain (Starkregen) exposure does not depend on the ZÜRS flood zone; the heavy-rain class is captured for a later rule. | D-08 |
| C-10 | UP-HOM-02 meaning | Building tier upgrade (age ≥20 or solar/heat pump) | Contents valuables extension (floor area ≥120 m²) | Both kept under different IDs. Valuables is **DRAFT**: floor area alone is a weak demands-and-needs proxy. | D-12 |
| C-11 | Cross-sell matrix | Trigger depends on the *source* LOB (Car→Home, Car→PL, Car→Dog, Home→PL, Home→Car, PL→Contents) | Different pairs (Car→PL, Car→PA, Building→Contents, Pet→Car, PL→Pet Health) | **Gap-based** cross-sells: evaluated on any renewing policy, against the whole portfolio. Union of both matrices. | D-13 |
| C-12 | Personal Accident | Not in the 4-LOB scope | CS-CAR-02 | Kept as an `EXTENSION_PRODUCT` (prototype demo needs it), in an exclusion group with the Driver Injury rider (both cover the same need). | D-01 |
| C-13 | Pet Health for horses | Dogs and cats only | Offered to dog **or horse** owners | Target market = dog or cat owners. | — |
| C-14 | Contents for owners | Any verified owner/tenant | Owner-occupier, detached, ≥140 m² | Size requirement dropped (no suitability basis). | D-13 |
| C-15 | Priority tiers | BAC-09 "Priority 1 vs 3", Scenario 2 "Priority Level 1" | Not defined | P1 existential liability, P2 major asset/income gap, P3 enhancement; tie-break by bundle saving (BR-09), then sequence. | D-09 |
| C-16 | Bundle discount | "Multi-policy bundle discount" | 5–10%, product-specific examples | Per-companion-product % table; basis = renewing premium + companion standalone. Interaction with existing multi-policy discounts is undefined. | D-11 |
| C-17 | Trigger timing | Quote event only; no calendar scan | "Policy maturing in 45–60 days" | Event-driven (BRD). W-01 closes the window at letter dispatch or when `letter_due_date` has passed (`quote.days_to_letter_due ≥ 0`). | — |
| C-18 | Number of offers | 1 primary + at most 1 optional alternative | "Max 2" | Primary + alternative, visually distinct in the UI (the prototype shows two equal cards). | — |
| C-19 | Defer | Postpone where contact or verification is pending | "Pending for agent follow-up" | Defer needs a reason and a follow-up date; expires at the SLA cut-off → not included. | D-15 |
| C-20 | Missing input data | Input table (§5) lacks fields that rules use | Uses payment status, penalty points, household vehicles, valve certification | Fact Builder adds: payment status, household type, primary earner, dependants, vehicle count, dwelling type, ZÜRS zone, valve, bike ownership, pet age/tier, external vehicle declaration, vulnerability flag, all with provenance. | — |

## 2.3 Rule-ID mapping (old → new)

| BRD ID | Rules-doc ID | Catalog v1.0 ID | Name |
|---|---|---|---|
| BR-01 | — | W-01 | Renewal quote trigger & operational window |
| BR-07 | BR-01 | GK-01 | Advisory consent verification |
| (Account_Standing) | BR-02 | GK-02 | Account standing & arrears |
| BR-04 | BR-03 | GK-03 | Open formal complaint |
| — | BR-03 / BR-05 (property) | GK-04 | Disputed claim / litigation |
| BR-05 | — | GK-05 | Sensitive open claims journey |
| — | — | GK-06 | Vulnerability hold (new, D-10) |
| BR-02 | (Step 3) | EL-01 | Strict non-duplication |
| BR-03 | — | EL-02 | Endorsement overlap |
| BR-06 | BR-04 | EL-03 | Cooldown |
| §5 Risk Quality Gate | BR-05 (motor) | EL-05 | Risk quality gate |
| §5 Asset Verification | BR-06 | EL-04 | Target market (POG) |
| §5 Data Integrity Gate | — | EL-06 | Data integrity |
| BR-12 | Step 5 | PR-01 | Verified incremental pricing |
| BR-08 / BR-09 | Step 6 | Ranking | Single primary + alternative; bundle tie-break |
| UP-CAR-01/02 | UP-CAR-02 | UP-CAR-01 / UP-CAR-02 | Coverage upgrades |
| UP-CAR-03 | — | UP-CAR-03 | Package tier Smart → Comfort |
| UP-CAR-04 | UP-CAR-01 | UP-CAR-04 | NCD protection |
| UP-CAR-05 | UP-CAR-03 | UP-CAR-05 | Roadside assistance |
| UP-CAR-06 | — | UP-CAR-06 | Driver personal injury |
| UP-HOM-01 | UP-HOM-01 | UP-HOM-01 | Natural hazards (building) |
| UP-HOM-02 | — | UP-HOM-02 | Building tier upgrade |
| UP-HOM-03 | — | UP-HOM-03 | Natural hazards (contents) |
| UP-HOM-04 | — | UP-HOM-04 | Bicycle & e-bike |
| — | UP-HOM-02 | UP-HOM-05 | Valuables extension (DRAFT) |
| — | UP-PET-01 | UP-PET-01 | Comprehensive vet health |
| CS-CAR-02, CS-HOM-01 | CS-CAR-01 | CS-LIA-01 | Personal liability |
| CS-CAR-03 | — | CS-PET-01 | Dog owner liability |
| (§3.4 product) | — | CS-PET-02 | Horse owner liability |
| CS-CAR-01 (tenant), CS-LIA-01 | CS-HOM-01 | CS-HOM-01 | Home contents |
| CS-CAR-01 (owner) | — | CS-HOM-02 | Residential building |
| CS-HOM-02 | CS-PET-01 | CS-CAR-01 | Car (declared external vehicle) |
| — | CS-CAR-02 | CS-ACC-01 | Personal accident (extension) |
| — | CS-LIA-01 | CS-PET-03 | Pet health & surgery |

## 2.4 Reconciled opportunity catalog (v1.0.0-draft)

**Opportunity rules** (pass all candidate filters → priced → ranked):

| Rule | Type | Product | Tier | Qualifies when | Status / decision |
|---|---|---|---|---|---|
| UP-CAR-01 | Upsell | Full Comprehensive (Vollkasko) | P2 | coverage_level ∈ {TPL, PARTIAL} AND market_value ≥ 8,000 AND age_years ≤ 8 AND claims_12m = 0 AND claims_36m ≤ 1 [group CAR_COVERAGE] | ACTIVE |
| UP-CAR-02 | Upsell | Partial Comprehensive (Teilkasko) | P2 | coverage_level = TPL AND market_value ≥ 4,000 AND age_years ≤ 12 [group CAR_COVERAGE] | ACTIVE · D-06 |
| UP-CAR-03 | Upsell | Car Comfort Package | P3 | coverage_level = FULL AND tier = SMART AND age_years ≤ 3 | ACTIVE |
| UP-CAR-04 | Upsell | No-Claims Discount Protection | P3 | coverage_level = FULL AND bonus_tier ≥ 8 AND at_fault_36m ≤ 0 | ACTIVE · D-04 |
| UP-CAR-05 | Upsell | Roadside Assistance & Breakdown Mobility | P3 | annual_km ≥ 12,000 AND household_vehicle_count ≤ 1 | ACTIVE · D-07 |
| UP-CAR-06 | Upsell | Driver Personal Injury Cover | P2 | primary_earner AND has_dependants [group DRIVER_PERSONAL_INJURY] | ACTIVE |
| UP-HOM-01 | Upsell | Extended Natural Hazards / Flood Cover (Building) | P2 | zuers_zone ≤ 3 AND (zuers_zone < 2 OR backwater_valve_certified) AND NOT open_water_claim_24m; zone > 3 → referral | ACTIVE · D-08 |
| UP-HOM-02 | Upsell | Building Comfort Package | P3 | tier = SMART AND (building_age_years ≥ 20 OR has_solar_or_heatpump) | ACTIVE |
| UP-HOM-03 | Upsell | Natural Hazards Cover for Contents | P3 | basement_or_ground_floor_storage | ACTIVE |
| UP-HOM-04 | Upsell | Comprehensive Bicycle & E-Bike Cover | P3 | high_value_bike_owner | ACTIVE |
| UP-HOM-05 | Upsell | High-Value Valuables Extension | P3 | floor_area_sqm ≥ 120 | DRAFT · D-12 |
| UP-PET-01 | Upsell | Comprehensive Veterinary Health Rider | P3 | cover_tier = SURGERY AND age_years ≤ 7 AND pet_claims_24m ≤ 1 | ACTIVE |
| CS-LIA-01 | Cross-Sell | Personal Liability Insurance | P1 | household_type ∈ {SINGLE, COUPLE, FAMILY, SINGLE_PARENT} | ACTIVE · D-13 |
| CS-PET-01 | Cross-Sell | Dog Owner Liability Insurance | P1 | dog_owner | ACTIVE |
| CS-PET-02 | Cross-Sell | Horse Owner Liability Insurance | P1 | horse_owner | ACTIVE |
| CS-HOM-01 | Cross-Sell | Home Contents Insurance | P2 | occupancy ∈ {OWNER_OCCUPIER, TENANT, LANDLORD} | ACTIVE · D-13 |
| CS-HOM-02 | Cross-Sell | Residential Building Insurance | P2 | occupancy ∈ {OWNER_OCCUPIER, TENANT, LANDLORD} | ACTIVE |
| CS-CAR-01 | Cross-Sell | Car Insurance | P2 | declared_external_vehicle AND declaration_age_months ≤ 24 | ACTIVE · D-14 |
| CS-ACC-01 | Cross-Sell | Personal Accident Insurance | P2 | annual_km ≥ 15,000 AND primary_earner [group DRIVER_PERSONAL_INJURY] | ACTIVE · D-01 |
| CS-PET-03 | Cross-Sell | Pet Health & Surgery Cover | P3 | (dog_owner OR cat_owner) | ACTIVE |

**Gatekeepers** (any fires → whole case suppressed; missing fact → suppressed):

| Rule | Name | Suppress when | Reason code |
|---|---|---|---|
| GK-01 | Advisory consent verification | advisory_renewal ≠ GRANTED | CONSENT_NOT_GRANTED |
| GK-02 | Account standing & arrears | payment_status ≠ CURRENT | ACCOUNT_NOT_IN_GOOD_STANDING |
| GK-03 | Open formal complaint | open_complaint | GRIEVANCE_ACTIVE |
| GK-04 | Disputed claim or litigation within lookback | (disputed_claim_in_lookback OR open_litigation) | DISPUTE_ACTIVE |
| GK-05 | Sensitive open claims journey | open_claim_in_settlement | CLAIM_IN_SETTLEMENT |
| GK-06 | Customer vulnerability hold | vulnerability_hold | VULNERABILITY_HOLD |

"Not already held", endorsement overlap, cooldown, data integrity, risk gate, target market and verified price are checked for **every** rule by filters EL-01 to EL-06 and PR-01, so they do not appear in the qualification column. Upsell rules apply only to the LOB of the renewing policy.

Full logic (JsonLogic conditions, parameters, target markets, bundle table): `rules/rule_catalog.v1.0.json`.

## 2.5 Golden test results on the reference evaluator

All 31 tests pass (`python -I rules/reference_evaluator/run_golden.py`). Outcomes for the prototype personas:

| Persona | Prototype showed | Reconciled engine result | Why it differs |
|---|---|---|---|
| David Miller (Car, Full Comprehensive) | NCD + Personal Accident | **Primary** Personal Accident (P2), **Alt** NCD (P3). Bundle saving **€25.37** (prototype €25.38), net **€482.03**. | Priority ranking; arithmetic corrected. Seed data adds his PL policy so NCD (BRD Scenario 1) is still surfaced, as the alternative. It becomes primary if PA is ruled out of scope (D-01). |
| Sarah Jenkins (Car, tenant) | Personal Liability | **Primary** PL (P1) €57.00, saving €28.60, net €543.40; **Alt** Home Contents (P2). Building → `TARGET_MARKET_MISMATCH`. | Alternative added under BR-08. |
| Robert Taylor (Building, owner) | Flood (as "upsell") + Contents (as "upsell") | **Primary** Home Contents (cross-sell, saving **€38.00**, net **€722.00**), **Alt** Flood (+€85.20, net €695.20). | Contents is a cross-sell, not an upsell; P2 tie broken by bundle saving (BR-09); saving corrected from €37.75. |
| Mark Stevens (Car TPL) | Suppressed | **Suppressed**: GK-03 grievance, GK-04 dispute, GK-05 open claim (all recorded). | Fuller audit trail. |
| Elena Rostova (Pet) | Car cross-sell | **Primary** Personal Liability (P1 gap found), **Alt** Car (10% bundle, €70.80, net €637.20). Building → `DATA_INTEGRITY_FAIL` (dwelling type unknown); Dog liability → `COVERED_BY_ENDORSEMENT`. | The rules find a gap the prototype missed; the data-integrity gate is visible. |

> **Demo moment:** the Elena case shows the value of rules plus explanation. The engine finds a gap the BA prototype missed, explains why Building insurance was *not* offered (missing data, prompting the officer to confirm the dwelling type), and the copilot can run "what if she lives in a detached house?" live.

## 2.6 Prototype findings to fix in the build

| ID | Finding | Fix |
|---|---|---|
| P-01 | Robert's Home Contents is labelled "Upsell — Premium Tier Upgrade" | `opportunity_type` comes from the rule (`CROSS_SELL`), never from copy. |
| P-02 | Arithmetic errors: David saving 25.38 (correct 25.37) and net 482.02 (482.03); Robert saving 37.75 (38.00) with the code comment `// 5% of (610+85.20+150)`; Robert net 722.45 does not even match the prototype's own formula (610 + 150 − 37.75 = 722.25; correct 722.00). The Rules doc repeats 37.75 and 25.38. | Single Pricing module, Decimal, ROUND_HALF_UP; DB CHECK `net_consistency`; golden price assertions. |
| P-03 | Unsupported copy: "18–24% increase", "statistically more exposed", "€420,000+ property", "river-adjacent areas", "100% all-risks", "guaranteed lump sum", "exclusive" | Fact-pack-only generation + number-provenance + approved-claims + prohibited-phrase validators. |
| P-04 | "Household profiling records" Elena's external car | State the source: "you told us on 2 June 2026 that…" (customer-declared fact with date). |
| P-05 | No Defer action; no explicit opt-in; no Art. 21 objection notice; no IPID link | Added to workflow and letter template (§5). |
| P-06 | No visible "why" behind a card beyond hard-coded text | Evidence panel from `rule_evaluation.clauses`, plus the copilot. |
| P-07 | DOB/age shown prominently though no rule uses it | Hidden by default (data minimisation); shown only where a rule needs it (e.g. pet age). |
| P-08 | Two equally weighted cards | Primary vs Alternative styling; alternative collapsed by default. |
| P-09 | Skip reasons differ: the BRD has two different 3-item lists (BR-11: Budget / Covered Externally / Inappropriate Timing; §7.1: Budget / Already Covered Elsewhere / Customer Ineligible) and the prototype has 4; none link to cooldown | `ref.skip_reason` with `creates_cooldown` and `triggers_data_fix`. |
| P-10 | Branding "XYZ Company"; file name references a real insurer while content is German | Neutral demo brand unless the client approves its branding; all data synthetic. |

## 2.7 Open decisions for BA / Compliance

| ID | Question | Proposed default (used in v1.0) | Owner |
|---|---|---|---|
| D-01 | Is Personal Accident in POC scope? | Yes, as an extension product for the demo; off by default for the pilot | Product / BA |
| D-02 | Does any open claim suppress, or only disputed/sensitive ones? | Any claim in settlement suppresses | Compliance |
| D-03 | Cooldown durations | 6 months rider/tier, 12 months companion | BA |
| D-04 | NCD thresholds | Bonus tier ≥8, 0 at-fault in 36 months | Underwriting |
| D-05 | Risk-gate threshold and scope; drop penalty points? | >1 at-fault in 24 months blocks motor upgrades only; no penalty points | Underwriting / Compliance |
| D-06 | Partial comprehensive thresholds | ≥ €4,000 value, ≤ 12 years | Underwriting |
| D-07 | Roadside thresholds | ≥12,000 km and ≤1 household vehicle | BA |
| D-08 | Flood eligibility zones, valve requirement, zone 4 handling | ZÜRS 1–3; valve from zone 2; zone 4 referral | Underwriting |
| D-09 | Priority tier per rule and tie-break order | As in §2.4; bundle saving, then sequence | BA |
| D-10 | Add a vulnerability hold gatekeeper? | Yes (flag only, no reason stored) | Compliance |
| D-11 | Bundle discount model and interaction with existing discounts | Per-companion %, basis renewal + companion, not stacked | Pricing |
| D-12 | Valuables extension: which declared-valuables fact? | Rule stays DRAFT | BA |
| D-13 | Gap-based cross-sell from any renewing LOB (vs BRD source-LOB pairs) | Gap-based | BA |
| D-14 | Lawful basis and recency for customer-declared external vehicle data | Declared ≤ 24 months ago (`external_vehicle_max_declaration_age_months`), with source recorded | DPO |
| D-15 | Deferred at letter cut-off | Expires → not included, logged | BA |
| D-16 | Consent model: explicit advisory consent (BRD) vs existing-customer exception (UWG §7(3)) / postal advertising | Keep the stricter BRD model; legal to confirm per channel | Legal |
| D-17 | Letter language and officer UI language | Letter DE (EN on request); UI DE/EN toggle | Business |
