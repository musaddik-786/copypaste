# 1. Solution Architecture

## 1.1 Architecture principles

| # | Principle | What it means in practice |
|---|---|---|
| AP-1 | **Rules decide, AI explains, humans approve** | No model output can change eligibility, suppression, price, ranking or what is dispatched. |
| AP-2 | **Fail closed** | Missing or unverified data, a missing gatekeeper fact or a missing verified price means *no recommendation*. Staying silent is always compliant. |
| AP-3 | **Reproducible by construction** | Immutable snapshot + versioned ruleset + pure engine = the same answer on replay, years later. |
| AP-4 | **Business-owned logic** | Thresholds and rules are data, changed through maker-checker with golden-test and backtest gates. |
| AP-5 | **Data minimisation to AI** | Models receive a pseudonymised fact pack and never the customer record. |
| AP-6 | **EU residency for real data** | Personal data stays within the EU data boundary, including model inference. |
| AP-7 | **Modular monolith first** | One deployable with strict module boundaries. Split into services only when scale or ownership requires it. |
| AP-8 | **Integration by contract** | PAS, CRM, Claims and Output Management sit behind adapters with versioned contracts. The POC uses mocks behind the same interfaces. |

## 1.2 Where the rules end and the AI begins

| Responsibility | Owner component | Technology | AI involved? |
|---|---|---|---|
| Trigger on renewal quote, operational window (BR-01) | Ingestion + Case Workflow | Service Bus consumer, state machine | No |
| Build verified facts from PAS/CRM/Claims, data quality flags | Fact Builder | Python, contract-tested adapters | No |
| Gatekeeper suppression (consent, arrears, complaint, dispute, open claim, vulnerability) | Decision Service | Rule catalog (JsonLogic) | No |
| Duplicate / endorsement / cooldown / data integrity / risk gate / target market | Decision Service | Rule catalog | No |
| Opportunity qualification (upsell & cross-sell matrices) | Decision Service | Rule catalog | No |
| Prices, bundle savings, net totals (BR-12) | Pricing module | PAS rating API + Decimal arithmetic | No |
| Ranking and selection (BR-08/BR-09) | Decision Service | Deterministic sort | No (ML propensity is roadmap, and only *within* the eligible set) |
| Officer card text, customer letter rationale (DE/EN) | Narrative Service | LLM + deterministic validators + template fallback | **Yes**, constrained |
| Q&A, what-if, policy-wording look-up for the officer | Officer Copilot | Agent with read-only tools | **Yes**, read-only |
| Include / Skip / Defer, letter approval | Renewal Officer | Console | Human |
| Letter layout and BR-13 demarcation | Letter Composer | Versioned templates | No (AI text is inserted only into the rationale slot) |

**The contract between the two halves is the decision record** (`decision_run` + `rule_evaluation` + `pricing_scenario`). The AI layer reads it and can never write to it.

## 1.3 Logical architecture

![Solution architecture](diagrams/01_solution_architecture.png)

| Module | Responsibilities | Key interfaces |
|---|---|---|
| **Ingestion & Fact Builder** | Consume `RenewalQuoteCreated` idempotently; pull the snapshot from PAS/CRM/Claims; derive facts (vehicle age, at-fault counts in 24/36 months, cooldown ledger, portfolio holdings, embedded covers); record per-fact provenance and quality (`OK/MISSING/UNVERIFIED/STALE`). | Service Bus, PAS/CRM/Claims adapters, `sra.policy_snapshot`, `sra.snapshot_fact` |
| **Decision Service** (`packages/sra_rules`) | Pure function `evaluate(context, ruleset, as_of)`: window, gatekeepers, ordered filters, qualification, ranking. Full clause-level trace. Sandbox mode for what-if. | In-process call; `sra.decision_run`, `sra.rule_evaluation` |
| **Pricing** (`packages/sra_pricing`) | Fetch verified rating quotes; compute increments, bundle saving and net totals for each inclusion combination (primary, alternative, both). | PAS Rating API; `sra.pricing_scenario` |
| **Case & Workflow** | Case state machine, queue and KPIs, officer actions with reasons, undo via reversal, deferral SLA, cooldown ledger, letter composition, approval, dispatch, outcome tracking. | REST via APIM; `sra.*`; Output Management |
| **Narrative Service** | Build the fact pack; call the model through the AI Gateway; run validators; retry once; fall back to an approved template; cache by fact-pack hash; store versions and officer edits. | Foundry deployments; `sra.narrative*`, `sra.llm_call` |
| **Officer Copilot** | Case-scoped agent session; read-only tools (trace, rule explanation, sandbox what-if, AVB/IPID search, call-note draft); citations; transcript logging. | Microsoft Agent Framework (Python); AI Search; `sra.copilot_*` |
| **Rule Registry / Admin** | Versioned rulesets, parameters, change requests (four-eyes), golden test runs, backtest impact report, publish. | `rules.*` |
| **Audit** | Hash-chained, append-only ledger written in the same transaction as each state change; export to Sentinel / Log Analytics. | `audit.audit_event` |

## 1.4 Decision pipeline

![Decision pipeline](diagrams/02_decision_pipeline.png)

Why the filters run in this order:

- **Cheap and definitive checks first.** Duplicates, embedded covers and cooldowns need no other facts.
- **Data integrity before qualification**, so a missing fact cannot read as "not triggered". It is reported as `DATA_INTEGRITY_FAIL` and shown to the officer as a data-quality action.
- **Risk gate before qualification**, so the officer sees *why* (e.g. "2 at-fault claims") rather than a generic non-match.
- **Target market after qualification.** Opportunity rules describe the *need*; the product's target market (owned by Product Oversight & Governance) describes *who the product is for*. The building cross-sell rule deliberately qualifies any occupancy, so for a tenant it is the target-market check that stops it (BAC-08). This shows the product-governance check working as a safety net even when a need rule is written broadly.
- **Verified price last**, because BR-12 forbids showing an offer without a verified price.

Gatekeepers are **all evaluated** even after the first one fires, so the audit trail shows every reason (Mark Stevens: GK-03, GK-04 and GK-05).

## 1.5 End-to-end flow

1. **PAS** emits `RenewalQuoteCreated` (a thin CloudEvent with IDs only; see `contracts/events`).
2. **Ingestion** pulls the snapshot, stores it immutably with a SHA-256 hash, derives facts, and creates the case (`RECEIVED`).
3. **Decision Service** evaluates against the *published* ruleset and stores `decision_run` and `rule_evaluation`. **Pricing** stores `pricing_scenario` rows. The case becomes `EVALUATED`, then `SUPPRESSED`, `READY_FOR_REVIEW`, or straight to `LETTER_DRAFTED` (standard notice).
4. **Narrative Service** pre-generates officer and letter narratives asynchronously, so the overlay opens instantly.
5. The **officer** opens the case and clicks **Generate Possible Opportunities** (BAC-02). The API checks whether source data changed since the snapshot (for example, a complaint filed yesterday). If it did, it re-pulls and re-evaluates, which takes milliseconds. Otherwise it returns the stored decision.
6. The officer reviews the **primary** and the optional **alternative** card, opens the copilot if needed, and chooses Include / Skip (mandatory reason) / Defer (reason + follow-up date) for each.
7. The **Letter Composer** builds the letter: core renewal terms and premium change, then a visibly separate *optional* advisory block with rationale, itemised pricing and bundle saving, an explicit opt-in instruction (never pre-ticked), the Art. 21 GDPR objection notice, and the IPID for cross-sells.
8. The officer **approves**. The PDF is frozen to immutable Blob storage with a content hash, then **dispatched** to Output Management. This closes the operational window (later evaluations return `NOT_TRIGGERED`).
9. The customer's **active opt-in** (portal or CSR) or decline is captured. Declines and qualifying skip reasons write the **cooldown ledger**. Outcomes feed the rule-effectiveness view.

## 1.6 Case lifecycle

![Case state machine](diagrams/03_case_state_machine.png)

- Concurrency: `row_version` optimistic locking (two officers on one case).
- **Deferral SLA:** recommendations still `DEFERRED` at `letter_due_date − 1 working day` are marked `EXPIRED`, the letter is drafted without them, and the event is logged (D-15).
- **Re-quote:** a new `quote_version` from PAS supersedes open recommendations (`SUPERSEDED`) and re-evaluates.

## 1.7 Deployment view (Azure)

| Concern | Choice (POC → pilot) |
|---|---|
| Region | Germany West Central (primary). Model deployments in EU Data Zone (Germany West Central / Sweden Central). |
| Compute | Azure Container Apps: `sra-api` (FastAPI), `sra-worker` (Service Bus consumer, narrative jobs), `sra-console` (static SPA via Static Web Apps or Container App + CDN). |
| Data | Azure Database for PostgreSQL Flexible Server (zone-redundant HA in the pilot, PITR 35 days, CMK via Key Vault); Blob Storage with immutability policy for letters; Azure AI Search for AVB/IPID/approved copy. |
| Messaging | Azure Service Bus (topic `renewal-quote-created`, DLQ, duplicate detection). |
| Gateway | Azure API Management: REST facade + AI Gateway policies (model routing by data class, token limits, semantic cache off for PII, logging). |
| AI | Microsoft Foundry: Azure OpenAI GPT (Data Zone Standard, EU) as default; Claude deployment for synthetic-data demos; Azure AI Content Safety (prompt shields, groundedness); Foundry evaluations and tracing. |
| Identity | Entra ID; app roles `RENEWAL_OFFICER`, `SUPERVISOR`, `RULE_AUTHOR`, `RULE_APPROVER`, `COMPLIANCE_REVIEWER`, `AUDITOR`; managed identities between services; no secrets in code. |
| Network (pilot) | Private endpoints for PG, Blob, Search, Service Bus, Foundry; Container Apps in a VNet; APIM internal with Front Door / WAF. |
| Observability | OpenTelemetry → Application Insights; Foundry tracing for LLM/agent spans; Log Analytics + Sentinel for audit export; Purview for data classification. |
| IaC / CD | Bicep + `azd`; GitHub Actions (or Azure DevOps) with environments dev → test → demo; golden tests and eval gates in the pipeline. |

## 1.8 Non-functional requirements

| NFR | POC / demo target | Pilot target |
|---|---|---|
| Decision latency (evaluate + price) | p95 < 300 ms | p95 < 300 ms |
| Overlay open (narratives pre-generated) | < 1 s | < 1 s |
| Narrative generation (async) | < 10 s per recommendation | < 8 s, cached |
| Copilot first token | < 3 s | < 2 s |
| Volume | 5–50 demo cases | ~10k renewals/day peak; rule engine scales linearly, LLM load ≈ 2 narratives × 2 languages per eligible case |
| Availability | Best effort | 99.5% business hours; renewal letters never blocked: if SRA is down, the standard notice flows |
| Reproducibility | Replay of any decision returns identical `output_sha256` | Same, verified nightly on a sample |
| Audit retention | Demo: 30 days | Per client DPO (advice records typically kept for limitation periods; see §5) |
| Accessibility | WCAG 2.1 AA for the console | Same; assess the German Accessibility Strengthening Act (BFSG) for customer-portal touchpoints |

**Graceful degradation:** if the model or gateway is unavailable, cards show approved template text marked "standard wording". If the Decision Service fails, the case falls back to the standard renewal notice. Revenue is lost; compliance is not.
