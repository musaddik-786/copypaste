import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
fig, ax = plt.subplots(figsize=(16, 10.5)); ax.set_xlim(0, 160); ax.set_ylim(-3, 105); ax.axis("off")
F = "DejaVu Sans"
def box(x, y, w, h, t, fc="#F4F6F9", ec="#5B6B7F", fs=9.5, lw=1.1, ls="-", bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.2", fc=fc, ec=ec, lw=lw, ls=ls))
    ax.text(x + w/2, y + h/2, t, ha="center", va="center", fontsize=fs, family=F, weight="bold" if bold else "normal", color="#1F2933")
def zone(x, y, w, h, t, ec, fc="none", ls="-"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=2", fc=fc, ec=ec, lw=1.3, ls=ls))
    ax.text(x + 1.2, y + h - 1.8, t, ha="left", va="top", fontsize=10, family=F, color=ec, weight="bold")
def arr(x1, y1, x2, y2, t="", c="#6B7785", ls="-", lw=1.2, off=(0, 0)):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=11, color=c, lw=lw, ls=ls))
    if t: ax.text((x1+x2)/2 + off[0], (y1+y2)/2 + off[1], t, fontsize=8, family=F, color="#33475B", ha="center", va="center",
                  bbox=dict(fc="white", ec="none", pad=0.6))
# users + gateway
zone(2, 90, 156, 13, "Users  (Entra ID SSO, role-based access)", "#9AA5B1", ls="--")
box(10, 92, 34, 7, "Renewal Officer Console\n(React SPA)", "#FFFDE7")
box(62, 92, 34, 7, "Rule Admin UI\n(BA author / Compliance approver)", "#FFFDE7")
box(114, 92, 34, 7, "Supervisor / Auditor views\n(KPIs, audit trail)", "#FFFDE7")
box(10, 80, 138, 6, "Azure API Management  -  REST gateway  +  AI Gateway (model routing, PII policy, token quotas, prompt/response logging)", "#FFF4E0", bold=True)
# app zone
zone(2, 33, 156, 44, "Smart Renewal Advisor  -  modular monolith on Azure Container Apps  (Germany West Central)", "#0F6CBD", fc="#FBFCFE")
zone(5, 36, 86, 34, "DETERMINISTIC CORE  -  decides  (no LLM in this path)", "#2E7D4F", fc="#F1FAF3")
box(8, 54, 18, 9, "Ingestion &\nFact Builder\n(PAS/CRM/claims\nadapters)", fs=8.5)
box(30, 54, 18, 9, "Decision Service\n(rules engine)", "#DFF3E4", "#2E7D4F", lw=1.8, bold=True)
box(52, 54, 17, 9, "Pricing &\nBundle Calc", "#DFF3E4", "#2E7D4F", lw=1.8)
box(72, 54, 17, 9, "Case &\nWorkflow (HITL)")
box(30, 39, 18, 9, "Rule Registry\n(maker-checker,\nversioned)")
box(52, 39, 37, 9, "Audit Ledger (append-only, hash-chained)\n+ Letter Composer (BR-13 demarcation)")
zone(95, 36, 60, 34, "AI LAYER  -  explains & assists  (never decides)", "#5E35B1", fc="#F7F3FC")
box(99, 54, 25, 9, "Narrative Service\nfact pack > LLM >\nvalidators > fallback", "#EDE7F6", "#5E35B1", lw=1.8, fs=8.5)
box(127, 54, 25, 9, "Officer Copilot\n(agent, read-only,\ncase-scoped tools)", "#EDE7F6", "#5E35B1", lw=1.8)
box(99, 39, 53, 9, "Guardrails: pseudonymisation | number provenance |\napproved-claims check | prohibited-phrase lexicon |\nContent Safety | eval harness", "#FFFFFF", "#5E35B1", fs=8.5)
# data
zone(2, 17, 98, 13, "Data & platform services", "#9AA5B1")
box(21, 19, 20, 7, "PostgreSQL Flexible\nsnapshots, decisions,\nrules, audit", "#E3F2FD", fs=8.5)
box(44, 19, 17, 7, "Blob (immutable)\nletters & evidence", "#E3F2FD", fs=8.5)
box(64, 19, 19, 7, "AI Search\nAVB / IPID /\napproved copy", "#E3F2FD", fs=8.5)
box(5, 19, 13, 7, "Service Bus\nevents", "#FFF4E0", fs=8.5)
box(86, 19, 12, 7, "Key Vault\nApp Insights\nSentinel", "#F1F1F1", fs=8.5)
zone(104, 17, 54, 13, "Microsoft Foundry  -  model deployments", "#5E35B1")
box(107, 19, 23, 7, "Azure OpenAI GPT\nData Zone EU\n(real data)", "#EDE7F6", fs=8.5)
box(133, 19, 23, 7, "Claude on Foundry\n(synthetic demo\ndata only *)", "#F7F3FC", ls="--", fs=8.5)
# enterprise
zone(2, 1, 156, 13, "Enterprise systems of record  (POC: mocked adapters)", "#9AA5B1", ls="--")
box(8, 3, 30, 7, "Policy Admin System\n+ Rating API", "#E8EEF7")
box(46, 3, 30, 7, "CRM: consent, complaints,\ndeclared facts", "#E8EEF7")
box(84, 3, 30, 7, "Claims system", "#E8EEF7")
box(122, 3, 30, 7, "Output Management / Portal\n(receives approved letters\nfrom Case & Workflow)", "#E8EEF7", fs=8.5)
# arrows
for x in (27, 79, 131): arr(x, 92, x, 86.3)
arr(80, 80, 80, 63.5, "case APIs", off=(5, 0)); arr(139, 80, 139, 63.5, "chat (SSE)", off=(5, 0)); arr(39, 80, 39, 63.5, "", ls="--")
arr(26.3, 58.5, 29.7, 58.5, c="#2E7D4F", lw=1.6); arr(48.3, 58.5, 51.7, 58.5, c="#2E7D4F", lw=1.6); arr(69.3, 58.5, 71.7, 58.5, c="#2E7D4F", lw=1.6)
arr(39, 48.3, 39, 53.7, "publish vN", ls="--", off=(5.5, 0))
arr(89.3, 60, 98.7, 60, "fact pack", off=(0, 1.6))
arr(126.7, 56, 89.5, 56.5, "", ls="--"); ax.text(108, 52.3, "what-if: sandbox call to Decision Service", fontsize=7.5, family=F, color="#5E35B1", ha="center")
arr(80, 53.7, 75, 48.3)
arr(118, 38.6, 118, 26.4, "AI Gateway", off=(0, 0)); arr(144, 38.6, 144, 26.4, "", ls="--")
arr(11, 10.3, 11, 18.7, "RenewalQuoteCreated", off=(9, 0)); arr(11, 26.4, 11, 53.6, "", )
arr(80, 53.7, 85, 48.3)
ax.text(156, -2.2, "* Claude on Foundry currently offers no EU data zone (Oct 2026). Re-assess when available.", fontsize=7.5, family=F, ha="right", color="#5E35B1")
plt.savefig("01_solution_architecture.png", dpi=170, bbox_inches="tight", facecolor="white")
