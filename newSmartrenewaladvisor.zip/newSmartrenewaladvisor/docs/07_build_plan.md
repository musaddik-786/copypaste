# 7. Implementation Plan, AI-Assisted SDLC & Demo

## 7.1 AI SDLC: how the team builds with Claude Code

The specification is **executable**: the rule catalog, golden tests, schemas and contracts already exist. Claude Code works against them instead of interpreting prose, which is the main lever for speed and correctness.

| SDLC stage | Artefact (in this pack) | How Claude Code is used | Human gate |
|---|---|---|---|
| Requirements | BRD, Rules doc → `docs/02_rule_reconciliation.md`, open decisions | Generate test cases from new BA text (`/add-rule`); flag conflicts against the catalog | BA + Compliance sign off D-xx |
| Design | ADRs, ERD, OpenAPI, event & LLM schemas | Draft ADR updates; check that code changes respect cited ADRs | Architect approves ADR changes |
| Build | `CLAUDE.md` invariants; `claude_code_setup/` (sub-agents, command, hook) | Plan mode first; test-first; `rules-engineer` for rules; scaffold FastAPI modules, React screens from the prototype, Alembic migrations from the DDL | PR review; CODEOWNERS for `rules/`, `ai/`, letter templates |
| Verify | Golden tests, contract tests, eval suites | Hook runs golden tests after each edit; `narrative-evaluator` runs evals; `compliance-reviewer` on sensitive diffs | Eval gates + Compliance reviewer |
| Release | Bicep/azd, pipeline | Generate IaC and pipeline YAML; write release notes from commits | Change approval |
| Operate | Dashboards, rule-effectiveness view | Summarise incidents, drift and skip-reason trends | Weekly ops review |

**Setup for engineers:** copy `CLAUDE.md` to the repo root and `claude_code_setup/` to `.claude/` (agents, commands, `settings.json` hook). Never put real customer data in the repository or in prompts. Use synthetic fixtures only.

**Kick-off prompts (sprint 0):**

1. *"Read CLAUDE.md and docs/. Create the monorepo skeleton from the 'Repo layout'. Add a Makefile with dev, test, golden, contract-test and lint targets. Wire `make golden` to rules/reference_evaluator."*
2. *"Implement `packages/sra_rules` as a production version of `rules/reference_evaluator/sra_reference.py` with Pydantic models, mypy-strict types and a clause trace. Add `make contract-test` that runs every golden test through both and asserts identical outcomes and prices."*
3. *"Create the Alembic baseline from db/001_sra_schema.sql and the seed from 002. Add the Fact Builder that converts `src.*` rows into the Decision Context so that it reproduces rules/golden/personas.json for the 5 personas."*
4. *"Port smart_renewal_advisor_prototype.html to React + TypeScript (queue, policy details, overlay, letter). Keep the visual design, remove the hard-coded data, call the OpenAPI endpoints, add Defer, the evidence panel and primary/alternative styling."*

## 7.2 Team

| Role | FTE | Focus |
|---|---|---|
| Lead architect / tech lead | 1 | ADRs, decision engine, reviews, client technical Q&A |
| Backend engineers (Python) | 2 | Fact Builder, pricing, case workflow, letters, audit, APIs |
| Frontend engineer (React/TS) | 1 | Console port, copilot panel, rule admin UI |
| AI engineer | 1 | Narrative Service, validators, copilot tools, evals, Foundry/APIM |
| QA / test automation (shared with BA) | 0.5 | Golden and API suites, letter snapshot tests, demo rehearsal |
| BA + Compliance SME (client side) | 0.5 + 0.25 | Open decisions, approved benefit copy (DE/EN), letter template sign-off |
| Cloud/DevOps (shared) | 0.5 | Azure landing zone, IaC, pipeline |

## 7.3 Plan to demo (about 6 weeks)

| Week | Goals | Exit criteria |
|---|---|---|
| **0 (3 days)** | Repo, CI, Azure dev environment (Container Apps, PG, APIM, Foundry with GPT Data Zone EU deployment), Entra app roles; BA workshop on D-01..D-17 | `make golden` green in CI; decisions D-01/02/03/11/16 answered or defaults accepted |
| **1** | `sra_rules` + contract tests; `sra_pricing`; Alembic baseline; Fact Builder for 5 personas + 20 synthetic extras | 31/31 golden on the production engine; snapshot → decision persisted with trace |
| **2** | Case workflow + APIs (queue, details, evaluate, actions with reasons, reversal, defer SLA); audit ledger; console port (queue, details, overlay with evidence panel) | Click-through of the 5 personas against the live API |
| **3** | Narrative Service: fact pack, prompt v1, validators 1–7, fallback templates, DE/EN, caching; approved benefit copy loaded | `narrative_golden_v1` gates green; no unvalidated text reachable in the UI |
| **4** | Letter Composer (sections, PDF, approve/dispatch); customer-response simulation; cooldown ledger; Rule Admin MVP (parameter change → golden + backtest → four-eyes → publish) | BAC-01..11 demonstrable end to end |
| **5** | Copilot (6 tools, what-if sandbox, AVB/IPID search over sample documents, prompt shields); red-team suite; performance pass | `copilot_redteam_v1` 100% safe; p95 latencies met |
| **6** | Hardening, demo data polish, dry runs, client-specific branding (if approved), fallback video recording | Two clean rehearsals; demo checklist signed |

The plan assumes the demo uses mocked systems of record. Real PAS/CRM integration, a DPIA and the pen test belong to the pilot phase (+8–10 weeks).

## 7.4 Test strategy

| Layer | What | Tooling | Gate |
|---|---|---|---|
| Rule unit + golden | Every rule outcome, ranking, pricing | pytest, golden JSON | 100% pass; each rule has positive/negative/boundary tests |
| Contract | Production engine == reference evaluator; API == OpenAPI; events == JSON Schema | pytest, schemathesis | 100% |
| Property-based | Pricing invariants (net = base + inc + comp − saving; savings ≥ 0; rounding) | hypothesis | 100% |
| Integration | Event → snapshot → decision → narrative → letter | pytest + docker compose (Postgres, Azurite) | Green on main |
| UI | Officer journeys for the 5 personas; accessibility | Playwright, axe | Green; no critical a11y issues |
| Letter | Rendered PDF snapshots per language and scenario | Playwright PDF + image diff | Compliance approves baselines |
| AI evals | Narrative & copilot suites (§4.5) | Foundry evaluations + harness | Hard gates |
| Replay | Re-evaluate stored snapshots → identical `output_sha256` | Nightly job | 100% |
| Security | SAST, dependency scan, DAST, LLM red team | GitHub Advanced Security / Defender, custom suite | No high findings |

**Definition of Done:** tests written first; golden and contract tests green; audit events emitted; i18n keys DE/EN; ADR referenced in the PR; `compliance-reviewer` run for sensitive areas; docs updated.

## 7.5 Demo storyline (about 20 minutes)

1. **Queue:** five renewals; Mark flagged *Conduct hold*. "No sales on a customer with an open complaint, enforced by rules, not by people remembering."
2. **David:** open, generate opportunities. Primary: Personal Accident with a 5% bundle (€25.37 saving, net €482.03). Alternative: NCD (+€3.80/month). Open the **evidence panel** (bonus tier 12 ≥ 8; 0 at-fault in 36 months).
3. **Copilot:** "Why not Roadside?" → eligible but ranked third (P3, max two shown). "Why NCD and not Driver Injury?" → no dependants recorded.
4. **Sarah:** Personal Liability primary (P1). Show that **Building is blocked by target market** (tenant), Rule BAC-08. Skip the alternative with the reason "Covered externally" → cooldown recorded.
5. **Elena:** the engine finds a **P1 gap the prototype missed**; Building blocked by **missing data**; copilot what-if "detached house" → eligible, nothing changed.
6. **Letter:** German letter with a demarcated optional block, itemised prices, opt-in instruction, objection notice and IPID link; approve → PDF frozen with hash → dispatched.
7. **Rule change live:** BA raises the Personal Accident mileage threshold (`pa_min_annual_km`) from 15,000 to 20,000 km. The golden suite flags the expected changes (SCN-01, X-06, X-08) and the backtest report lists the affected cases. Compliance approves as a second user; publish v1.0.1; re-evaluate David → primary becomes NCD, alternative Roadside. No code deployed. (Verified on the reference evaluator.)
8. **Audit:** open Mark's audit trail and the hash-chain verification; show that replaying David's decision gives the identical hash.
9. **Close:** "Rules decide, AI explains, humans approve", and the path to pilot.

## 7.6 Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| BA open decisions not closed in time | Medium | Medium | Defaults are already in the catalog; decisions are parameter changes |
| Model data-residency objections from the client DPO | Medium | High | GPT Data Zone EU as default; synthetic-only Claude; documented routing |
| LLM text quality in German | Medium | Medium | DE-specific evals; approved templates as fallback; Compliance-authored benefit copy |
| Real PAS data lacks new facts (household vehicles, valve, declared external car) | High (pilot) | Medium | Data Integrity Gate keeps it safe; data-capture recommendations for CSR scripts and the portal |
| Scope creep into autonomous selling | Low | High | ADR-001; copilot read-only; demo storyline emphasises HITL |
| Branding / real-insurer naming in demo material | Medium | Medium | Neutral brand unless written approval |
| Prototype expectations (prototype outcomes differ from reconciled rules) | Medium | Low | §2.5 explains each difference; walk BA through before the demo |
