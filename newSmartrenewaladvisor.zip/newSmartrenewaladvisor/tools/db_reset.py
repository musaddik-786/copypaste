"""Recreate the SRA database objects: drop the 5 app schemas, load db/001..004, then `alembic upgrade head`.

    python tools/db_reset.py --confirm <database-name>

DESTRUCTIVE: drops schemas ref, src, rules, sra (incl. sra.alembic_version), audit. The --confirm value
must equal the name of the database DATABASE_URL points to, so a reset can never hit the wrong database by
accident. The connection string is read from the environment / repo-root .env and is never printed.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlsplit

import psycopg

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services" / "api"))
from sra_api.settings import get_settings  # noqa: E402

SCHEMAS = ("audit", "sra", "rules", "src", "ref")
SEED_FILES = ("001_sra_schema.sql", "002_reference_seed.sql", "003_src_demo_seed.sql", "004_rules_seed.sql")
# db/001 only needs pgcrypto for gen_random_uuid(), which is core PostgreSQL since v13. Azure Flexible Server
# rejects non-allow-listed extensions, so on PG >= 13 this one statement is skipped (db/001 stays unchanged).
PGCRYPTO_STMT = "CREATE EXTENSION IF NOT EXISTS pgcrypto;"


def _sql_for(conn: psycopg.Connection[tuple[object, ...]], name: str) -> str:
    sql = (ROOT / "db" / name).read_text(encoding="utf-8")
    if PGCRYPTO_STMT in sql and conn.info.server_version >= 130000:
        print(f"  note: skipping '{PGCRYPTO_STMT}' (gen_random_uuid is built in on PostgreSQL >= 13)")
        sql = sql.replace(PGCRYPTO_STMT, "-- " + PGCRYPTO_STMT + "  (skipped by tools/db_reset.py: core since PG 13)")
    return sql


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--confirm", required=True, help="name of the database to reset (must match DATABASE_URL)")
    args = ap.parse_args()

    url = get_settings().database_url.replace("postgresql+psycopg://", "postgresql://")
    if not url:
        print("DATABASE_URL is not configured")
        return 2
    target = urlsplit(url)
    dbname = target.path.lstrip("/")
    if args.confirm != dbname:
        print(f"Refusing: --confirm {args.confirm!r} does not match the configured database {dbname!r}")
        return 2

    print(f"Resetting database {dbname!r} on {target.hostname} ...")
    with psycopg.connect(url, autocommit=True) as conn:
        for s in SCHEMAS:
            conn.execute(f"DROP SCHEMA IF EXISTS {s} CASCADE")
        for name in SEED_FILES:
            conn.execute(_sql_for(conn, name).encode("utf-8"))
            print(f"  loaded db/{name}")
    rc = subprocess.call([sys.executable, "-m", "alembic", "-c", str(ROOT / "services/api/alembic.ini"),
                          "upgrade", "head"], cwd=ROOT / "services" / "api")
    if rc:
        print("alembic upgrade failed")
        return rc
    print("Database reset complete.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
