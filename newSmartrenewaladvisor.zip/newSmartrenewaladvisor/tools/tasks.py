"""Cross-platform task runner (Windows has no `make`). Same commands as the Makefile.

    python tools/tasks.py golden          # reference evaluator vs golden suite (must be 31/31+)
    python tools/tasks.py contract-test   # sra_rules vs reference evaluator on all golden tests (+ differential)
    python tools/tasks.py test            # all pytest suites
    python tools/tasks.py lint            # ruff + mypy --strict on packages/
    python tools/tasks.py gate1           # Phase 1 gate: golden + contract-test + test + lint
    python tools/tasks.py gate2           # Phase 2 gate: gate1 + API unit/integration tests + service lint
    python tools/tasks.py gate4           # Phase 3/4 gates: same suites incl. officer actions and narratives
    python tools/tasks.py live            # opt-in: real model smoke test (needs the Azure OpenAI role)
    python tools/tasks.py db-reset <db>   # DESTRUCTIVE: recreate schemas + seeds in database <db>
    python tools/tasks.py serve           # run the API locally on http://127.0.0.1:8000 (docs at /docs)

Run with the project venv interpreter (.venv/Scripts/python on Windows, .venv/bin/python elsewhere).
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable

TASKS: dict[str, list[list[str]]] = {
    "golden": [[PY, "-I", "rules/reference_evaluator/run_golden.py"]],
    "contract-test": [[PY, "-m", "pytest", "packages/sra_rules/tests/test_contract.py",
                       "packages/sra_rules/tests/test_differential.py",
                       "packages/sra_rules/tests/test_cooldown_boundary.py"]],
    "test": [[PY, "-m", "pytest"]],
    "lint": [[PY, "-m", "ruff", "check", "packages", "tests", "tools/tasks.py"], [PY, "-m", "mypy"]],
    "lint-services": [[PY, "-m", "ruff", "check", "services", "tools/db_reset.py"],
                      [PY, "-m", "mypy", "services/api/sra_api", "--ignore-missing-imports"]],
    "serve": [[PY, "-m", "uvicorn", "sra_api.main:app", "--app-dir", "services/api", "--reload"]],
}
TASKS["gate1"] = TASKS["golden"] + TASKS["contract-test"] + TASKS["test"] + TASKS["lint"]
TASKS["gate2"] = TASKS["gate1"] + TASKS["lint-services"]  # `test` already includes services/api/tests
TASKS["gate3"] = TASKS["gate2"]   # officer actions: same suites, more tests
TASKS["gate4"] = TASKS["gate2"]   # narratives (fake model); the real model: `live`
TASKS["live"] = [[PY, "-m", "pytest", "services/api/tests/live", "-m", "live", "-o", "addopts=", "-s", "-q"]]


def main(argv: list[str]) -> int:
    if len(argv) == 2 and argv[0] == "db-reset":
        return subprocess.call([PY, "tools/db_reset.py", "--confirm", argv[1]], cwd=ROOT)
    if len(argv) != 1 or argv[0] not in TASKS:
        print(__doc__)
        return 2
    for cmd in TASKS[argv[0]]:
        print(f"\n$ {' '.join(Path(c).name if c == PY else c for c in cmd)}", flush=True)
        rc = subprocess.call(cmd, cwd=ROOT)
        if rc:
            print(f"\nFAILED ({argv[0]}): exit {rc}")
            return rc
    print(f"\nOK ({argv[0]})")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
