// Builds Smart_Renewal_Advisor_Technical_Architecture_v1.0.docx from docs/*.md and docs/adr/*.md
// Usage: node tools/build_docx.js   (run from the pack root)
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType,
  ShadingType, BorderStyle, AlignmentType, ImageRun, ExternalHyperlink, TableOfContents, PageBreak,
  Header, Footer, PageNumber, LevelFormat, TabStopType,
} = require("docx");

const ROOT = path.resolve(__dirname, "..");
const DOCS = path.join(ROOT, "docs");
const OUT = path.join(ROOT, "Smart_Renewal_Advisor_Technical_Architecture_v1.0.docx");
const FONT = "Calibri", MONO = "Consolas";
const C = { primary: "0F3D6E", accent: "0F6CBD", grey: "5B6B7F", light: "EEF3F9", border: "C5CED8", callout: "F1F6FC" };
const PAGE_W = 11906, MARGIN = 1134, CONTENT_W = PAGE_W - 2 * MARGIN; // A4, 2 cm margins

// ---------------------------------------------------------------- inline markdown
function inline(text, base = {}) {
  const runs = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\)|\*[^*\s][^*]*\*)/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) runs.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...base }));
    const t = m[0];
    if (t.startsWith("**")) runs.push(...inline(t.slice(2, -2), { ...base, bold: true }));
    else if (t.startsWith("`")) runs.push(new TextRun({ text: t.slice(1, -1), font: MONO, size: (base.size || 21) - 2, color: "8A2B2B", ...(base.bold ? { bold: true } : {}) }));
    else if (t.startsWith("[")) {
      const mm = /\[([^\]]+)\]\(([^)]+)\)/.exec(t);
      if (/^https?:/.test(mm[2])) runs.push(new ExternalHyperlink({ link: mm[2], children: [new TextRun({ text: mm[1], style: "Hyperlink", font: FONT, ...base })] }));
      else runs.push(new TextRun({ text: mm[1], font: FONT, ...base }));
    } else runs.push(...inline(t.slice(1, -1), { ...base, italics: true }));
    last = m.index + t.length;
  }
  if (last < text.length) runs.push(new TextRun({ text: text.slice(last), font: FONT, ...base }));
  return runs;
}

// ---------------------------------------------------------------- tables
const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: C.border };
function splitRow(line) {
  return line.trim().replace(/^\|/, "").replace(/\|$/, "").split(/(?<!\\)\|/).map(s => s.trim().replace(/\\\|/g, "|"));
}
function plainLen(s) { return s.replace(/\*\*|`|\*/g, "").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").length; }
function buildTable(lines) {
  const rows = lines.filter((l, i) => i !== 1).map(splitRow);
  const n = rows[0].length;
  const size = n >= 6 ? 15 : n >= 4 ? 16 : 17;
  // column widths proportional to sqrt of max content length, with floor
  const maxLen = Array.from({ length: n }, (_, j) => Math.max(...rows.map(r => plainLen(r[j] || ""))));
  const weights = maxLen.map(l => Math.max(Math.sqrt(Math.min(l, 400)), 3.2));
  const minW = rows[0].map(hd => Math.max(...hd.split(/\s+/).map(w => plainLen(w))) * (size * 5.2) + 200); // longest header word fits
  const total = weights.reduce((a, b) => a + b, 0);
  let widths = weights.map((w, j) => Math.max(Math.floor((w / total) * CONTENT_W), minW[j]));
  const over = widths.reduce((a, b) => a + b, 0) - CONTENT_W;
  if (over > 0) { const flex = widths.map((w, j) => w - minW[j]); const fsum = flex.reduce((a, b) => a + b, 0) || 1;
    widths = widths.map((w, j) => Math.floor(w - over * flex[j] / fsum)); }
  widths[widths.length - 1] += CONTENT_W - widths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, i) => new TableRow({
      tableHeader: i === 0,
      cantSplit: true,
      children: Array.from({ length: n }, (_, j) => new TableCell({
        width: { size: widths[j], type: WidthType.DXA },
        borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
        shading: i === 0 ? { type: ShadingType.CLEAR, fill: C.primary, color: "auto" } : (i % 2 === 0 ? { type: ShadingType.CLEAR, fill: "F7F9FC", color: "auto" } : undefined),
        margins: { top: 50, bottom: 50, left: 80, right: 80 },
        children: [new Paragraph({ spacing: { before: 0, after: 0, line: 252 },
          children: inline(r[j] || "", i === 0 ? { bold: true, color: "FFFFFF", size } : { size }) })],
      })),
    })),
  });
}

// ---------------------------------------------------------------- images
function pngSize(buf) { return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) }; }
function image(rel, baseDir) {
  const p = path.resolve(baseDir, rel);
  const buf = fs.readFileSync(p);
  const { w, h } = pngSize(buf);
  const maxW = 640, maxH = 820;           // px at 96 dpi  (~6.65in x 8.5in)
  let width = maxW, height = Math.round(h * maxW / w);
  if (height > maxH) { height = maxH; width = Math.round(w * maxH / h); }
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 120 },
    children: [new ImageRun({ type: "png", data: buf, transformation: { width, height } })] });
}

// ---------------------------------------------------------------- block parser
function mdToBlocks(md, baseDir, opts = {}) {
  const shift = opts.shift || 0;
  const out = [];
  const lines = md.replace(/\r/g, "").split("\n");
  let i = 0;
  const H = [HeadingLevel.HEADING_1, HeadingLevel.HEADING_2, HeadingLevel.HEADING_3, HeadingLevel.HEADING_4];
  while (i < lines.length) {
    let line = lines[i];
    if (/^\s*$/.test(line) || /^<!--/.test(line)) { i++; continue; }
    let m;
    if ((m = /^(#{1,4})\s+(.*)$/.exec(line))) {
      const lvl = Math.min(m[1].length - 1 + shift, 3);
      out.push(new Paragraph({ heading: H[lvl], children: inline(m[2]) , ...(lvl === 0 && opts.pageBreakH1 !== false && out.length ? { pageBreakBefore: true } : {}) }));
      i++; continue;
    }
    if (/^```/.test(line)) {
      const buf = []; i++;
      while (i < lines.length && !/^```/.test(lines[i])) buf.push(lines[i++]);
      i++;
      out.push(...buf.map((t, k) => new Paragraph({
        spacing: { before: k === 0 ? 80 : 0, after: k === buf.length - 1 ? 120 : 0, line: 240 },
        shading: { type: ShadingType.CLEAR, fill: "F3F4F6", color: "auto" },
        indent: { left: 120, right: 120 },
        children: [new TextRun({ text: t.length ? t : " ", font: MONO, size: 15, color: "1F2933" })],
      })));
      continue;
    }
    if (/^\|/.test(line)) {
      const buf = [];
      while (i < lines.length && /^\|/.test(lines[i])) buf.push(lines[i++]);
      out.push(buildTable(buf));
      out.push(new Paragraph({ spacing: { before: 0, after: 80 }, children: [] }));
      continue;
    }
    if ((m = /^!\[([^\]]*)\]\(([^)]+)\)/.exec(line))) {
      out.push(image(m[2], baseDir));
      if (m[1]) out.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 },
        children: [new TextRun({ text: "Figure: " + m[1], italics: true, size: 17, color: C.grey, font: FONT })] }));
      i++; continue;
    }
    if (/^>\s?/.test(line)) {
      const buf = [];
      while (i < lines.length && /^>/.test(lines[i])) buf.push(lines[i++].replace(/^>\s?/, ""));
      const paras = buf.join("\n").split(/\n\s*\n/);
      paras.forEach(p => out.push(new Paragraph({
        spacing: { before: 60, after: 60 }, indent: { left: 240, right: 120 },
        shading: { type: ShadingType.CLEAR, fill: C.callout, color: "auto" },
        border: { left: { style: BorderStyle.SINGLE, size: 18, color: C.accent, space: 8 } },
        children: inline(p.replace(/\n/g, " "), { size: 20 }),
      })));
      continue;
    }
    if (/^\s*[-*]\s+/.test(line)) {
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
        const lvl = /^\s{2,}/.test(lines[i]) ? 1 : 0;
        let text = lines[i].replace(/^\s*[-*]\s+/, ""); i++;
        while (i < lines.length && /^\s{2,}\S/.test(lines[i]) && !/^\s*[-*]\s+/.test(lines[i])) text += " " + lines[i++].trim();
        out.push(new Paragraph({ numbering: { reference: "bullets", level: lvl }, spacing: { after: 40 }, children: inline(text) }));
      }
      continue;
    }
    if (/^\s*\d+\.\s+/.test(line)) {
      const ref = "num" + (numCounter++);
      numRefs.push(ref);
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) {
        let text = lines[i].replace(/^\s*\d+\.\s+/, ""); i++;
        while (i < lines.length && /^\s{2,}\S/.test(lines[i])) text += " " + lines[i++].trim();
        out.push(new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 40 }, children: inline(text) }));
      }
      continue;
    }
    // paragraph (merge consecutive lines)
    const buf = [line]; i++;
    while (i < lines.length && lines[i].trim() && !/^(#|```|\||!\[|>|\s*[-*]\s|\s*\d+\.\s)/.test(lines[i])) buf.push(lines[i++]);
    out.push(new Paragraph({ spacing: { after: 100 }, children: inline(buf.join(" ")) }));
  }
  return out;
}
let numCounter = 0; const numRefs = [];

// ---------------------------------------------------------------- assemble
const read = f => fs.readFileSync(path.join(DOCS, f), "utf8");
const children = [];

// Cover
children.push(
  new Paragraph({ spacing: { before: 2400 }, children: [new TextRun({ text: "SMART RENEWAL ADVISOR", font: FONT, size: 22, bold: true, color: C.accent, characterSpacing: 40 })] }),
  new Paragraph({ spacing: { before: 120, after: 120 }, children: [new TextRun({ text: "Technical Architecture & Implementation Blueprint", font: FONT, size: 52, bold: true, color: C.primary })] }),
  new Paragraph({ spacing: { after: 600 }, children: [new TextRun({ text: "Pre-renewal upsell & cross-sell decision support for personal lines P&C (Germany / EU)", font: FONT, size: 26, color: C.grey })] }),
  new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: C.accent, space: 4 } }, children: [] }),
);
const meta = [["Version", "1.0 (Draft for review)"], ["Date", "14 October 2026"], ["Prepared by", "Principal AI Architect, Insurance Practice"],
  ["Inputs", "BRD v1.0 (Business Baseline); Smart Renewal Advisor Rules; HTML prototype"],
  ["Platform", "Microsoft Azure (Germany West Central) · Microsoft Foundry"], ["Classification", "Confidential: client and project team"]];
children.push(new Table({ width: { size: 7000, type: WidthType.DXA }, columnWidths: [1800, 5200],
  rows: meta.map(([k, v]) => new TableRow({ children: [
    new TableCell({ width: { size: 1800, type: WidthType.DXA }, borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } },
      children: [new Paragraph({ spacing: { before: 60, after: 60 }, children: [new TextRun({ text: k, bold: true, color: C.grey, font: FONT, size: 20 })] })] }),
    new TableCell({ width: { size: 5200, type: WidthType.DXA }, borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } },
      children: [new Paragraph({ spacing: { before: 60, after: 60 }, children: [new TextRun({ text: v, font: FONT, size: 20 })] })] }),
  ] })) }));

// Document control + TOC
children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, children: [new TextRun("Document Control")] }));
children.push(...mdToBlocks(`| Version | Date | Author | Change |
|---|---|---|---|
| 0.9 | 13 Oct 2026 | Principal AI Architect | Analysis of BA inputs, research, reconciled rule catalog, reference evaluator |
| 1.0 draft | 14 Oct 2026 | Principal AI Architect | Full architecture, ADR-001..012, schema, AI design, compliance mapping, build plan |

| Reviewer / approver | Role | Scope |
|---|---|---|
| Client CTO delegate | Approver | ADR-001, ADR-008, ADR-009 |
| Head of Compliance | Approver | §2.7 open decisions, §5 control matrix, letter template |
| DPO | Reviewer | §3.7, ADR-008, ADR-011, DPIA input |
| BA Lead | Approver | §2 rule reconciliation, golden tests |
| Engineering Lead | Reviewer | §1, §3, §6, §7 |

**How to read this document.** Executives: Executive Summary and ADR-001. BA / Compliance: §2 and §5. Engineers: §1, §3, §4, §6, §7 and the ADRs, together with the engineering pack (Appendix A). Regulatory statements are architecture guidance and must be confirmed by the client's Legal and DPO functions.`, DOCS, { pageBreakH1: false }));
children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, children: [new TextRun("Contents")] }));
children.push(new TableOfContents("Contents", { hyperlink: true, headingStyleRange: "1-2" }));

for (const f of ["00_executive_summary.md", "01_solution_architecture.md", "02_rule_reconciliation.md", "03_data_model.md",
  "04_ai_design.md", "05_compliance_controls.md", "06_integration_and_apis.md", "07_build_plan.md"]) {
  const blocks = mdToBlocks(read(f), DOCS);
  // force page break before each file's H1
  blocks[0] = new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, children: inline(read(f).split("\n")[0].replace(/^#\s+/, "")) });
  children.push(...blocks);
}

// ADRs
children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, children: [new TextRun("8. Architecture Decision Records")] }));
const adrFiles = fs.readdirSync(path.join(DOCS, "adr")).filter(f => f.endsWith(".md")).sort();
const idx = ["| ADR | Decision | Status |", "|---|---|---|"];
for (const f of adrFiles) {
  const first = fs.readFileSync(path.join(DOCS, "adr", f), "utf8").split("\n")[0].replace(/^#\s+/, "");
  const [id, ...rest] = first.split(":");
  idx.push(`| ${id} | ${rest.join(":").trim()} | Proposed |`);
}
children.push(...mdToBlocks(idx.join("\n"), DOCS, { pageBreakH1: false }));
for (const f of adrFiles) {
  children.push(...mdToBlocks(fs.readFileSync(path.join(DOCS, "adr", f), "utf8"), path.join(DOCS, "adr"), { shift: 1, pageBreakH1: false }));
}
// Appendix
const app = mdToBlocks(read("09_appendix.md"), DOCS);
app[0] = new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, children: [new TextRun("Appendix")] });
children.push(...app);

const doc = new Document({
  features: { updateFields: true },
  creator: "Principal AI Architect", title: "Smart Renewal Advisor - Technical Architecture v1.0",
  description: "Technical architecture, ADRs, data schema and implementation plan",
  styles: {
    default: { document: { run: { font: FONT, size: 21 }, paragraph: { spacing: { line: 276 } } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 34, bold: true, color: C.primary, font: FONT }, paragraph: { spacing: { before: 240, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 27, bold: true, color: C.accent, font: FONT }, paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1, keepNext: true } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 23, bold: true, color: C.primary, font: FONT }, paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2, keepNext: true } },
      { id: "Heading4", name: "Heading 4", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 21, bold: true, italics: true, color: C.grey, font: FONT }, paragraph: { spacing: { before: 160, after: 60 }, outlineLevel: 3, keepNext: true } },
    ],
  },
  numbering: { config: [
    { reference: "bullets", levels: [
      { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 400, hanging: 260 } } } },
      { level: 1, format: LevelFormat.BULLET, text: "–", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 800, hanging: 260 } } } } ] },
    ...numRefs.map(r => ({ reference: r, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 400, hanging: 300 } } } }] })),
  ] },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: 16838 }, margin: { top: 1134, bottom: 1134, left: MARGIN, right: MARGIN } }, titlePage: true },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
      border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: C.border, space: 4 } },
      children: [new TextRun({ text: "Smart Renewal Advisor · Technical Architecture v1.0 (Draft) · Confidential", size: 16, color: C.grey, font: FONT })] })] }),
      first: new Header({ children: [new Paragraph({ children: [] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: ["Page ", PageNumber.CURRENT, " of ", PageNumber.TOTAL_PAGES], size: 16, color: C.grey, font: FONT })] })] }),
      first: new Footer({ children: [new Paragraph({ children: [] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUT, b); console.log("written", OUT, b.length); });
