"""Measure the evaluation latency (CLAUDE.md: steps 1-5, p95 < 300 ms) against the configured database.

    python tools/measure_latency.py [repetitions]

Each evaluation runs in its own transaction that is ROLLED BACK, so the database is left unchanged.
Reports the pure engine time (decide) separately from the end-to-end time (incl. database round trips).
"""
from __future__ import annotations

import statistics
import sys
import time
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services" / "api"))

from sqlalchemy.orm import Session  # noqa: E402

from sra_api.audit.ledger import Actor  # noqa: E402
from sra_api.cases.evaluate import evaluate_quote  # noqa: E402
from sra_api.db import get_engine  # noqa: E402

QUOTES = ["QUO-2026-88129", "QUO-2026-91402", "QUO-2026-72810", "QUO-2026-44019", "QUO-2026-61849"]
AS_OF = date(2026, 10, 13)


def p95(xs: list[float]) -> float:
    return statistics.quantiles(xs, n=20)[-1] if len(xs) >= 2 else xs[0]


def main() -> int:
    reps = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    engine = get_engine()
    end_to_end: list[float] = []
    engine_ms: list[int] = []
    for _ in range(reps):
        for q in QUOTES:
            with engine.connect() as conn:
                tx = conn.begin()
                session = Session(bind=conn, join_transaction_mode="create_savepoint")
                t0 = time.perf_counter()
                out = evaluate_quote(session, q, Actor("OFFICER", "latency.probe"), as_of=AS_OF, jurisdiction="DE")
                session.flush()
                end_to_end.append((time.perf_counter() - t0) * 1000)
                from sqlalchemy import text
                engine_ms.append(session.execute(text("SELECT duration_ms FROM sra.decision_run "
                                                      "WHERE decision_run_id = :r"),
                                                 {"r": out.decision_run_id}).scalar_one())
                session.close()
                tx.rollback()
    print(f"evaluations: {len(end_to_end)}")
    print(f"engine (rules + pricing, pure): max {max(engine_ms)} ms")
    print(f"end-to-end steps 1-5 incl. DB:  median {statistics.median(end_to_end):.0f} ms, "
          f"p95 {p95(end_to_end):.0f} ms, max {max(end_to_end):.0f} ms")
    return 0


if __name__ == "__main__":
    sys.exit(main())
