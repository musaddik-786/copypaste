"""Generate db/003_src_demo_seed.sql and db/004_rules_seed.sql.

    python -I tools/generate_seeds.py

* src  : raw mock PAS/CRM/Claims rows for the 5 demo personas (synthetic data only).
* rules: the catalog loaded as a PUBLISHED ruleset (+ rule, parameter, golden_test rows).
The script also derives Decision Context facts from the src rows (a minimal reference
Fact Builder) and asserts they equal rules/golden/personas.json, so the raw demo data,
the golden tests and the rule catalog can never drift apart.
"""
import hashlib
import json
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AS_OF = date(2026, 10, 13)
CATALOG = json.loads((ROOT / "rules/rule_catalog.v1.0.json").read_text(encoding="utf-8"))
PERSONAS = json.loads((ROOT / "rules/golden/personas.json").read_text(encoding="utf-8"))
TESTS = json.loads((ROOT / "rules/golden/golden_tests.json").read_text(encoding="utf-8"))

# ----------------------------------------------------------------------------- synthetic source data
CUSTOMERS = [
    # id, name, dob, street, postcode, city, region, lang, channel, occupancy, dwelling, household, earner, dependants, vehicles, payment, vuln, persona
    ("CUST-90124", "David Miller",  "1979-03-15", "14 Elm Street",       "80331", "Munich",    "DE-BY", "en", "POST",   "TENANT",         "APARTMENT", "COUPLE", True,  False, 1,    "CURRENT", False, "DAVID_MILLER"),
    ("CUST-38192", "Sarah Jenkins", "1988-07-22", "82 Park Lane",        "20095", "Hamburg",   "DE-HH", "en", "PORTAL", "TENANT",         "APARTMENT", "SINGLE", True,  False, 1,    "CURRENT", False, "SARAH_JENKINS"),
    ("CUST-55102", "Robert Taylor", "1971-11-03", "9 Riverbank Road",    "50667", "Cologne",   "DE-NW", "en", "POST",   "OWNER_OCCUPIER", "DETACHED",  "COUPLE", True,  False, None, "CURRENT", False, "ROBERT_TAYLOR"),
    ("CUST-22941", "Mark Stevens",  "1984-06-09", "44 Industrial Way",   "60311", "Frankfurt", "DE-HE", "en", "POST",   "TENANT",         "APARTMENT", "SINGLE", True,  False, 1,    "CURRENT", False, "MARK_STEVENS"),
    ("CUST-77310", "Elena Rostova", "1985-09-18", "29 Blumenstrasse",    "70173", "Stuttgart", "DE-BW", "en", "PORTAL", "OWNER_OCCUPIER", None,        "COUPLE", None,  None,  1,    "CURRENT", False, "ELENA_ROSTOVA"),
]
# declared facts: (customer, key, value, source, verified, declared_at)
DECLARED = []
for cid, *_rest in CUSTOMERS:
    p = PERSONAS[_rest[-1]]["customer"]
    for k in ("dog_owner", "cat_owner", "horse_owner", "high_value_bike_owner"):
        DECLARED.append((cid, k, p[k], "APPLICATION", True, "2025-01-15"))
DECLARED.append(("CUST-77310", "external_vehicle", {"declared": True, "vehicle": "2023 BMW X3", "cover": "TPL"}, "CSR_CALL", True, "2026-06-02"))
for cid in ("CUST-90124", "CUST-38192", "CUST-55102", "CUST-22941"):
    DECLARED.append((cid, "external_vehicle", {"declared": False}, "APPLICATION", True, "2025-01-15"))

POLICIES = [
    # policy, customer, lob, base product, coverage, tier, inception, expiry, premium, tax
    ("POL-CAR-440192", "CUST-90124", "CAR",           "CAR_POLICY",         "FULL", "COMFORT", "2025-11-26", "2026-11-25", "420.00", "67.06"),
    ("POL-HOM-10294",  "CUST-90124", "HOME_CONTENTS", "HOME_CONTENTS",      None,   "COMFORT", "2025-03-01", "2027-02-28", "96.00",  "15.33"),
    ("POL-LIA-31877",  "CUST-90124", "LIABILITY",     "LIAB_PRIVATE",       None,   "COMFORT", "2024-07-01", "2027-06-30", "57.00",  "9.10"),
    ("POL-CAR-771204", "CUST-38192", "CAR",           "CAR_POLICY",         "FULL", "COMFORT", "2025-11-21", "2026-11-20", "490.00", "78.24"),
    ("POL-HOM-883109", "CUST-55102", "HOME_BUILDING", "HOME_BUILDING",      None,   "COMFORT", "2025-12-06", "2026-12-05", "580.00", "92.61"),
    ("POL-LIA-20914",  "CUST-55102", "LIABILITY",     "LIAB_PRIVATE",       None,   "COMFORT", "2023-04-01", "2027-03-31", "62.00",  "9.90"),
    ("POL-CAR-118420", "CUST-22941", "CAR",           "CAR_POLICY",         "TPL",  "SMART",   "2025-11-16", "2026-11-15", "310.00", "49.50"),
    ("POL-PET-559201", "CUST-77310", "PET_HEALTH",    "PET_HEALTH_SURGERY", None,   "COMFORT", "2025-12-11", "2026-12-10", "185.00", "29.54"),
]
MODULES = [
    ("POL-CAR-440192", "CAR_COV_FULL"), ("POL-CAR-440192", "CAR_TIER_COMFORT"), ("POL-CAR-440192", "CAR_GLASS"),
    ("POL-CAR-771204", "CAR_COV_FULL"), ("POL-CAR-771204", "CAR_TIER_COMFORT"), ("POL-CAR-771204", "CAR_ROADSIDE"),
    ("POL-HOM-883109", "HOME_BLD_TIER_COMFORT"),
    ("POL-PET-559201", "PET_HEALTH_COMPREHENSIVE"),
]
VEHICLES = [  # policy, make_model, build_year, value, km, km_verified, bonus_tier, plate
    ("POL-CAR-440192", "VW Golf",    2021, "18500.00", 15000, True, 12, "M-DM 1234"),
    ("POL-CAR-771204", "Audi A3",    2022, "24000.00", 12000, True, 8,  "HH-SJ 5678"),
    ("POL-CAR-118420", "Ford Focus", 2017, "7500.00",  18000, True, 2,  "F-MS 9012"),
]
PROPERTIES = [  # policy, dwelling, build_year, area, zuers, heavy_rain, valve, solar, basement
    ("POL-HOM-10294",  "APARTMENT", 2015, 78,  1, 1, False, False, False),
    ("POL-HOM-883109", "DETACHED",  2012, 160, 2, 2, True,  False, True),
]
ANIMALS = [("POL-PET-559201", "MAX", "DOG", "Golden Retriever", 2023)]
CLAIMS = [  # id, policy, customer, loss, reported, peril, at_fault, severity, status, status_changed
    ("CLM-2025-00311", "POL-CAR-118420", "CUST-22941", "2025-03-14", "2025-03-15", "COLLISION", True, "MAJOR", "CLOSED",   "2025-05-20"),
    ("CLM-2025-01877", "POL-CAR-118420", "CUST-22941", "2025-11-02", "2025-11-03", "COLLISION", True, "MAJOR", "DISPUTED", "2026-10-03"),
]
COMPLAINTS = [("CMP-2026-00412", "CUST-22941", "2026-10-03", "OPEN", None)]
EMBEDDING = [  # mirrors ref.product_embedding in db/002 (parent, parent_tier or None, embedded)
    ("CAR_COV_FULL", None, "CAR_COV_PARTIAL"), ("PET_HEALTH_COMPREHENSIVE", None, "PET_HEALTH_SURGERY"),
    ("HOME_CONTENTS", "PREMIUM", "HOME_CNT_BICYCLE"), ("HOME_CONTENTS", "PREMIUM", "HOME_CNT_NATHAZ"),
    ("PET_HEALTH_SURGERY", "COMFORT", "LIAB_DOG")]
QUOTE_DATES = {  # quote -> renewal_date
    "QUO-2026-88129": "2026-11-26", "QUO-2026-91402": "2026-11-21", "QUO-2026-72810": "2026-12-06",
    "QUO-2026-44019": "2026-11-16", "QUO-2026-61849": "2026-12-11"}


# ----------------------------------------------------------------------------- SQL helpers
def q(v):
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def j(v):
    return "$j$" + json.dumps(v, ensure_ascii=False) + "$j$::jsonb"


# ----------------------------------------------------------------------------- src seed
def build_src():
    L = ["-- Generated by tools/generate_seeds.py - SYNTHETIC demo data for the src (mock PAS/CRM/Claims) schema.",
         "-- Never load real customer data into src. Requires 001 + 002.", "BEGIN;", ""]
    for c in CUSTOMERS:
        cid, name, dob, street, pc, city, reg, lang, ch, occ, dw, hh, earn, dep, veh, pay, vuln, _ = c
        L.append("INSERT INTO src.customer (customer_id, full_name, date_of_birth, street_address, postal_code, city, region_code, "
                 "preferred_language, preferred_channel, occupancy, dwelling_type, household_type, primary_earner, has_dependants, "
                 f"household_vehicle_count, payment_status, vulnerability_hold) VALUES ({q(cid)}, {q(name)}, {q(dob)}, {q(street)}, {q(pc)}, "
                 f"{q(city)}, {q(reg)}, {q(lang)}, {q(ch)}, {q(occ)}, {q(dw)}, {q(hh)}, {q(earn)}, {q(dep)}, {q(veh)}, {q(pay)}, {q(vuln)});")
    L.append("")
    for cid, k, v, src, ver, at in DECLARED:
        L.append(f"INSERT INTO src.customer_declared_fact VALUES ({q(cid)}, {q(k)}, {j(v)}, {q(src)}, {q(ver)}, {q(at)});")
    L.append("")
    for c in CUSTOMERS:
        L.append(f"INSERT INTO src.consent VALUES ({q(c[0])}, 'ADVISORY_RENEWAL', 'GRANTED', 'POST', '2025-01-15T10:00:00Z', {q('CONSENT-EVID-' + c[0])});")
    L.append("")
    for p in POLICIES:
        pid, cid, lob, base, cov, tier, inc, exp, prem, tax = p
        L.append("INSERT INTO src.policy (policy_id, customer_id, lob_code, base_product_code, coverage_level, package_tier, status, "
                 f"inception_date, expiry_date, annual_premium_gross, insurance_tax) VALUES ({q(pid)}, {q(cid)}, {q(lob)}, {q(base)}, "
                 f"{q(cov)}, {q(tier)}, 'ACTIVE', {q(inc)}, {q(exp)}, {prem}, {tax});")
    for pid, pc in MODULES:
        inc = next(p[6] for p in POLICIES if p[0] == pid)
        L.append(f"INSERT INTO src.policy_module VALUES ({q(pid)}, {q(pc)}, {q(inc)});")
    L.append("")
    for v in VEHICLES:
        pid, mm, by, val, km, kmv, bt, plate = v
        L.append("INSERT INTO src.insured_vehicle (policy_id, make_model, build_year, market_value, market_value_as_of, annual_km, "
                 f"annual_km_verified, bonus_tier, registration_plate) VALUES ({q(pid)}, {q(mm)}, {by}, {val}, '2026-10-01', {km}, {q(kmv)}, {bt}, {q(plate)});")
    for pr in PROPERTIES:
        pid, dw, by, area, z, hr, valve, solar, base = pr
        L.append("INSERT INTO src.insured_property (policy_id, dwelling_type, build_year, floor_area_sqm, zuers_zone, heavy_rain_class, "
                 f"backwater_valve_certified, has_solar_or_heatpump, basement_or_ground_floor_storage) VALUES ({q(pid)}, {q(dw)}, {by}, {area}, "
                 f"{z}, {hr}, {q(valve)}, {q(solar)}, {q(base)});")
    for a in ANIMALS:
        L.append(f"INSERT INTO src.insured_animal VALUES ({', '.join(q(x) for x in a)});")
    L.append("")
    for c in CLAIMS:
        L.append("INSERT INTO src.claim (claim_id, policy_id, customer_id, loss_date, reported_date, peril, at_fault, severity, status, "
                 f"status_changed_at) VALUES ({', '.join(q(x) for x in c)});")
    for c in COMPLAINTS:
        L.append(f"INSERT INTO src.complaint VALUES ({', '.join(q(x) for x in c)});")
    L.append("")
    for key, pe in PERSONAS.items():
        if key.startswith("_"):
            continue
        qt, pol = pe["quote"], pe["policy"]
        L.append("INSERT INTO src.renewal_quote (quote_id, policy_id, created_at, status, renewal_date, letter_due_date, "
                 f"expiring_premium_gross, renewal_premium_gross) VALUES ({q(qt['quote_id'])}, {q(qt['policy_id'])}, '{qt['created_at']}T06:00:00Z', "
                 f"'QUOTED', {q(QUOTE_DATES[qt['quote_id']])}, {q(qt['letter_due'])}, {pol['expiring_premium']:.2f}, {pol['renewal_premium']:.2f});")
        for i, (pc, rq) in enumerate(sorted(pe["pas_quotes"].items()), 1):
            L.append("INSERT INTO src.rating_quote (rating_quote_id, quote_id, product_code, variant, annual_gross, valid_until, rated_at) "
                     f"VALUES ({q(qt['quote_id'] + '-R' + str(i))}, {q(qt['quote_id'])}, {q(pc)}, 'STANDARD', {rq['annual_gross']:.2f}, "
                     f"{q(qt['letter_due'])}, '{qt['created_at']}T06:05:00Z');")
    L += ["", "COMMIT;", ""]
    return "\n".join(L)


# ----------------------------------------------------------------------------- rules seed
def build_rules():
    version = CATALOG["version"]
    cat_txt = json.dumps(CATALOG, ensure_ascii=False, sort_keys=True)
    sha = hashlib.sha256(cat_txt.encode()).hexdigest()
    L = ["-- Generated by tools/generate_seeds.py - loads rules/rule_catalog.v1.0.json as the PUBLISHED demo ruleset.",
         "-- Four-eyes: created_by (BA) <> approved_by (Compliance). Requires 001 + 002.", "BEGIN;", "",
         "INSERT INTO rules.ruleset (ruleset_version, jurisdiction, status, catalog_json, catalog_sha256, effective_from, created_by, "
         "approved_by, approved_at, published_at) VALUES "
         f"({q(version)}, 'DE', 'PUBLISHED', $cat${cat_txt}$cat$::jsonb, {q(sha)}, '2026-10-13T00:00:00Z', 'ba.lead@demo.local', "
         "'compliance.lead@demo.local', '2026-10-13T09:00:00Z', '2026-10-13T09:05:00Z');", ""]

    def rule_row(rid, stage, rtype, name, product=None, lob=None, tier=None, seq=None, group=None, risk=None,
                 cond=None, req=(), status="ACTIVE", src=(), reg=(), dec=()):
        arr = lambda xs: "ARRAY[" + ", ".join(q(x) for x in xs) + "]::text[]" if xs else "'{}'::text[]"
        L.append("INSERT INTO rules.rule (ruleset_version, rule_id, stage, rule_type, name, product_code, lob_code, priority_tier, sequence, "
                 "exclusion_group, risk_class, condition_jsonlogic, required_facts, status, source_refs, regulatory_refs, open_decisions) VALUES "
                 f"({q(version)}, {q(rid)}, {q(stage)}, {q(rtype)}, {q(name)}, {q(product)}, {q(lob)}, {q(tier)}, {q(seq)}, {q(group)}, {q(risk)}, "
                 f"{j(cond) if cond is not None else 'NULL'}, {arr(req)}, {q(status)}, {arr(src)}, {arr(reg)}, {arr(dec)});")

    w = CATALOG["window_rule"]
    rule_row(w["id"], "WINDOW", None, w["name"], cond=w["when"], src=w["source_refs"])
    for g in CATALOG["gatekeepers"]:
        rule_row(g["id"], "GATEKEEPER", "SUPPRESSION", g["name"], cond=g["suppress_when"], req=g["required_facts"],
                 status=g["status"], src=g["source_refs"], reg=g.get("regulatory_refs", []), dec=g.get("open_decisions", []))
    for f in CATALOG["candidate_filters"]:
        if f["id"] == "QUAL":
            continue
        rule_row(f["id"], "FILTER", "FILTER", f["name"], cond=f.get("when_risky"), src=f.get("source_refs", []))
    for r in CATALOG["rules"]:
        rule_row(r["id"], "OPPORTUNITY", r["type"], r["name"], r["product_code"], r.get("lob") or CATALOG["products"][r["product_code"]]["lob"],
                 r["priority_tier"], r["sequence"], r.get("exclusion_group"), r.get("risk_class"), r["when"], r["required_facts"],
                 r["status"], r["source_refs"], r.get("regulatory_refs", []), r.get("open_decisions", []))
    L.append("")
    for k, p in CATALOG["parameters"].items():
        L.append(f"INSERT INTO rules.parameter (ruleset_version, param_key, value, value_type, source) VALUES "
                 f"({q(version)}, {q(k)}, {j(p['value'])}, {q(p['type'])}, {q(p.get('source'))});")
    L.append("")
    origin = lambda tid: "BRD_BAC" if tid.startswith("BAC") else "BRD_SCENARIO" if tid.startswith("SCN") else "ARCHITECT"
    for t in TESTS["tests"]:
        ov = {k: t[k] for k in ("set", "remove") if k in t}
        L.append(f"INSERT INTO rules.golden_test (test_id, title, base_fixture, overrides, expectation, origin) VALUES "
                 f"({q(t['id'])}, {q(t['title'])}, {q(t['base'])}, {j(ov)}, {j(t['expect'])}, {q(origin(t['id']))});")
    L += ["", "COMMIT;", ""]
    return "\n".join(L)


# ----------------------------------------------------------------------------- reference Fact Builder check
def months(d1, d2):
    m = (d2.year - d1.year) * 12 + (d2.month - d1.month)
    return m - 1 if d2.day < d1.day else m


def derive(customer_id):
    """Minimal Fact Builder: src rows -> Decision Context subset (what personas.json asserts)."""
    c = next(x for x in CUSTOMERS if x[0] == customer_id)
    persona = PERSONAS[c[-1]]
    pols = [p for p in POLICIES if p[1] == customer_id]
    renewing = next(p for p in pols if p[0] == persona["quote"]["policy_id"])
    active = sorted({p[3] for p in pols} | {m[1] for m in MODULES if m[0] in {p[0] for p in pols}})
    claims = [x for x in CLAIMS if x[2] == customer_id]
    def within(cl, m): return months(date.fromisoformat(cl[3]), AS_OF) < m
    ext = next((d[2] for d in DECLARED if d[0] == customer_id and d[1] == "external_vehicle"), {})
    ext_at = next((d[5] for d in DECLARED if d[0] == customer_id and d[1] == "external_vehicle"), None)
    out = {
        "customer.occupancy": c[9], "customer.dwelling_type": c[10], "customer.household_type": c[11],
        "customer.primary_earner": c[12], "customer.household_vehicle_count": c[14],
        "policy.lob": renewing[2], "policy.tier": renewing[5],
        "conduct.open_complaint": any(x[1] == customer_id and x[3] in ("OPEN", "ESCALATED") for x in COMPLAINTS),
        "conduct.open_claim_in_settlement": any(x[8] in ("OPEN", "IN_SETTLEMENT", "DISPUTED", "LITIGATION") for x in claims),
        "conduct.disputed_claim_in_lookback": any(x[8] == "DISPUTED" and (AS_OF - date.fromisoformat(x[9])).days <= 180 for x in claims),
        "claims.claims_12m": sum(within(x, 12) for x in claims), "claims.claims_36m": sum(within(x, 36) for x in claims),
        "claims.at_fault_24m": sum(within(x, 24) and x[6] for x in claims),
        "external.declared_external_vehicle": ext.get("declared", False),
        "portfolio.active_products": active,
        "portfolio.embedded_covers": sorted({e[2] for e in EMBEDDING for p in pols
                                             if (e[0] == p[3] or e[0] in {m[1] for m in MODULES if m[0] == p[0]})
                                             and (e[1] is None or e[1] == p[5])} - set(active)),
    }
    if renewing[2] == "CAR":
        v = next(x for x in VEHICLES if x[0] == renewing[0])
        out.update({"policy.coverage_level": renewing[4], "vehicle.market_value": int(float(v[3])),
                    "vehicle.age_years": AS_OF.year - v[2], "vehicle.annual_km": v[4], "motor.bonus_tier": v[6]})
    if ext.get("declared"):
        out["external.declaration_age_months"] = months(date.fromisoformat(ext_at), AS_OF)
    return persona, out


def get(d, path):
    for p in path.split("."):
        d = d.get(p) if isinstance(d, dict) else None
    return d


def verify():
    problems = []
    for c in CUSTOMERS:
        persona, facts = derive(c[0])
        for k, v in facts.items():
            exp = get(persona, k)
            if k in ("portfolio.active_products", "portfolio.embedded_covers"):
                exp = sorted(exp)
            if exp != v:
                problems.append(f"{c[-1]} {k}: src-derived {v!r} != personas.json {exp!r}")
    return problems


if __name__ == "__main__":
    probs = verify()
    if probs:
        raise SystemExit("Fact derivation mismatch:\n  " + "\n  ".join(probs))
    (ROOT / "db/003_src_demo_seed.sql").write_text(build_src(), encoding="utf-8")
    (ROOT / "db/004_rules_seed.sql").write_text(build_rules(), encoding="utf-8")
    print("src-derived facts match personas.json for all 5 personas; wrote db/003_src_demo_seed.sql and db/004_rules_seed.sql")
