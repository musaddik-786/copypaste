"""Architecture guards for the decision path (CLAUDE.md invariants 1, 2 and 4, ADR-001).

* sra_rules / sra_pricing (and services/api/decisioning once it exists) import only the standard library
  and each other - so no LLM client, HTTP client or DB driver can ever reach the decision path.
* No I/O or clock access inside the pure packages.
* No float() / float literals for money in sra_pricing.
"""
from __future__ import annotations

import ast
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
PURE_PACKAGES = [REPO / "packages" / "sra_rules" / "src", REPO / "packages" / "sra_pricing" / "src"]
DECISION_PATH = [*PURE_PACKAGES, REPO / "services" / "api" / "sra_api" / "decisioning"]
FIRST_PARTY = {"sra_rules", "sra_pricing", "sra_api"}
FORBIDDEN_PREFIXES = ("openai", "anthropic", "azure", "langchain", "semantic_kernel", "httpx", "requests",
                      "aiohttp", "urllib", "socket", "http", "psycopg", "sqlalchemy", "sra_api.narrative")
FORBIDDEN_CALLS_PURE = {"open", "input", "print", "eval", "exec"}
FORBIDDEN_ATTRS_PURE = {("date", "today"), ("datetime", "now"), ("datetime", "utcnow"), ("time", "time"),
                        ("random", "random")}


def _files(roots: list[Path]) -> list[Path]:
    return sorted(p for r in roots if r.exists() for p in r.rglob("*.py"))


def _imports(tree: ast.AST) -> list[str]:
    out: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            out += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            out.append(node.module)
    return out


@pytest.mark.parametrize("path", _files(DECISION_PATH), ids=lambda p: p.name)
def test_decision_path_has_no_llm_or_io_imports(path: Path) -> None:
    for mod in _imports(ast.parse(path.read_text(encoding="utf-8"))):
        assert not mod.startswith(FORBIDDEN_PREFIXES), f"{path}: forbidden import {mod}"


@pytest.mark.parametrize("path", _files(PURE_PACKAGES), ids=lambda p: p.name)
def test_pure_packages_import_only_stdlib(path: Path) -> None:
    for mod in _imports(ast.parse(path.read_text(encoding="utf-8"))):
        top = mod.split(".")[0]
        assert top in sys.stdlib_module_names or top in FIRST_PARTY or top == "__future__", \
            f"{path}: non-stdlib import {mod}"


@pytest.mark.parametrize("path", _files(PURE_PACKAGES), ids=lambda p: p.name)
def test_pure_packages_have_no_io_or_clock(path: Path) -> None:
    for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            assert node.func.id not in FORBIDDEN_CALLS_PURE, f"{path}:{node.lineno} calls {node.func.id}()"
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
            assert (node.value.id, node.attr) not in FORBIDDEN_ATTRS_PURE, \
                f"{path}:{node.lineno} uses {node.value.id}.{node.attr}"


LLM_SDKS = ("openai", "azure", "anthropic", "langchain", "semantic_kernel")
LLM_CLIENT_MODULE = REPO / "services" / "api" / "sra_api" / "narrative" / "clients.py"


@pytest.mark.parametrize("path", _files([REPO / "services" / "api" / "sra_api"]), ids=lambda p: p.name)
def test_llm_sdks_are_imported_only_by_the_narrative_client(path: Path) -> None:
    """One place talks to models; everything else goes through the Narrative Service and its validators."""
    if path == LLM_CLIENT_MODULE:
        return
    for mod in _imports(ast.parse(path.read_text(encoding="utf-8"))):
        assert not mod.startswith(LLM_SDKS), f"{path}: imports {mod} (only narrative/clients.py may)"


@pytest.mark.parametrize("path", _files([REPO / "packages" / "sra_pricing" / "src"]), ids=lambda p: p.name)
def test_no_float_in_pricing(path: Path) -> None:
    for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
        assert not (isinstance(node, ast.Name) and node.id == "float"), f"{path}:{node.lineno} uses float"
        assert not (isinstance(node, ast.Constant) and isinstance(node.value, float)), \
            f"{path}:{node.lineno} float literal"
