# Smart Renewal Advisor: Architecture & Engineering Pack (v1.0 draft)

> **Scope decisions of 2026-10-15** (English default, no events / Service Bus, no copilot) are recorded in `CLAUDE.md` and override the Word document and `docs/` where they differ.

| Path | What it is | Audience |
|---|---|---|
| `Smart_Renewal_Advisor_Technical_Architecture_v1.0.docx` | Complete architecture document (built from `docs/`) | Leadership, client, BA, Compliance |
| `docs/00…07_*.md` | Architecture sections (source of the Word document) | Everyone |
| `docs/adr/ADR-001…012` | Architecture Decision Records | Architects, engineers |
| `docs/diagrams/` | Diagrams (PNG + source .dot/.py) | — |
| `rules/rule_catalog.v1.0.json` | **Reconciled rule catalog** (JsonLogic, parameters, products, bundle table) | BA, engineers |
| `rules/golden/` | Personas (Decision Contexts) + 31 golden tests | QA, engineers |
| `rules/reference_evaluator/` | Executable specification of the decision engine + test runner | Engineers |
| `db/001_sra_schema.sql` | PostgreSQL 16 DDL (5 schemas) | Engineers |
| `db/002_reference_seed.sql` | `ref` seed: products, embeddings, bundle rules, reasons, regulatory refs | Engineers |
| `db/003_src_demo_seed.sql` | `src` seed: synthetic customers, policies, claims, complaints, quotes for the 5 personas | Engineers |
| `db/004_rules_seed.sql` | `rules` seed: catalog as PUBLISHED ruleset + rules, parameters, golden tests | Engineers |
| `tools/generate_seeds.py` | Regenerates 003/004 and checks src rows derive exactly the facts in personas.json | Engineers |
| `contracts/` | OpenAPI, LLM fact-pack and output schemas | Engineers |
| `ai/` | Narrative prompt, prohibited-phrase lexicon | AI engineer, Compliance |
| `CLAUDE.md` | Invariants and conventions for Claude Code | Engineers |
| `_out_of_scope/` | Parked items (PAS event schema, copilot prompt). Do not implement. | — |
| `claude_code_setup/` | Sub-agents, slash command and hook. **Copy to `.claude/` in the repo.** | Engineers |

## Quick start
```bash
python -I rules/reference_evaluator/run_golden.py              # 31/31 expected
python -I rules/reference_evaluator/run_golden.py --trace SCN-05   # full rule trace for Elena
```
