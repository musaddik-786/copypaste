# Out of scope (parked 2026-10-15)

Kept for reference only. **Do not implement anything in this folder.** See the scope decisions in `CLAUDE.md`.

| File | Why parked |
|---|---|
| `renewal_quote_created.v1.schema.json` | PAS will not emit events; evaluation is triggered on demand from the console (`POST /renewal-quotes/{quoteId}/evaluations`). No Azure Service Bus. |
| `copilot_system.v1.md` | The officer copilot is not required for the POC. |
