# CLAUDE.md — Smart Renewal Advisor (SRA)

Read this before every task. It holds the non-negotiable rules for this repository. Architecture: `docs/` (start with `docs/01_solution_architecture.md`), decisions: `docs/adr/`.

## Scope decisions (2026-10-15) — these OVERRIDE anything in `docs/`, ADRs or the Word document
1. **English is the default everywhere.** UI, API `lang` defaults, narratives, customer letters, seed data and test fixtures default to `en`. German (`de`) stays a supported option, not the default.
2. **No events, no Azure Service Bus.** PAS does not emit `RenewalQuoteCreated`. Evaluation is **on demand**: the Renewal Officer clicks **Generate Possible Opportunities** and the console calls `POST /renewal-quotes/{quoteId}/evaluations`. That call creates the case (if new), pulls the snapshot from the PAS/CRM/Claims adapters (the `src` mock schema in the POC), evaluates, prices and returns the recommendations. Do not add Service Bus, message consumers, workers for ingestion, event schemas or "pre-compute on event" logic.
3. **No copilot.** Do not implement the officer copilot, its tools, what-if/sandbox runs, agent frameworks, copilot prompts, copilot evals or copilot UI. GenAI is used **only** for (a) the officer-card rationale and (b) the customer letter advisory text, behind the validators.

Material in `docs/` that mentions Service Bus, `RenewalQuoteCreated`, pre-computation on events, the copilot (ADR-007, docs §4.3), what-if/sandbox runs, or German as default is **superseded** by the three points above. If a doc and this section disagree, this section wins. Ask before building anything not covered here.

## What we are building
A decision-support tool for Renewal Officers. When the officer requests it for a renewal quote, a **deterministic rules engine** decides which upsell or cross-sell (if any) is eligible, pricing is computed deterministically, **GenAI writes the explanation and the letter advisory text**, and the **officer decides** (Include / Skip / Defer) before any letter is sent. Jurisdiction: Germany / EU, EUR. Default language: English.

## Request flow (POC)
```
Console: queue  ->  GET /renewal-quotes                (quotes in the operational window, joined with case state if any)
Console: click  ->  POST /renewal-quotes/{quoteId}/evaluations
                    1. create sra.renewal_case if it does not exist (idempotent on quote_id)
                    2. Fact Builder pulls src.* via adapter ports -> sra.policy_snapshot (+ snapshot_fact)
                    3. sra_rules.evaluate(...)            -> sra.decision_run + sra.rule_evaluation
                    4. sra_pricing                         -> sra.pricing_scenario
                    5. recommendations persisted          -> sra.recommendation
                    6. narratives generated (en) + validated, cached by fact_pack_sha256 -> sra.narrative
                    7. return cards; audit events in the same transaction
Console: actions -> POST /recommendations/{id}/actions (INCLUDE | SKIP+reason | DEFER+reason+date)
Console: letter  -> GET /cases/{caseId}/letter-draft, POST .../approve, POST /cases/{caseId}/dispatch
```
Steps 1–5 are synchronous (p95 < 300 ms). Step 6 may run in-request for the POC (≤ ~10 s with a spinner) or as a background task in the same process. No external queue.

## Invariants — never break these (CI and reviewers enforce them)
1. **No LLM in the decision path.** Code under `packages/sra_rules`, `packages/sra_pricing`, `services/api/decisioning` must never import an LLM client. The eligibility, suppression, pricing and ranking outputs never depend on model output. (ADR-001)
2. **Rules are data.** Thresholds and conditions live in the rule catalog (`rules/rule_catalog.*.json`, JsonLogic; loaded into `rules.*` tables by `db/004_rules_seed.sql`). Never hard-code a business threshold in Python/TypeScript. A new rule = catalog entry + golden test + `source_refs`. (ADR-002)
3. **Golden tests are the contract.** `rules/golden/golden_tests.json` must stay green. The production engine must produce exactly the same outcomes as `rules/reference_evaluator` for every golden test (`make contract-test`).
4. **Money:** `decimal.Decimal` in Python, string on the wire, `numeric(12,2)` in Postgres. `ROUND_HALF_UP`, 2 dp, only inside `sra_pricing`. No floats for money anywhere, including the frontend (`big.js`/`dinero.js`).
5. **Fail closed.** If a required fact is missing or unverified, the opportunity is ineligible (Data Integrity Gate). If a gatekeeper fact is missing, the case is suppressed.
6. **Immutable records.** `policy_snapshot`, `decision_run`, `rule_evaluation`, `audit_event` are insert-only. Undo = new REVERSAL row.
7. **LLM data minimisation.** Only the Fact Pack (`contracts/llm/fact_pack.v1.schema.json`) goes to a model. No names, addresses, DOB, policy/customer IDs or CRM free text. Use `{{FIRST_NAME}}` / `{{CITY}}` tokens and re-insert them server side.
8. **Model routing by data class.** Real or pseudonymised customer data goes only to deployments with `data_boundary = EU` (Azure OpenAI Data Zone EU). Claude on Foundry is allowed for `SYNTHETIC` data only until an EU data zone exists (ADR-008). Enforced in `ModelRouter`.
9. **Every generated narrative passes all validators** (`services/api/narrative/validators/`) or falls back to the approved static template. Never show unvalidated LLM text.
10. **Human in the loop.** No code path dispatches a letter with an advisory block unless an officer INCLUDED it and approved the letter. No pre-ticked opt-ins anywhere in customer-facing output.
11. **Audit everything.** Every state change writes an `audit.audit_event` (hash-chained) in the same transaction.
12. **Idempotent evaluation.** Repeated clicks on the same quote never create duplicate cases; each click that finds changed source data creates a new immutable `decision_run` and supersedes the previous open recommendations.

## Repo layout (target)
```
apps/console/              React 18 + TypeScript + Vite, MSAL, TanStack Query (port of prototype screens)
services/api/              FastAPI modular monolith: adapters/ (PAS/CRM/Claims ports, src-mock impl), factbuilder/,
                           decisioning/, pricing/, cases/, letters/, narrative/, admin/, audit/
packages/sra_rules/        pure-Python decision engine (JsonLogic + trace)  <- no I/O, no clock
packages/sra_pricing/      pure-Python pricing & bundle calculator
rules/                     rule catalog, golden tests, reference evaluator (executable spec)
db/                        001 schema, 002 ref seed, 003 src demo seed, 004 rules seed; migrations/ (Alembic, baseline = 001)
contracts/                 OpenAPI, LLM fact pack & output schemas
ai/                        narrative prompt, guardrail lexicon, narrative eval datasets
infra/                     Bicep + azd (Container Apps, PG Flexible, APIM, Key Vault, Foundry)  - no Service Bus
docs/                      architecture, ADRs, diagrams (see scope overrides above)
```

## Commands
```bash
make dev            # docker compose: postgres, api (hot reload), console
make db-reset       # recreate DB and load db/001..004 in order
make test           # pytest + vitest
make golden         # python -I rules/reference_evaluator/run_golden.py  (must be 31/31+)
make contract-test  # sra_rules vs reference evaluator on all golden tests
make seeds          # python -I tools/generate_seeds.py  (regenerates 003/004 and checks facts vs personas)
make evals          # narrative eval suite against the configured deployment (needs creds)
make lint           # ruff, mypy --strict (packages/), eslint, tsc
```

## Conventions
- Python 3.12, FastAPI, Pydantic v2, SQLAlchemy 2 (Core for reads, ORM for writes), psycopg 3.
- Business IDs keep the BA formats: `QUO-2026-88129`, `POL-CAR-440192`, `REC-2026-0041`.
- Rule IDs are namespaced (`W-`, `GK-`, `EL-`, `UP-<LOB>-`, `CS-<LOB>-`, `PR-`). Never reuse an ID; retire it instead.
- UI copy in `apps/console/src/i18n/en.json` (default) and `de.json` (optional). Customer letters default to English.
- Feature flags: `SRA_NARRATIVE_MODEL`, `SRA_ALLOW_SYNTHETIC_CLAUDE`, `SRA_LETTER_LANGUAGES` (default `en`).
- Never edit `db/003` / `db/004` by hand; change the sources and run `make seeds`.
- Commits: Conventional Commits. A PR touching `rules/` needs a Compliance reviewer (CODEOWNERS).

## How to work with Claude Code here
- For rule work use the `rules-engineer` subagent; for compliance review of any diff touching letters, narratives, prompts or rules use `compliance-reviewer`; for LLM changes run `narrative-evaluator`.
- Plan first, cite the ADR (or scope decision) you are following, write the failing test first, then code.
- Never "fix" a golden test to match new behaviour without a linked change request ID in the commit message.
