# Cedera — Engineering Decisions

These are interview stories: each entry follows the format
**symptom → measurement → change → result**.

---

## DEC-001 · Wrong turns are architectural, not financial

**Symptom**: Early planning proposed deliberately writing incorrect XoL recovery
logic (e.g., skip the exclusion check, ignore prior erosion) to create "fix it later"
stories. The test scenario where Layer 2 pays £3.2m instead of £4m was treated as
a deliberate bug to introduce rather than a correct answer to prove.

**Measurement**: GPT confirmed the CAT-2026-004 expected total is £7.1m. Any
implementation that uses `treaty_terms.layer_limit` instead of
`layer_erosion.current_limit_remaining` silently returns £7.9m — a confident wrong
answer handed to the agent, which then narrates it as fact with no error.

**Change**: Redefined "deliberate wrong turn" to mean *technical and architectural*
choices only: Chroma→pgvector, synchronous→Celery, one-agent→supervisor pattern.
Business calculations are correct from day one. The wrong answers (£7.9m, false
recovery on flooded risk) become TEST CASES that prove correctness, not TODOs to
introduce and fix.

**Result**: Recovery handler passes three golden-set scenarios on first build.
Interview story: "I had to convince the team that the wrong-turn methodology
applies to infrastructure choices, not to financial arithmetic. Getting £7.1m right
from the start and having a test that catches £7.9m is actually the more defensible
engineering position."

---

## DEC-002 · `list_exclusions` ordered by non-existent column

**Symptom**: Treaty handler's `list_exclusions` query used `ORDER BY exclusion_ref`
but the live Azure PostgreSQL table has `exclusion_id` as the primary key column.
No syntax error at import time — the failure would only surface at runtime when an
agent called the tool.

**Measurement**: `\d treaty_exclusions` in psql confirmed columns:
`exclusion_id, treaty_ref, clause_ref, exclusion_name, description`.
Column `exclusion_ref` does not exist.

**Change**: Fixed to `ORDER BY exclusion_id` in `treaty_mcp/handler.py`.

**Result**: `list_exclusions` no longer throws `column "exclusion_ref" does not exist`
at query time. FastApiMCP silently exposes the tool regardless — there would have been
no startup warning, only a 500 at agent call time.

---

## DEC-003 · `include_operations` whitelist only listed one tool

**Symptom**: `main.py` mounted the treaty sub-app with
`include_operations=["treaty_management_mcp"]`. FastApiMCP only exposes tools whose
`operation_id` appears in that list. The four other treaty endpoints
(`list_treaties`, `get_treaty_terms`, `list_exclusions`, `get_clause`) were
invisible to the agent with no error, warning, or log line.

**Measurement**: Calling `GET /api/v1/treaty/mcp` returned a tools manifest with
exactly one entry. The Treaty Agent would only be able to call `get_treaty`.

**Change**: Added all five operation_ids to the whitelist in `main.py`.

**Result**: All five treaty tools appear in the MCP manifest. This is the canonical
silent failure mode for FastApiMCP — a missing operation_id is invisible until you
inspect the manifest. Interview story: "The agent passed eval on happy-path but
couldn't list treaties or fetch clauses. No error anywhere — I had to read the MCP
spec to realise the whitelist was the gating mechanism."

---

## DEC-004 · Treaty MCP mounted at wrong path

**Symptom**: `main.py` mounted the treaty sub-app at `/api/v1/treaty_management_mcp`.
The CLAUDE.md spec defines the Recovery Agent's tool calls as targeting
`/api/v1/treaty` to call `list_exclusions` and `get_clause`.

**Measurement**: Any agent or test client hitting `/api/v1/treaty/*` got a 404.

**Change**: Mount path changed to `/api/v1/treaty` in `main.py`.

**Result**: Treaty tools reachable at the documented path.

---

## DEC-005 · Chroma relative path breaks from any non-ingestion working directory

**Symptom**: `ingestion/chroma_store.py` set `CHROMA_PATH = "./chroma_db"`.
When the module is imported from `MCP/main.py` or from a test, the relative path
resolves to the caller's working directory, not the `ingestion/` directory where the
actual database lives.

**Measurement**: Starting uvicorn from `MCP/` caused chromadb to create a fresh empty
`chroma_db/` in `MCP/` rather than reading the populated one in `ingestion/`.
Similarity searches returned zero results with no error.

**Change**: `CHROMA_PATH = Path(__file__).resolve().parent / "chroma_db"` — always
resolves relative to the file, regardless of working directory at call time.

**Result**: Chroma reads the correct database from any invocation context.
Phase 5 interview story: "Hybrid retrieval was added to fix recall, but the
underlying issue was that Phase 2 ingestion and Phase 3 retrieval were pointing at
different databases on disk. The migration to pgvector in Phase 5 eliminated this
class of problem entirely."

---

## DEC-006 · XoL recovery exclusion check must precede arithmetic

**Symptom (by design)**: A naive implementation calculates `loss_above_attachment`
first, then checks exclusions. The LLM is handed a non-zero figure for a flood event
on TRT-2026-003, which it narrates as a valid recovery. Article 4(b) excludes flood,
so the correct answer is NIL.

**Measurement**: `test_cat_2026_002_flood_excluded` catches this: if the exclusion
check runs after the arithmetic step, the returned `recoverable_amount` is non-zero.

**Change**: Enforced sequence in `recovery_mcp/handler.py`: Business Covered check →
exclusion check → layer terms → erosion lookup → arithmetic. The function returns
early at steps 2 or 3 with `recoverable_amount=0` and a `reason` field that the
agent uses to construct its narrative.

**Result**: The LLM never sees a financial figure it shouldn't narrate.
Rule encoded in `CLAUDE.md`: "The model only writes the narrative explanation of a
result it was given." This is the enforcement mechanism.

---

## DEC-007 · Prior erosion from layer_erosion, not treaty_terms

**Symptom (by design)**: `treaty_terms.layer_limit` for TRT-2026-003 Layer 2 = £4m.
CAT-2026-004 arrives after Ashley eroded £0.8m. A handler that reads
`treaty_terms.layer_limit` returns £4m available — and calculates £7.9m recovery.

**Measurement**: `layer_erosion.current_limit_remaining` = £3.2m for Layer 2 before
Cerys. The test `test_cat_2026_004_layer2_erosion` fails on any implementation that
reads `treaty_terms` instead.

**Change**: `calculate_xol_recovery` reads
```sql
SELECT current_limit_remaining FROM layer_erosion
WHERE treaty_ref = %s AND layer_number = %s AND event_date < %s
ORDER BY event_date DESC LIMIT 1
```
Falls back to `treaty_terms.layer_limit` only when no prior erosion row exists.

**Result**: CAT-2026-004 total = £7.1m. Correct.
