
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "common"))

from dotenv import load_dotenv, find_dotenv
load_dotenv(find_dotenv())

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi_mcp import FastApiMCP

from treaty_router import router as treaty_router
from recovery_router import router as recovery_router

import uvicorn


app = FastAPI(docs_url="/docs", title="Cedera")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _make_cors_app(title: str, description: str = "") -> FastAPI:
    sub = FastAPI(title=title, description=description)
    sub.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return sub


# ── Treaty MCP (port sub-app) ─────────────────────────────────────────────────
treaty_app = _make_cors_app(
    title="Treaty MCP",
    description="MCP tools for treaty management",
)
treaty_app.include_router(treaty_router)
FastApiMCP(
    treaty_app,
    include_operations=[
        "treaty_management_mcp",   # get_treaty
        "list_treaties",
        "get_treaty_terms",
        "list_exclusions",
        "get_clause",
    ],
).mount_http()
app.mount("/api/v1/treaty", treaty_app)


# ── Recovery MCP (port sub-app) ───────────────────────────────────────────────
recovery_app = _make_cors_app(
    title="Recovery MCP",
    description="MCP tools for XoL recovery calculation",
)
recovery_app.include_router(recovery_router)
FastApiMCP(
    recovery_app,
    include_operations=[
        "get_event",
        "list_applicable_treaties",
        "calculate_xol_recovery",
        "calculate_aggregate_position",
        "check_reinstatements",
    ],
).mount_http()
app.mount("/api/v1/recovery", recovery_app)


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "cedera",
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=7720)
