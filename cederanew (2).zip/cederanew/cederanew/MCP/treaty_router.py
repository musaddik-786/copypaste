import logging
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional

from treaty_mcp import handler

log = logging.getLogger(__name__)

router = APIRouter()


class TreatyManagement(BaseModel):
    """
    it accepts treaty number
    """
    treaty_ref: str


@router.post(
    "/treaty_management_mcp",
    operation_id = "treaty_management_mcp"    
)

def get_treaty(req: TreatyManagement):
    """
    returns treaty information from the database
    """
    return handler.get_treaty_info(req.treaty_ref)







class TreatyListRequest(BaseModel):
    status: str | None = None
    class_of_business: str | None = None
    as_at: str | None = None


@router.post("/list_treaties", operation_id="list_treaties")
def list_treaties(req: TreatyListRequest):
    return handler.list_treaties(
        req.status,
        req.class_of_business,
        req.as_at
    )







class TreatyTermsRequest(BaseModel):
    treaty_ref: str


@router.post("/get_treaty_terms", operation_id="get_treaty_terms")
def get_treaty_terms(req: TreatyTermsRequest):
    return handler.get_treaty_terms(req.treaty_ref)



class ListExclusionsRequest(BaseModel):
    treaty_ref: str


@router.post("/list_exclusions", operation_id="list_exclusions")
def list_exclusions(req: ListExclusionsRequest):
    return handler.list_exclusions(req.treaty_ref)
class GetClauseRequest(BaseModel):
    clause_ref: str
    treaty_ref: str


@router.post("/get_clause", operation_id="get_clause")
def get_clause(req: GetClauseRequest):
    return handler.get_clause(
        req.clause_ref,
        req.treaty_ref
    )