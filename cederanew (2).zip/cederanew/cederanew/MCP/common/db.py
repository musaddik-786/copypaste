# import os 
# import mysql.connector
# from dotenv import load_dotenv

# load_dotenv

# def get_db_connection():
#     return mysql.connector.connect(
#         host = os.getenv("DB_HOST","localhost"),
#         port = int(os.getenv("DB_PORT", "3306")),
#         user = os.getenv("DB_USER","root"),
#         password = os.getenv("DB_PASSWORD"),
#         database = os.getenv("DB_NAME","cedera"),
# )



import os
import logging

import psycopg2
import psycopg2.extras
from dotenv import load_dotenv, find_dotenv

load_dotenv(find_dotenv())

# log = logging.getLogger(__name__)

# Azure PostgreSQL connection parameters
PG_HOST = os.getenv("AZURE_PG_HOST", "localhost")
PG_PORT = int(os.getenv("AZURE_PG_PORT", "5432"))
PG_DATABASE = os.getenv("AZURE_PG_DATABASE", "policyholder_db")
PG_USER = os.getenv("AZURE_PG_USER", "postgres")
PG_PASSWORD = os.getenv("AZURE_PG_PASSWORD", "")
PG_SSLMODE = os.getenv("AZURE_PG_SSLMODE", "require")


def get_db_connection():
    """
    Returns a psycopg2 connection to Azure PostgreSQL.
    Uses RealDictCursor by default so rows are returned as dicts.
    """
    conn = psycopg2.connect(
        host=PG_HOST,
        port=PG_PORT,
        dbname=PG_DATABASE,
        user=PG_USER,
        password=PG_PASSWORD,
        sslmode=PG_SSLMODE,
        cursor_factory=psycopg2.extras.RealDictCursor,
    )
    conn.autocommit = False
    return conn