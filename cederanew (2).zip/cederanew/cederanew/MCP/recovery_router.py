import logging
from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from recovery_mcp import handler

log = logging.getLogger(__name__)

router = APIRouter()


class GetEventRequest(BaseModel):
    event_ref: str = Field(min_length=1)


@router.post("/get_event", operation_id="get_event")
def get_event(req: GetEventRequest):
    """Returns loss event details: peril, net retained loss, policy count, cat programme ref."""
    return handler.get_event(req.event_ref)


class ListApplicableTreatiesRequest(BaseModel):
    event_ref: str = Field(min_length=1)


@router.post("/list_applicable_treaties", operation_id="list_applicable_treaties")
def list_applicable_treaties(req: ListApplicableTreatiesRequest):
    """Lists XoL treaties active on the event date that may respond."""
    return handler.list_applicable_treaties(req.event_ref)


class CalculateXolRecoveryRequest(BaseModel):
    event_ref: str = Field(min_length=1)
    treaty_ref: str = Field(min_length=1)
    layer_number: int = Field(ge=1)
    as_at_date: Optional[str] = None


@router.post("/calculate_xol_recovery", operation_id="calculate_xol_recovery")
def calculate_xol_recovery(req: CalculateXolRecoveryRequest):
    """
    Deterministic XoL recovery. Checks Business Covered eligibility and
    peril exclusions BEFORE arithmetic. Returns calculation_basis JSON.
    """
    return handler.calculate_xol_recovery(
        req.event_ref,
        req.treaty_ref,
        req.layer_number,
        req.as_at_date,
    )


class CalculateAggregatePositionRequest(BaseModel):
    treaty_ref: str = Field(min_length=1)
    layer_number: int = Field(ge=1)
    as_at_date: str = Field(min_length=1)


@router.post("/calculate_aggregate_position", operation_id="calculate_aggregate_position")
def calculate_aggregate_position(req: CalculateAggregatePositionRequest):
    """Returns current available limit after prior erosion for a layer."""
    return handler.calculate_aggregate_position(
        req.treaty_ref,
        req.layer_number,
        req.as_at_date,
    )


class CheckReinstatementsRequest(BaseModel):
    treaty_ref: str = Field(min_length=1)
    layer_number: int = Field(ge=1)


@router.post("/check_reinstatements", operation_id="check_reinstatements")
def check_reinstatements(req: CheckReinstatementsRequest):
    """Returns reinstatement allowances and usage for a layer."""
    return handler.check_reinstatements(req.treaty_ref, req.layer_number)
