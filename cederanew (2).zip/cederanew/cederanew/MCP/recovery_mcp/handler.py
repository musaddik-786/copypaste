import logging
from decimal import Decimal
from typing import Optional

from common.db import get_db_connection

log = logging.getLogger(__name__)


def get_event(event_ref: str) -> dict:
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute(
            """
            SELECT
                event_ref, event_name, peril, event_date,
                total_gross_loss, total_proportional_recovery,
                total_net_retained_loss, affected_policy_count,
                cat_programme_ref, exclusion_note
            FROM loss_events
            WHERE event_ref = %s
            """,
            (event_ref,),
        )
        row = cursor.fetchone()
        if not row:
            return {"status": "not_found", "message": f"Event {event_ref} not found"}
        return {"status": "success", "data": dict(row)}
    except Exception:
        log.exception("get_event failed for %s", event_ref)
        raise
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def list_applicable_treaties(event_ref: str) -> dict:
    """Returns XoL treaties active on the event date that could respond."""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute(
            """
            SELECT t.treaty_ref, t.treaty_type, t.class_of_business,
                   t.cedent_name, t.reinsurer_name, t.currency
            FROM treaties t
            JOIN loss_events le ON le.event_ref = %s
            WHERE t.treaty_type = 'xol'
              AND t.inception_date <= le.event_date
              AND t.expiry_date >= le.event_date
              AND t.status = 'active'
            ORDER BY t.treaty_ref
            """,
            (event_ref,),
        )
        rows = cursor.fetchall()
        return {
            "status": "success",
            "event_ref": event_ref,
            "count": len(rows),
            "data": [dict(r) for r in rows],
        }
    except Exception:
        log.exception("list_applicable_treaties failed for %s", event_ref)
        raise
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def calculate_xol_recovery(
    event_ref: str,
    treaty_ref: str,
    layer_number: int,
    as_at_date: Optional[str] = None,
) -> dict:
    """
    Deterministic XoL recovery.

    Sequence enforced by CLAUDE.md:
    1. Get event (net retained loss, peril, policy count)
    2. Business Covered eligibility  — cat programme requires >=2 policies
    3. Exclusion check               — peril match against treaty_exclusions
    4. Layer terms                   — attachment, event limit
    5. Available limit               — current_limit_remaining from layer_erosion
    6. Arithmetic                    — recovery = min(loss above attachment, limit)
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        # ── Step 1: get event ────────────────────────────────────────────────
        cursor.execute(
            """
            SELECT total_net_retained_loss, peril, affected_policy_count,
                   cat_programme_ref, event_date
            FROM loss_events
            WHERE event_ref = %s
            """,
            (event_ref,),
        )
        event = cursor.fetchone()
        if not event:
            return {"status": "not_found", "message": f"Event {event_ref} not found"}

        net_retained = Decimal(str(event["total_net_retained_loss"]))
        peril = event["peril"]
        policy_count = int(event["affected_policy_count"])
        cat_programme_ref = event["cat_programme_ref"]
        event_date = event["event_date"]

        effective_as_at = as_at_date or str(event_date)

        # ── Step 2: Business Covered (cat programme only) ────────────────────
        # The condition lives in Business Covered, not in Exclusions.
        # LOSS-2026-011 is the test case: 1 policy, fire, cat programme → NIL.
        if cat_programme_ref == treaty_ref and policy_count < 2:
            return {
                "status": "success",
                "recoverable_amount": 0.0,
                "eligible": False,
                "reason": "business_covered_not_met",
                "note": (
                    f"Event {event_ref} affects {policy_count} policy. "
                    "The catastrophe programme requires at least 2 original "
                    "policies (Business Covered condition, not an Exclusion)."
                ),
                "calculation_basis": {
                    "event_ref": event_ref,
                    "treaty_ref": treaty_ref,
                    "layer_number": layer_number,
                    "check": "business_covered",
                    "affected_policy_count": policy_count,
                    "required": 2,
                    "result": "ineligible",
                },
            }

        # ── Step 3: Exclusion check ──────────────────────────────────────────
        # CAT-2026-002 flood test: Article 4(b) excludes flood from TRT-2026-003.
        # Must run BEFORE any arithmetic or the model could produce a wrong figure.
        peril_pattern = f"%{peril}%"
        cursor.execute(
            """
            SELECT exclusion_id, exclusion_name, clause_ref, description
            FROM treaty_exclusions
            WHERE treaty_ref = %s
              AND (
                exclusion_name ILIKE %s
                OR description ILIKE %s
              )
            LIMIT 1
            """,
            (treaty_ref, peril_pattern, peril_pattern),
        )
        exclusion = cursor.fetchone()
        if exclusion:
            return {
                "status": "success",
                "recoverable_amount": 0.0,
                "eligible": False,
                "reason": "peril_excluded",
                "note": (
                    f"Peril '{peril}' excluded by {exclusion['clause_ref']}: "
                    f"{exclusion['exclusion_name']}."
                ),
                "calculation_basis": {
                    "event_ref": event_ref,
                    "treaty_ref": treaty_ref,
                    "layer_number": layer_number,
                    "check": "exclusion",
                    "peril": peril,
                    "exclusion_name": exclusion["exclusion_name"],
                    "clause_ref": exclusion["clause_ref"],
                    "result": "excluded",
                },
            }

        # ── Step 4: Layer terms ──────────────────────────────────────────────
        cursor.execute(
            """
            SELECT attachment_point, layer_limit, event_limit, reinstatements
            FROM treaty_terms
            WHERE treaty_ref = %s AND layer_number = %s
            """,
            (treaty_ref, layer_number),
        )
        terms = cursor.fetchone()
        if not terms:
            return {
                "status": "not_found",
                "message": f"No terms for {treaty_ref} layer {layer_number}",
            }

        attachment = Decimal(str(terms["attachment_point"]))
        layer_limit = Decimal(str(terms["layer_limit"]))
        event_limit = Decimal(str(terms["event_limit"]))

        # ── Step 5: Available limit from layer_erosion ───────────────────────
        # Read current_limit_remaining from the most recent prior erosion row.
        # CAT-2026-004 test: Layer 2 has £0.8m eroded by Ashley → available = £3.2m.
        # Using treaty_terms.layer_limit here gives the WRONG answer of £7.9m.
        cursor.execute(
            """
            SELECT current_limit_remaining, cumulative_eroded, aggregate_remaining
            FROM layer_erosion
            WHERE treaty_ref = %s
              AND layer_number = %s
              AND event_date < %s
            ORDER BY event_date DESC
            LIMIT 1
            """,
            (treaty_ref, layer_number, effective_as_at),
        )
        erosion = cursor.fetchone()

        if erosion:
            available_limit = Decimal(str(erosion["current_limit_remaining"]))
            cumulative_eroded = Decimal(str(erosion["cumulative_eroded"]))
            aggregate_remaining = Decimal(str(erosion["aggregate_remaining"]))
        else:
            # No prior erosion — full inception limits apply
            cursor.execute(
                "SELECT aggregate_limit FROM treaty_terms WHERE treaty_ref = %s AND layer_number = %s",
                (treaty_ref, layer_number),
            )
            terms_agg = cursor.fetchone()
            available_limit = layer_limit
            cumulative_eroded = Decimal("0")
            aggregate_remaining = Decimal(str(terms_agg["aggregate_limit"])) if terms_agg else layer_limit

        # Cap by event limit AND annual aggregate remaining.
        # aggregate_remaining tracks total available across all occurrences this year.
        effective_limit = min(available_limit, event_limit, aggregate_remaining)

        # ── Step 6: Arithmetic ───────────────────────────────────────────────
        loss_above_attachment = max(Decimal("0"), net_retained - attachment)
        recoverable = min(loss_above_attachment, effective_limit)

        calculation_basis = {
            "event_ref": event_ref,
            "treaty_ref": treaty_ref,
            "layer_number": layer_number,
            "as_at_date": effective_as_at,
            "net_retained_loss": str(net_retained),
            "attachment_point": str(attachment),
            "layer_limit_at_inception": str(layer_limit),
            "cumulative_eroded_before_event": str(cumulative_eroded),
            "current_limit_remaining": str(available_limit),
            "aggregate_remaining": str(aggregate_remaining),
            "event_limit": str(event_limit),
            "effective_limit_used": str(effective_limit),
            "binding_constraint": (
                "aggregate_remaining" if aggregate_remaining < min(available_limit, event_limit)
                else "event_limit" if event_limit < available_limit
                else "current_limit_remaining"
            ),
            "loss_above_attachment": str(loss_above_attachment),
            "recoverable_amount": str(recoverable),
        }

        return {
            "status": "success",
            "eligible": True,
            "recoverable_amount": float(recoverable),
            "calculation_basis": calculation_basis,
        }

    except Exception:
        log.exception(
            "calculate_xol_recovery failed: event=%s treaty=%s layer=%s",
            event_ref,
            treaty_ref,
            layer_number,
        )
        raise
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def calculate_aggregate_position(
    treaty_ref: str,
    layer_number: int,
    as_at_date: str,
) -> dict:
    """
    Current available limit and erosion state for a layer as at a given date.
    Reads layer_erosion ordered by event_date — NOT treaty_terms.layer_limit.
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT erosion_ref, event_ref, event_date, amount_eroded,
                   cumulative_eroded, current_limit_remaining,
                   aggregate_limit, aggregate_remaining
            FROM layer_erosion
            WHERE treaty_ref = %s
              AND layer_number = %s
              AND event_date < %s
            ORDER BY event_date DESC
            LIMIT 1
            """,
            (treaty_ref, layer_number, as_at_date),
        )
        erosion = cursor.fetchone()

        if not erosion:
            # No prior erosion — fall back to inception limit from treaty_terms
            cursor.execute(
                """
                SELECT layer_limit, aggregate_limit
                FROM treaty_terms
                WHERE treaty_ref = %s AND layer_number = %s
                """,
                (treaty_ref, layer_number),
            )
            terms = cursor.fetchone()
            if not terms:
                return {
                    "status": "not_found",
                    "message": f"No terms for {treaty_ref} layer {layer_number}",
                }
            return {
                "status": "success",
                "data": {
                    "treaty_ref": treaty_ref,
                    "layer_number": layer_number,
                    "as_at_date": as_at_date,
                    "cumulative_eroded": 0.0,
                    "current_limit_remaining": float(terms["layer_limit"]),
                    "aggregate_limit": float(terms["aggregate_limit"]),
                    "aggregate_remaining": float(terms["aggregate_limit"]),
                    "prior_events": 0,
                },
            }

        return {
            "status": "success",
            "data": {
                "treaty_ref": treaty_ref,
                "layer_number": layer_number,
                "as_at_date": as_at_date,
                "cumulative_eroded": float(erosion["cumulative_eroded"]),
                "current_limit_remaining": float(erosion["current_limit_remaining"]),
                "aggregate_limit": float(erosion["aggregate_limit"]),
                "aggregate_remaining": float(erosion["aggregate_remaining"]),
                "most_recent_prior_event": erosion["event_ref"],
                "most_recent_event_date": str(erosion["event_date"]),
            },
        }

    except Exception:
        log.exception(
            "calculate_aggregate_position failed: treaty=%s layer=%s as_at=%s",
            treaty_ref,
            layer_number,
            as_at_date,
        )
        raise
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def check_reinstatements(
    treaty_ref: str,
    layer_number: int,
) -> dict:
    """Returns reinstatement status for a layer."""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute(
            """
            SELECT reinstatements_allowed, reinstatements_used,
                   aggregate_remaining, current_limit_remaining
            FROM layer_erosion
            WHERE treaty_ref = %s AND layer_number = %s
            ORDER BY event_date DESC
            LIMIT 1
            """,
            (treaty_ref, layer_number),
        )
        row = cursor.fetchone()
        if not row:
            cursor.execute(
                "SELECT reinstatements FROM treaty_terms WHERE treaty_ref = %s AND layer_number = %s",
                (treaty_ref, layer_number),
            )
            terms = cursor.fetchone()
            if not terms:
                return {"status": "not_found", "message": f"No terms for {treaty_ref} layer {layer_number}"}
            return {
                "status": "success",
                "data": {
                    "treaty_ref": treaty_ref,
                    "layer_number": layer_number,
                    "reinstatements_allowed": terms["reinstatements"],
                    "reinstatements_used": 0,
                    "reinstatements_remaining": terms["reinstatements"],
                },
            }
        remaining = row["reinstatements_allowed"] - row["reinstatements_used"]
        return {
            "status": "success",
            "data": {
                "treaty_ref": treaty_ref,
                "layer_number": layer_number,
                "reinstatements_allowed": row["reinstatements_allowed"],
                "reinstatements_used": row["reinstatements_used"],
                "reinstatements_remaining": remaining,
            },
        }
    except Exception:
        log.exception("check_reinstatements failed: treaty=%s layer=%s", treaty_ref, layer_number)
        raise
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
