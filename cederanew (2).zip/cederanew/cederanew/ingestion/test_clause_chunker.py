
# from loaders import load_pdf
# from clause_chunker import clause_aware_chunk_documents


# PDF_PATH = r"/home/JarvisClaims/Musaddique/cedera/treaty_pdfs/TRT-2026-001_Property_Quota_Share.pdf"


# documents = load_pdf(PDF_PATH)

# chunks = clause_aware_chunk_documents(documents)

# print(f"Documents: {len(documents)}")
# print(f"Clause-aware chunks: {len(chunks)}")


# for chunk in chunks:
#     print("\n" + "=" * 80)
#     print(f"Page: {chunk['page_number']}")
#     print(f"Chunk: {chunk['chunk_number']}")
#     print(f"Article: {chunk['article']}")
#     print(f"Clause: {chunk['clause_ref']}")
#     print("-" * 80)
#     print(chunk["text"][:1000])


from pathlib import Path
from ingestion.loaders import load_pdf
from ingestion.clause_chunker import chunk_documents

PDF_PATH = (
   "/home/JarvisClaims/Musaddique/cedera/treaty_pdfs/TRT-2026-005_Casualty_Risk_XoL.pdf"
)

def main():
   # ---------------------------------------------------------
   # 1. Load PDF
   # ---------------------------------------------------------
   documents = load_pdf(PDF_PATH)
   print(f"Documents / Pages: {len(documents)}")
   # ---------------------------------------------------------
   # 2. Create treaty-aware chunks
   # ---------------------------------------------------------
   chunks = chunk_documents(documents)
   print(f"Total chunks: {len(chunks)}")
   # ---------------------------------------------------------
   # 3. Display chunks
   # ---------------------------------------------------------
   for chunk in chunks:
       print("\n" + "=" * 80)
       print(f"Chunk:       {chunk['chunk_number']}")
       print(f"Page:        {chunk['page_number']}")
       print(f"Article:     {chunk['article']}")
       print(f"Clause:      {chunk['clause_ref']}")
       print("-" * 80)
       print(chunk["text"])

if __name__ == "__main__":
   main()