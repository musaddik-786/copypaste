from loaders import load_pdf


PDF_PATH = r"/home/JarvisClaims/Musaddique/cedera/treaty_pdfs/TRT-2026-001_Property_Quota_Share.pdf"


documents = load_pdf(PDF_PATH)

print(f"Pages: {len(documents)}")

for document in documents[:3]:
    print("\n" + "=" * 80)
    print(f"Page: {document['page_number']}")
    print(document["text"][:1000])