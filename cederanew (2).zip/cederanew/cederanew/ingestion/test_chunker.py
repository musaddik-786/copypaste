

from loaders import load_pdf
from chunker import chunk_documents


PDF_PATH = r"/home/JarvisClaims/Musaddique/cedera/treaty_pdfs/TRT-2026-001_Property_Quota_Share.pdf"


documents = load_pdf(PDF_PATH)

chunks = chunk_documents(documents)

print(f"Documents: {len(documents)}")
print(f"Chunks: {len(chunks)}")

for chunk in chunks[:5]:
    print("\n" + "=" * 80)
    print(f"Page: {chunk['page_number']}")
    print(f"Chunk: {chunk['chunk_number']}")
    print(chunk["text"][:500])