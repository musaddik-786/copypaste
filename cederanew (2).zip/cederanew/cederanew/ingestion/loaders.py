# from langchain_community.document_loaders import PyPDFLoader
# loader = PyPDFLoader("C:\\Users\\2000137378\\Desktop\\newproject\\RAG_PIPELINES\\quote_20260325_114738.pdf")
# document = loader.load()
# print(document)
from pathlib import Path
from pypdf import PdfReader


def load_pdf(file_path: str) -> list[dict]:
    """
    Extract text from a treaty PDF page by page.
    """

    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"PDF not found: {file_path}")

    reader = PdfReader(str(path))

    documents = []

    for page_number, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""

        documents.append({
            "source": path.name,
            "page_number": page_number,
            "text": text.strip()
        })

    return documents