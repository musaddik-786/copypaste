
import re
from pathlib import Path

from ingestion.loaders import load_pdf
from ingestion.clause_chunker import chunk_documents
from ingestion.embedder import get_embeddings
from ingestion.chroma_store import rebuild_chroma_collection


TREATY_PDF_DIR = Path("treaty_pdfs")


def extract_treaty_ref(file_path: Path) -> str:
    filename = file_path.name

    match = re.match(
        r"(TRT-\d{4}-\d{3})",
        filename
    )

    if not match:
        raise ValueError(
            f"Could not extract treaty_ref from filename: {filename}"
        )

    return match.group(1)


def ingest_treaties():
    pdf_files = sorted(TREATY_PDF_DIR.glob("*.pdf"))

    if not pdf_files:
        raise FileNotFoundError(
            f"No treaty PDFs found in {TREATY_PDF_DIR}"
        )

    collection = rebuild_chroma_collection()

    embedding_model = get_embeddings()

    total_chunks = 0

    for pdf_path in pdf_files:

        treaty_ref = extract_treaty_ref(pdf_path)

        print(f"\nProcessing: {pdf_path.name}")
        print(f"Treaty ref: {treaty_ref}")

        documents = load_pdf(str(pdf_path))

        chunks = chunk_documents(documents)

        texts = [
            chunk["text"]
            for chunk in chunks
        ]

        vectors = embedding_model.embed_documents(texts)

        ids = [
            f"{treaty_ref}_{chunk['chunk_number']}"
            for chunk in chunks
        ]

        metadatas = [
            {
                "source": chunk["source"],
                "treaty_ref": treaty_ref,
                "page_number": chunk["page_number"],
                "chunk_number": chunk["chunk_number"],
                "article": chunk["article"] or "",
                "clause_ref": chunk["clause_ref"] or "",
            }
            for chunk in chunks
        ]

        collection.upsert(
            ids=ids,
            documents=texts,
            embeddings=vectors,
            metadatas=metadatas,
        )

        total_chunks += len(chunks)

        print(f"Chunks: {len(chunks)}")

    print("\n-----------------------------")
    print("Ingestion complete")
    print(f"Treaties: {len(pdf_files)}")
    print(f"Total chunks: {total_chunks}")
    print(f"Collection count: {collection.count()}")
    print("-----------------------------")


if __name__ == "__main__":
    ingest_treaties()
