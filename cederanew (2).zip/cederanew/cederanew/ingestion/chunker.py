def chunk_documents(
    documents: list[dict],
    chunk_size: int = 1000,
    overlap: int = 200
) -> list[dict]:

    chunks = []

    for document in documents:
        text = document["text"]

        start = 0
        chunk_number = 1

        while start < len(text):

            end = start + chunk_size
            chunk_text = text[start:end]

            chunks.append({
                "source": document["source"],
                "page_number": document["page_number"],
                "chunk_number": chunk_number,
                "text": chunk_text
            })

            start += chunk_size - overlap
            chunk_number += 1

    return chunks

