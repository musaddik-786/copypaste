

from loaders import load_pdf
from chunker import chunk_documents
from embedder import get_embeddings


PDF_PATH = r"/home/JarvisClaims/Musaddique/cedera/treaty_pdfs/TRT-2026-001_Property_Quota_Share.pdf"


documents = load_pdf(PDF_PATH)

chunks = chunk_documents(documents)

embeddings = get_embeddings()

texts = [chunk["text"] for chunk in chunks]

vectors = embeddings.embed_documents(texts)

print(f"Chunks: {len(chunks)}")
print(f"Embeddings: {len(vectors)}")
print(f"Vector dimensions: {len(vectors[0])}")