# import chromadb


# CHROMA_PATH = Path(__file__).resolve().parent / "chroma_db"


# def get_chroma_collection():
#     client = chromadb.PersistentClient(path=CHROMA_PATH)

#     collection = client.get_or_create_collection(
#         name="treaty_clauses"
#     )

#     return collection



from pathlib import Path
import chromadb


# CHROMA_PATH = Path(__file__).resolve().parent / "chroma_db"
CHROMA_PATH = Path(__file__).resolve().parent / "chroma_db"
COLLECTION_NAME = "treaty_clauses"


def get_chroma_client():
    return chromadb.PersistentClient(path=str(CHROMA_PATH))


def get_chroma_collection():
    client = get_chroma_client()
    return client.get_or_create_collection(
        name=COLLECTION_NAME
    )


def rebuild_chroma_collection():
    client = get_chroma_client()

    try:
        client.delete_collection(COLLECTION_NAME)
        print(f"Deleted existing collection: {COLLECTION_NAME}")
    except Exception:
        print(f"No existing collection found: {COLLECTION_NAME}")

    collection = client.create_collection(
        name=COLLECTION_NAME
    )

    print(f"Created fresh collection: {COLLECTION_NAME}")

    return collection

