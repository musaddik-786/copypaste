# from embedder import get_embeddings
# from chroma_store import get_chroma_collection


# QUERY = "Article 4(b) flood exclusion"


# embeddings_model = get_embeddings()
# collection = get_chroma_collection()

# query_vector = embeddings_model.embed_query(QUERY)

# results = collection.query(
#     query_embeddings=[query_vector],
#     n_results=5
# )


# for i, document in enumerate(results["documents"][0]):
#     metadata = results["metadatas"][0][i]
#     distance = results["distances"][0][i]

#     print("\n" + "=" * 80)
#     print(f"Result: {i + 1}")
#     print(f"Distance: {distance}")
#     print(f"Page: {metadata['page_number']}")
#     print(f"Chunk: {metadata['chunk_number']}")
#     print(f"Treaty: {metadata['treaty_ref']}")
#     print("\n" + document)



from ingestion.embedder import get_embeddings
from ingestion.chroma_store import get_chroma_collection


def search_clause(treaty_ref: str, query: str):

    collection = get_chroma_collection()
    embedding_model = get_embeddings()

    query_vector = embedding_model.embed_query(query)

    results = collection.query(
        query_embeddings=[query_vector],
        n_results=5,
        where={
            "treaty_ref": treaty_ref
        },
    )

    print("\n====================================")
    print(f"Treaty: {treaty_ref}")
    print(f"Query: {query}")
    print("====================================")

    for i in range(len(results["documents"][0])):

        metadata = results["metadatas"][0][i]
        document = results["documents"][0][i]
        distance = results["distances"][0][i]

        print(f"\nResult {i + 1}")
        print(f"Distance: {distance}")
        print(f"Article: {metadata['article']}")
        print(f"Clause: {metadata['clause_ref']}")
        print(f"Page: {metadata['page_number']}")
        print(f"Treaty: {metadata['treaty_ref']}")
        print(f"Text:\n{document}")


if __name__ == "__main__":

    search_clause(
        "TRT-2026-001",
        "What is Article 4(b)?"
    )

    search_clause(
        "TRT-2026-003",
        "What is Article 4(b)?"
    )

    search_clause(
        "TRT-2026-003",
        "What does the hours clause say?"
    )

    search_clause(
        "TRT-2026-003",
        "How does prior erosion affect recovery?"
    )

    search_clause(
        "TRT-2026-005",
        "What does the Business Covered article say?"
    )