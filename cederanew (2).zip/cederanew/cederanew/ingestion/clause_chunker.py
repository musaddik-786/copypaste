# # import re


# # ARTICLE_PATTERN = re.compile(
# #     r"^\s*ARTICLE\s+(\d+[A-Z]?)\s*(?:—|-)?\s*(.*)$",
# #     re.IGNORECASE
# # )

# # CLAUSE_PATTERN = re.compile(
# #     r"^\s*((?:\d+\([a-z]\))|(?:\d+(?:\.\d+)+))\s+(.*)$",
# #     re.IGNORECASE
# # )


# # def clause_aware_chunk_documents(documents: list[dict]) -> list[dict]:
# #     chunks = []

# #     current_article = None
# #     chunk_number = 1

# #     for document in documents:
# #         text = document["text"]

# #         lines = text.splitlines()

# #         current_clause_lines = []
# #         current_clause_ref = None

# #         def flush_clause():
# #             nonlocal current_clause_lines
# #             nonlocal current_clause_ref
# #             nonlocal chunk_number

# #             if not current_clause_lines:
# #                 return

# #             clause_text = "\n".join(current_clause_lines).strip()

# #             if not clause_text:
# #                 current_clause_lines = []
# #                 current_clause_ref = None
# #                 return

# #             chunks.append({
# #                 "source": document["source"],
# #                 "page_number": document["page_number"],
# #                 "chunk_number": chunk_number,
# #                 "article": current_article,
# #                 "clause_ref": current_clause_ref,
# #                 "text": clause_text
# #             })

# #             chunk_number += 1

# #             current_clause_lines = []
# #             current_clause_ref = None

# #         for line in lines:
# #             stripped = line.strip()

# #             if not stripped:
# #                 continue

# #             # ---------------------------------
# #             # ARTICLE
# #             # ---------------------------------
# #             article_match = ARTICLE_PATTERN.match(stripped)

# #             if article_match:
# #                 flush_clause()

# #                 article_number = article_match.group(1)

# #                 current_article = f"ARTICLE {article_number}"

# #                 continue

# #             # ---------------------------------
# #             # CLAUSE
# #             # ---------------------------------
# #             clause_match = CLAUSE_PATTERN.match(stripped)

# #             if clause_match:
# #                 flush_clause()

# #                 current_clause_ref = clause_match.group(1)

# #                 current_clause_lines = [stripped]

# #                 continue

# #             # ---------------------------------
# #             # CONTINUATION OF CURRENT CLAUSE
# #             # ---------------------------------
# #             if current_clause_lines:
# #                 current_clause_lines.append(stripped)

# #             else:
# #                 # Text before the first recognised
# #                 # clause/article.
# #                 chunks.append({
# #                     "source": document["source"],
# #                     "page_number": document["page_number"],
# #                     "chunk_number": chunk_number,
# #                     "article": current_article,
# #                     "clause_ref": None,
# #                     "text": stripped
# #                 })

# #                 chunk_number += 1

# #         flush_clause()

# #     return chunks



# import re

# ARTICLE_PATTERN = re.compile(
#    r"^\s*ARTICLE\s+\d+[A-Z]?(?:\s*[—-].*)?\s*$",
#    re.IGNORECASE
# )
# CLAUSE_PATTERN = re.compile(
#    r"^\s*(\d+\([a-z]\)|\d+(?:\.\d+)+)\s+",
#    re.IGNORECASE
# )
# SCHEDULE_PATTERN = re.compile(
#    r"^\s*SCHEDULE\s+[A-Z0-9]+\s*$",
#    re.IGNORECASE
# )

# def is_pdf_header_footer(line: str) -> bool:
#    line = line.strip()
#    if not line:
#        return False
#    if re.fullmatch(r"Page\s+\d+", line, re.IGNORECASE):
#        return True
#    if line.startswith("Synthetic document generated"):
#        return True
#    return False

# def chunk_documents(documents: list[dict]) -> list[dict]:
#    chunks = []
#    for document in documents:
#        lines = document["text"].splitlines()
#        current_lines = []
#        current_article = None
#        current_clause = None
#        chunk_number = 1
#        def save_chunk():
#            nonlocal current_lines, chunk_number
#            if not current_lines:
#                return
#            text = "\n".join(current_lines).strip()
#            if not text:
#                current_lines = []
#                return
#            chunks.append({
#                "source": document["source"],
#                "page_number": document["page_number"],
#                "chunk_number": chunk_number,
#                "article": current_article,
#                "clause_ref": current_clause,
#                "text": text
#            })
#            chunk_number += 1
#            current_lines = []
#        for line in lines:
#            line = line.strip()
#            if not line:
#                continue
#            if is_pdf_header_footer(line):
#                continue
#            # ------------------------------------------------
#            # ARTICLE
#            # ------------------------------------------------
#            if ARTICLE_PATTERN.match(line):
#                save_chunk()
#                current_article = line
#                current_clause = None
#                current_lines.append(line)
#                continue
#            # ------------------------------------------------
#            # SCHEDULE
#            # ------------------------------------------------
#            if SCHEDULE_PATTERN.match(line):
#                save_chunk()
#                current_article = line
#                current_clause = None
#                current_lines.append(line)
#                continue
#            # ------------------------------------------------
#            # EXPLICIT / NUMBERED CLAUSE
#            # ------------------------------------------------
#            clause_match = CLAUSE_PATTERN.match(line)
#            if clause_match:
#                save_chunk()
#                current_clause = clause_match.group(1)
#                current_lines.append(line)
#                continue
#            # ------------------------------------------------
#            # NORMAL PARAGRAPH / CONTINUATION
#            # ------------------------------------------------
#            current_lines.append(line)
#        # Save remaining content
#        save_chunk()
#    return chunks
# import re


# ARTICLE_PATTERN = re.compile(
#     r"^\s*ARTICLE\s+\d+[A-Z]?(?:\s*[—-].*)?\s*$",
#     re.IGNORECASE
# )

# CLAUSE_PATTERN = re.compile(
#     r"^\s*(\d+\([a-z]\)|\d+\.\d+(?:\.\d+)*)\s+[A-Za-z]",
#     re.IGNORECASE
# )

# SCHEDULE_PATTERN = re.compile(
#     r"^\s*SCHEDULE\s+[A-Z0-9]+(?:\s*[—-].*)?\s*$",
#     re.IGNORECASE
# )


# def is_pdf_header_footer(line: str) -> bool:

#     line = line.strip()

#     if not line:
#         return False

#     # Page number
#     if re.fullmatch(r"Page\s+\d+", line, re.IGNORECASE):
#         return True

#     # Synthetic document notice
#     if line.startswith("Synthetic document generated"):
#         return True

#     # Repeated treaty reference in PDF header
#     if re.fullmatch(r"TRT-\d{4}-\d{3}", line):
#         return True

#     # Repeated treaty title in PDF header
#     if line.endswith("Reinsurance Agreement"):
#         return True

#     return False


# def chunk_documents(documents: list[dict]):

#     chunks = []

#     current_lines = []
#     current_article = None
#     current_clause = None

#     chunk_number = 1
#     current_page = None

#     def save_chunk():

#         nonlocal current_lines
#         nonlocal chunk_number
#         nonlocal current_clause

#         if not current_lines:
#             return

#         text = "\n".join(current_lines).strip()

#         if not text:
#             current_lines = []
#             return

#         chunks.append({
#             "source": documents[0]["source"],
#             "page_number": current_page,
#             "chunk_number": chunk_number,
#             "article": current_article,
#             "clause_ref": current_clause,
#             "text": text
#         })

#         chunk_number += 1
#         current_lines = []

#     for document in documents:

#         current_page = document["page_number"]

#         lines = document["text"].splitlines()

#         for line in lines:

#             line = line.strip()

#             if not line:
#                 continue

#             # -----------------------------------------
#             # Remove PDF headers / footers
#             # -----------------------------------------

#             if is_pdf_header_footer(line):
#                 continue

#             # -----------------------------------------
#             # ARTICLE
#             # -----------------------------------------

#             if ARTICLE_PATTERN.match(line):

#                 save_chunk()

#                 current_article = line
#                 current_clause = None

#                 current_lines.append(line)

#                 continue

#             # -----------------------------------------
#             # SCHEDULE
#             # -----------------------------------------

#             if SCHEDULE_PATTERN.match(line):

#                 save_chunk()

#                 current_article = line
#                 current_clause = None

#                 current_lines.append(line)

#                 continue

#             # -----------------------------------------
#             # CLAUSE
#             # -----------------------------------------

#             clause_match = CLAUSE_PATTERN.match(line)

#             if clause_match:

#                 save_chunk()

#                 current_clause = clause_match.group(1)

#                 current_lines.append(line)

#                 continue

#             # -----------------------------------------
#             # NORMAL TEXT / CONTINUATION
#             # -----------------------------------------

#             current_lines.append(line)

#     # Save final chunk
#     save_chunk()

#     return chunks




import re


ARTICLE_PATTERN = re.compile(
    r"^\s*ARTICLE\s+\d+[A-Z]?(?:\s*[—-].*)?\s*$",
    re.IGNORECASE
)

CLAUSE_PATTERN = re.compile(
    r"^\s*(\d+\([a-z]\)|\d+\.\d+(?:\.\d+)*)\s+[A-Za-z]",
    re.IGNORECASE
)

SCHEDULE_PATTERN = re.compile(
    r"^\s*SCHEDULE\s+[A-Z0-9]+(?:\s*[—-].*)?\s*$",
    re.IGNORECASE
)


def is_pdf_header_footer(line: str) -> bool:

    line = line.strip()

    if not line:
        return False

    # Page number
    if re.fullmatch(r"Page\s+\d+", line, re.IGNORECASE):
        return True

    # Synthetic document notice
    if line.startswith("Synthetic document generated"):
        return True

    # Document notice
    if line.startswith("DOCUMENT NOTICE"):
        return True

    # Continuation of document notice
    if line.startswith("contract,"):
        return True

    # Repeated treaty reference in PDF header
    if re.fullmatch(r"TRT-\d{4}-\d{3}", line):
        return True

    # Repeated treaty title in PDF header
    if line.endswith("Reinsurance Agreement"):
        return True

    return False


def chunk_documents(documents: list[dict]):

    chunks = []

    current_lines = []
    current_article = None
    current_clause = None

    chunk_number = 1
    current_page = None

    def save_chunk():

        nonlocal current_lines
        nonlocal chunk_number
        nonlocal current_clause

        if not current_lines:
            return

        text = "\n".join(current_lines).strip()

        if not text:
            current_lines = []
            return

        chunks.append({
            "source": documents[0]["source"],
            "page_number": current_page,
            "chunk_number": chunk_number,
            "article": current_article,
            "clause_ref": current_clause,
            "text": text
        })

        chunk_number += 1
        current_lines = []

    for document in documents:

        current_page = document["page_number"]

        lines = document["text"].splitlines()

        for line in lines:

            line = line.strip()

            if not line:
                continue

            # -----------------------------------------
            # Remove PDF headers / footers
            # -----------------------------------------

            if is_pdf_header_footer(line):
                continue

            # -----------------------------------------
            # ARTICLE
            # -----------------------------------------

            if ARTICLE_PATTERN.match(line):

                save_chunk()

                current_article = line
                current_clause = None

                current_lines.append(line)

                continue

            # -----------------------------------------
            # SCHEDULE
            # -----------------------------------------

            if SCHEDULE_PATTERN.match(line):

                save_chunk()

                current_article = line
                current_clause = None

                current_lines.append(line)

                continue

            # -----------------------------------------
            # CLAUSE
            # -----------------------------------------
            # Do not treat Schedule A values such as
            # 30.0, 70.0, 27.5, etc. as clauses.

            if not (
                current_article
                and current_article.upper().startswith("SCHEDULE")
            ):

                clause_match = CLAUSE_PATTERN.match(line)

                if clause_match:

                    save_chunk()

                    current_clause = clause_match.group(1)

                    current_lines.append(line)

                    continue

            # -----------------------------------------
            # NORMAL TEXT / CONTINUATION
            # -----------------------------------------

            current_lines.append(line)

    # Save final chunk
    save_chunk()

    return chunks