"""
Recovery handler tests — three scenarios that prove correctness.

Run from cederanew/MCP so imports resolve:
    cd F:/cederanew/cederanew/MCP
    python -m pytest ../tests/test_recovery.py -v

Or run directly:
    cd F:/cederanew/cederanew/MCP
    python ../tests/test_recovery.py
"""
import os
import sys

# Resolve MCP package and common imports
MCP_DIR = os.path.join(os.path.dirname(__file__), "..", "MCP")
sys.path.insert(0, os.path.abspath(MCP_DIR))
sys.path.insert(0, os.path.abspath(os.path.join(MCP_DIR, "common")))

from recovery_mcp.handler import (
    calculate_xol_recovery,
    calculate_aggregate_position,
)


# ── Test 1: CAT-2026-004 Windstorm Cerys ─────────────────────────────────────
# Net retained £8.4m | TRT-2026-003 cat XoL | 6 policies | Windstorm (not excluded)
# Layer 2 has £0.8m eroded by Ashley → available £3.2m  (NOT the inception £4m)
# Expected: L1=£500k + L2=£3.2m + L3=£3.4m = £7.1m  (wrong naive answer = £7.9m)

def test_cat_2026_004_total():
    total = 0.0
    for layer in [1, 2, 3]:
        r = calculate_xol_recovery("CAT-2026-004", "TRT-2026-003", layer)
        assert r["status"] == "success", f"Layer {layer}: {r}"
        assert r.get("eligible"), f"Layer {layer} should be eligible, got: {r}"
        total += r["recoverable_amount"]
    assert abs(total - 7_100_000) < 1.0, (
        f"Expected £7,100,000 — got £{total:,.0f}\n"
        "Likely cause: using layer_limit from treaty_terms instead of "
        "current_limit_remaining from layer_erosion (off by £0.8m eroded by Ashley)."
    )


def test_cat_2026_004_layer2_erosion():
    """Layer 2 specifically must return £3.2m, not £4m."""
    r = calculate_xol_recovery("CAT-2026-004", "TRT-2026-003", 2)
    assert r["status"] == "success"
    assert r["eligible"]
    assert abs(r["recoverable_amount"] - 3_200_000) < 1.0, (
        f"Layer 2 expected £3,200,000 — got £{r['recoverable_amount']:,.0f}"
    )


# ── Test 2: CAT-2026-002 River Trent Flood ────────────────────────────────────
# Net retained £1.04m (above Layer 1 attachment £0.5m)
# Article 4(b) excludes Flood from TRT-2026-003 → recovery NIL
# (Flood IS covered under proportional treaties TRT-2026-001/002 — different contract)

def test_cat_2026_002_flood_excluded():
    r = calculate_xol_recovery("CAT-2026-002", "TRT-2026-003", 1)
    assert r["status"] == "success"
    assert r["recoverable_amount"] == 0.0, (
        f"Flood event must return NIL on cat XoL — got £{r['recoverable_amount']:,.0f}\n"
        "Cause: exclusion check skipped or Article 4(b) not seeded in treaty_exclusions."
    )
    assert not r.get("eligible")
    assert r.get("reason") == "peril_excluded", f"Unexpected reason: {r.get('reason')}"


# ── Test 3: LOSS-2026-011 Lanchester Chemical Park Fire ──────────────────────
# Net retained £2.4m (would breach Layer 2 attachment)
# Only 1 policy affected — cat programme requires ≥2 → NIL
# The disqualifying condition is Business Covered, NOT Exclusions

def test_loss_2026_011_single_policy():
    r = calculate_xol_recovery("LOSS-2026-011", "TRT-2026-003", 1)
    assert r["status"] == "success"
    assert r["recoverable_amount"] == 0.0, (
        f"Single-policy fire must return NIL on cat XoL — got £{r['recoverable_amount']:,.0f}\n"
        "Cause: Business Covered policy-count check missing."
    )
    assert not r.get("eligible")
    assert r.get("reason") == "business_covered_not_met", (
        f"Reason must be 'business_covered_not_met' (not 'peril_excluded') — "
        f"got: {r.get('reason')}"
    )


# ── Test 4: aggregate position for Layer 2 before Cerys ─────────────────────
# Confirms layer_erosion is read correctly and current_limit_remaining = £3.2m

def test_aggregate_position_layer2_before_cerys():
    r = calculate_aggregate_position("TRT-2026-003", 2, "2026-09-01")
    assert r["status"] == "success"
    data = r["data"]
    assert abs(data["current_limit_remaining"] - 3_200_000) < 1.0, (
        f"Layer 2 available before Cerys expected £3,200,000 — "
        f"got £{data['current_limit_remaining']:,.0f}"
    )


if __name__ == "__main__":
    print("Running recovery handler tests...\n")
    tests = [
        test_cat_2026_004_total,
        test_cat_2026_004_layer2_erosion,
        test_cat_2026_002_flood_excluded,
        test_loss_2026_011_single_policy,
        test_aggregate_position_layer2_before_cerys,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  PASS  {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL  {t.__name__}\n        {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR {t.__name__}\n        {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed.")
