# ─────────────────────────────────────────────────────────────────────────────
# server.py  —  Recovery Agent
#
# This is the AI layer. It sits on top of the recovery tools.
# Its only job is:
#   1. Receive a plain-English question from the analyst
#   2. Decide which tools to call and in what order
#   3. Call the tools (which talk to the database)
#   4. Write a plain-English answer explaining the results
#
# IT NEVER CALCULATES ANYTHING ITSELF.
# Every number in its answer came from a tool call.
#
# How to run (two terminals needed):
#
#   Terminal 1 — start the MCP server (the tools):
#     cd ~/Musaddique/cederanew/cederanew/MCP
#     python main.py
#     → runs on port 7720
#
#   Terminal 2 — start this agent:
#     cd ~/Musaddique/cederanew/cederanew/RecoveryAgent
#     python server.py
#     → runs on port 8914
#
#   Then ask it something:
#     curl -X POST http://localhost:8914/ask \
#       -H "Content-Type: application/json" \
#       -d '{"question": "How much can we recover on the Cerys windstorm?"}'
# ─────────────────────────────────────────────────────────────────────────────

import logging
import os
import sys

# Add the MCP folder to Python's path so we can find common/db.py if needed
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "MCP"))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "MCP", "common"))

# Load environment variables from the .env file (Azure credentials, API keys)
from dotenv import load_dotenv, find_dotenv
load_dotenv(find_dotenv())

import uvicorn                                          # Web server
from fastapi import FastAPI                             # API framework
from fastapi.middleware.cors import CORSMiddleware      # Allow browser requests
from pydantic import BaseModel                          # Data validation
from typing import Optional

# LangChain + LangGraph — the AI orchestration libraries
from langchain_openai import AzureChatOpenAI            # Azure OpenAI (NOT standard OpenAI)
from langchain_core.messages import SystemMessage       # For the system prompt
from langgraph.prebuilt import create_react_agent       # Builds the agent loop
from langchain_mcp_adapters.client import MultiServerMCPClient  # Connects to MCP tools

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


# ─────────────────────────────────────────────────────────────────────────────
# MCP Server URL
#
# The MCP server (main.py) runs on port 7720.
# Our recovery tools are mounted at /api/v1/recovery.
# FastApiMCP exposes them at /mcp/sse (SSE = Server-Sent Events, a streaming protocol).
#
# So the full URL is: http://localhost:7720/api/v1/recovery/mcp/sse
# ─────────────────────────────────────────────────────────────────────────────
MCP_BASE = os.getenv("MCP_BASE_URL", "http://localhost:7720")
RECOVERY_MCP_URL = f"{MCP_BASE}/api/v1/recovery/mcp/sse"


# ─────────────────────────────────────────────────────────────────────────────
# System Prompt
#
# This is the instruction set we give the AI before it sees any question.
# It tells the agent:
#   - What role it plays
#   - What tools to use and in what order
#   - What NOT to do (never invent numbers)
#   - How to format the answer
# ─────────────────────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are a reinsurance recovery specialist for Cedera, a treaty intelligence platform.

Your job is to answer questions about XoL (excess of loss) reinsurance recoveries.
You work for the reinsurer (e.g. Swiss Re) and calculate how much they owe the
insurance company (e.g. GoCompare) after a major loss event like a storm.

CRITICAL RULE: You NEVER produce a recovery amount, premium, or any financial
figure from your own knowledge. Every number must come from a tool call.
If you guess a number, the answer will be wrong and the company could overpay or underpay.

WHEN ASKED ABOUT A RECOVERY, follow this sequence:

Step 1 — call get_event
  Find out: what was the peril? how big was the loss? how many policies were affected?

Step 2 — call list_applicable_treaties
  Find which XoL treaties were active on the event date.

Step 3 — call calculate_xol_recovery for each layer (1, 2, 3)
  Do this for each relevant treaty and layer combination.
  Each call returns: recoverable_amount + calculation_basis (the full audit trail).

Step 4 — summarise clearly
  Show a table: layer | attachment | available limit | recovery amount
  Show the total at the bottom.
  If Layer 2 was eroded by a prior event, say so and name that prior event.

IF A RECOVERY IS NIL:
  - Say clearly whether it's because: (a) the peril is excluded by a clause,
    or (b) the Business Covered condition was not met (too few policies affected).
  - Cite the clause reference (e.g. "Article 4(b)") from the tool result.
  - Do NOT invent clause wording. Only cite what the tool returned.

TONE: Be precise and professional. Show the maths. An analyst reading your answer
should be able to check every number against the tool results.
"""


# ─────────────────────────────────────────────────────────────────────────────
# FastAPI App
#
# This is the HTTP server for the Recovery Agent.
# It runs on port 8914 (per the Cedera architecture spec).
# ─────────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Cedera Recovery Agent",
    description="AI agent for XoL reinsurance recovery calculations",
    docs_url="/docs",   # Visit http://localhost:8914/docs to see the API
)

# CORSMiddleware lets browser-based UIs call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],    # In production this would be restricted
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────────────────────────────────
# Data models for the /ask endpoint
# ─────────────────────────────────────────────────────────────────────────────

class AskRequest(BaseModel):
    question: str              # The plain-English question from the analyst
    thread_id: Optional[str] = None  # Optional: for conversation tracking


class AskResponse(BaseModel):
    answer: str                # The agent's plain-English answer
    tool_calls_made: int       # How many tool calls the agent made (for transparency)
    thread_id: Optional[str]


# ─────────────────────────────────────────────────────────────────────────────
# POST /ask  —  The main endpoint
#
# This is where the magic happens.
# 1. Receive a question
# 2. Connect to the MCP tools
# 3. Create the LangGraph agent
# 4. Run the agent (it calls tools automatically)
# 5. Return the answer
# ─────────────────────────────────────────────────────────────────────────────
@app.post("/ask", response_model=AskResponse)
async def ask(req: AskRequest):
    """
    Ask a plain-English question about XoL recoveries.

    Example: {"question": "How much can we recover on the Cerys windstorm CAT-2026-004?"}

    The agent will:
    - Call get_event to look up the storm
    - Call list_applicable_treaties to find active XoL contracts
    - Call calculate_xol_recovery for each layer
    - Return a clear summary with the total recovery
    """

    # ── Set up the AI model ───────────────────────────────────────────────────
    # We use AzureChatOpenAI (not standard OpenAI) because our Azure deployment
    # credentials are in the .env file.
    # temperature=0 means deterministic output — same input always gives same output.
    # This is required for tool-calling agents so they don't "improvise".
    llm = AzureChatOpenAI(
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01"),
        temperature=0,      # Must be 0 for tool-calling agents
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    )

    # ── Connect to the MCP tools ──────────────────────────────────────────────
    # MultiServerMCPClient connects to the running MCP server and fetches
    # the list of available tools (get_event, calculate_xol_recovery, etc.)
    # "async with" means the connection is automatically closed when done.
    async with MultiServerMCPClient(
        {
            "recovery": {
                "url": RECOVERY_MCP_URL,
                "transport": "sse",   # SSE = Server-Sent Events (streaming)
            }
        }
    ) as mcp_client:

        # Get the list of tools the agent can use
        tools = mcp_client.get_tools()
        log.info("Recovery agent loaded %d tools from MCP: %s",
                 len(tools), [t.name for t in tools])

        # ── Build the LangGraph agent ─────────────────────────────────────────
        # create_react_agent builds a ReAct loop:
        #   Reason → Act (call a tool) → Observe (read result) → Reason again...
        # It keeps looping until it has enough information to answer.
        agent = create_react_agent(
            llm,
            tools,
            prompt=SystemMessage(content=SYSTEM_PROMPT),
        )

        # ── Run the agent ─────────────────────────────────────────────────────
        # ainvoke = async invoke (non-blocking)
        # We pass the user's question as a "user" message
        result = await agent.ainvoke(
            {"messages": [{"role": "user", "content": req.question}]}
        )

    # ── Extract the answer ────────────────────────────────────────────────────
    messages = result["messages"]
    answer = messages[-1].content   # The last message is the agent's final answer

    # Count tool calls made (for transparency — the analyst can see how many
    # database lookups were made to produce this answer)
    tool_calls_made = sum(
        1 for m in messages
        if hasattr(m, "tool_calls") and m.tool_calls
    )

    return AskResponse(
        answer=answer,
        tool_calls_made=tool_calls_made,
        thread_id=req.thread_id,
    )


# ─────────────────────────────────────────────────────────────────────────────
# GET /health
#
# Quick check that the agent server is running.
# Also shows the MCP URL it's trying to connect to.
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {
        "status": "healthy",
        "service": "recovery-agent",
        "port": 8914,
        "mcp_url": RECOVERY_MCP_URL,
    }


# ─────────────────────────────────────────────────────────────────────────────
# GET /tools
#
# Lists the tools currently available to the agent.
# Useful for debugging — if a tool is missing from this list,
# the agent can't use it (check main.py include_operations).
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/tools")
async def list_tools():
    """Lists the MCP tools available to this agent."""
    async with MultiServerMCPClient(
        {
            "recovery": {
                "url": RECOVERY_MCP_URL,
                "transport": "sse",
            }
        }
    ) as mcp_client:
        tools = mcp_client.get_tools()
        return {
            "count": len(tools),
            "tools": [
                {"name": t.name, "description": t.description}
                for t in tools
            ],
        }


# ─────────────────────────────────────────────────────────────────────────────
# Entry point — runs when you do: python server.py
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Starting Recovery Agent on http://localhost:8914")
    print(f"MCP tools at: {RECOVERY_MCP_URL}")
    print("API docs at:  http://localhost:8914/docs")
    uvicorn.run(app, host="0.0.0.0", port=8914)
