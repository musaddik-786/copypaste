"""
End-to-end smoke test for the Recovery Agent.

Requires both servers to be running:
  Terminal 1: cd MCP          && python main.py       (port 7720)
  Terminal 2: cd RecoveryAgent && python server.py    (port 8914)

Then run:
  python tests/test_recovery_agent.py
"""

import httpx

AGENT_URL = "http://localhost:8914"


def ask(question: str) -> dict:
    r = httpx.post(f"{AGENT_URL}/ask", json={"question": question}, timeout=60)
    r.raise_for_status()
    return r.json()


def test_cerys_windstorm():
    """Agent must cite £7.1m and mention prior erosion of Layer 2."""
    result = ask("How much XoL recovery can we get on the Cerys windstorm event CAT-2026-004?")
    answer = result["answer"].lower()
    print(f"\nCerys answer:\n{result['answer']}\n")
    assert "7,100,000" in answer or "7.1" in answer, "Expected £7.1m in answer"
    assert result["tool_calls_made"] >= 3, "Expected at least 3 tool calls"
    print(f"PASS — tool calls made: {result['tool_calls_made']}")


def test_flood_nil():
    """Agent must report NIL and cite the exclusion clause."""
    result = ask("Can we recover anything on the River Trent flood CAT-2026-002 under TRT-2026-003?")
    answer = result["answer"].lower()
    print(f"\nFlood answer:\n{result['answer']}\n")
    assert "nil" in answer or "zero" in answer or "excluded" in answer, (
        "Expected NIL or excluded in answer"
    )
    assert "article 4" in answer or "flood" in answer, "Expected exclusion clause cited"
    print(f"PASS — tool calls made: {result['tool_calls_made']}")


def test_tools_endpoint():
    """Agent health and tools endpoint must respond."""
    r = httpx.get(f"{AGENT_URL}/tools", timeout=15)
    r.raise_for_status()
    data = r.json()
    assert data["count"] >= 4, f"Expected at least 4 recovery tools, got {data['count']}"
    names = [t["name"] for t in data["tools"]]
    assert "calculate_xol_recovery" in names
    assert "get_event" in names
    print(f"PASS — {data['count']} tools: {names}")


if __name__ == "__main__":
    print("Recovery Agent smoke tests\n" + "=" * 40)
    tests = [test_tools_endpoint, test_cerys_windstorm, test_flood_nil]
    passed = failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL  {t.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed.")
