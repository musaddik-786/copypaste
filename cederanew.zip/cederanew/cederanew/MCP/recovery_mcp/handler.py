# ─────────────────────────────────────────────────────────────────────────────
# handler.py  —  Recovery Handler
#
# This file does ALL the real work for XoL (excess of loss) recovery.
# Think of it as the "calculator" for: how much does the reinsurer owe?
#
# IMPORTANT RULE: This file does pure Python maths.
# The AI (LLM) never touches the numbers. It only reads what this file returns
# and writes a plain-English explanation. This keeps answers 100% correct.
#
# Real-world analogy:
#   GoCompare (the insurance company) had a big storm payout.
#   They come to Swiss Re (the reinsurer) and say "pay us back".
#   This file works out exactly how much Swiss Re owes them.
# ─────────────────────────────────────────────────────────────────────────────

import logging
from decimal import Decimal   # We use Decimal (not float) for money — floats can drift by pennies
from typing import Optional

from common.db import get_db_connection  # Our function to connect to Azure PostgreSQL

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# FUNCTION 1: get_event
#
# Purpose: Fetch the details of a loss event from the database.
# Example: "Tell me everything about the Cerys windstorm (CAT-2026-004)"
#
# Returns:
#   - event_ref:               the event's ID code
#   - event_name:              human-readable name (e.g. "Windstorm Cerys")
#   - peril:                   what caused the damage (Windstorm, Flood, Fire...)
#   - total_net_retained_loss: how much the insurance company needs to claim back
#   - affected_policy_count:   how many individual policies were hit
#   - cat_programme_ref:       which catastrophe reinsurance contract covers this
# ─────────────────────────────────────────────────────────────────────────────
def get_event(event_ref: str) -> dict:

    # Always start with connection = None so the finally block is safe
    # even if the connection never opens
    connection = None
    cursor = None

    try:
        connection = get_db_connection()  # Open a connection to Azure PostgreSQL
        cursor = connection.cursor()      # A cursor lets us run SQL queries

        # Fetch everything we need to know about this loss event
        # %s is a placeholder — psycopg2 fills it in safely (prevents SQL injection)
        cursor.execute(
            """
            SELECT
                event_ref,
                event_name,
                peril,
                event_date,
                total_gross_loss,
                total_proportional_recovery,
                total_net_retained_loss,
                affected_policy_count,
                cat_programme_ref,
                exclusion_note
            FROM loss_events
            WHERE event_ref = %s
            """,
            (event_ref,),  # This tuple fills the %s above
        )

        row = cursor.fetchone()  # Get the single matching row

        # If nothing came back, the event doesn't exist
        if not row:
            return {
                "status": "not_found",
                "message": f"Event {event_ref} not found in the database"
            }

        # dict(row) converts the database row into a normal Python dictionary
        return {"status": "success", "data": dict(row)}

    except Exception:
        # log.exception logs the full error traceback — never swallow errors silently
        log.exception("get_event failed for %s", event_ref)
        raise  # Re-raise so the caller knows something went wrong

    finally:
        # This block ALWAYS runs — even if there was an error above.
        # We must close the cursor and connection to avoid memory leaks.
        if cursor:
            cursor.close()
        if connection:
            connection.close()


# ─────────────────────────────────────────────────────────────────────────────
# FUNCTION 2: list_applicable_treaties
#
# Purpose: Find which reinsurance contracts were active when the loss happened.
# Example: "Which treaties were in force on the date of the Cerys storm?"
#
# Why this matters:
#   A reinsurance contract (treaty) only covers events that happen while it
#   is active. If the treaty expired before the storm, it doesn't pay.
# ─────────────────────────────────────────────────────────────────────────────
def list_applicable_treaties(event_ref: str) -> dict:

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        # Find all XoL treaties where:
        #   - treaty_type = 'xol'  (excess of loss, not quota share)
        #   - The event date falls between when the treaty started and ended
        #   - The treaty is still active (not cancelled)
        cursor.execute(
            """
            SELECT
                t.treaty_ref,
                t.treaty_type,
                t.class_of_business,
                t.cedent_name,
                t.reinsurer_name,
                t.currency
            FROM treaties t
            JOIN loss_events le ON le.event_ref = %s
            WHERE t.treaty_type = 'xol'
              AND t.inception_date <= le.event_date
              AND t.expiry_date   >= le.event_date
              AND t.status = 'active'
            ORDER BY t.treaty_ref
            """,
            (event_ref,),
        )

        rows = cursor.fetchall()

        return {
            "status": "success",
            "event_ref": event_ref,
            "count": len(rows),
            "data": [dict(r) for r in rows],  # Convert each row to a dictionary
        }

    except Exception:
        log.exception("list_applicable_treaties failed for %s", event_ref)
        raise

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


# ─────────────────────────────────────────────────────────────────────────────
# FUNCTION 3: calculate_xol_recovery  ← THE MOST IMPORTANT FUNCTION
#
# Purpose: Calculate exactly how much the reinsurer owes for one layer of
#          one treaty for one event.
#
# Real-world analogy (GoCompare / Swiss Re):
#   Swiss Re's Layer 2 deal says: "We cover £1m–£5m of GoCompare's losses."
#   GoCompare's storm loss was £8.4m.
#   But before this storm, another storm (Ashley) already used up £0.8m.
#   So Layer 2 only has £3.2m left to pay.
#
# We run this function once per layer (Layer 1, Layer 2, Layer 3).
# Add them up to get the total recovery.
#
# The SEQUENCE matters — we check eligibility BEFORE doing any maths.
# If we did the maths first and then checked exclusions, we might hand
# the AI a number it shouldn't see.
# ─────────────────────────────────────────────────────────────────────────────
def calculate_xol_recovery(
    event_ref: str,          # e.g. "CAT-2026-004"
    treaty_ref: str,         # e.g. "TRT-2026-003"
    layer_number: int,       # e.g. 1, 2, or 3
    as_at_date: Optional[str] = None,  # Optional: calculate "as of" a specific date
) -> dict:

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        # ── STEP 1: Get the event details ────────────────────────────────────
        # We need: how big was the loss? what peril? how many policies?
        cursor.execute(
            """
            SELECT
                total_net_retained_loss,   -- the amount GoCompare needs back
                peril,                     -- Windstorm? Flood? Fire?
                affected_policy_count,     -- how many policyholders were hit
                cat_programme_ref,         -- which cat treaty applies
                event_date
            FROM loss_events
            WHERE event_ref = %s
            """,
            (event_ref,),
        )
        event = cursor.fetchone()

        if not event:
            return {"status": "not_found", "message": f"Event {event_ref} not found"}

        # Pull out the values we need into named variables (easier to read below)
        net_retained = Decimal(str(event["total_net_retained_loss"]))
        peril = event["peril"]                           # e.g. "Windstorm"
        policy_count = int(event["affected_policy_count"])
        cat_programme_ref = event["cat_programme_ref"]   # e.g. "TRT-2026-003"
        event_date = event["event_date"]

        # If no as_at_date was given, use the event date itself
        effective_as_at = as_at_date or str(event_date)


        # ── STEP 2: Business Covered check ───────────────────────────────────
        # The catastrophe (cat) XoL programme only pays if the storm hit
        # at least 2 separate policies. A single big fire doesn't count.
        #
        # Real example: Lanchester Chemical Park fire (LOSS-2026-011)
        #   - Loss was £2.4m (big enough to claim)
        #   - But only 1 factory was affected
        #   - Cat programme says "minimum 2 policies" → NIL
        #
        # Note: this condition is in the "Business Covered" section of the
        # contract, NOT in the Exclusions section. Different interview story.
        if cat_programme_ref == treaty_ref and policy_count < 2:
            return {
                "status": "success",
                "recoverable_amount": 0.0,
                "eligible": False,
                "reason": "business_covered_not_met",
                "note": (
                    f"Event {event_ref} only affected {policy_count} policy. "
                    f"The catastrophe programme requires at least 2 separate "
                    f"policies to be affected (Business Covered condition)."
                ),
                # calculation_basis is the audit trail — always include it
                "calculation_basis": {
                    "event_ref": event_ref,
                    "treaty_ref": treaty_ref,
                    "layer_number": layer_number,
                    "check": "business_covered",
                    "affected_policy_count": policy_count,
                    "required": 2,
                    "result": "ineligible",
                },
            }


        # ── STEP 3: Exclusion check ───────────────────────────────────────────
        # Before doing any maths, check if this type of damage is excluded.
        #
        # Real example: River Trent Flood (CAT-2026-002)
        #   - Loss was £1.04m (above the £0.5m attachment point)
        #   - BUT Article 4(b) says flood is excluded from TRT-2026-003
        #   - So the recovery is NIL — doesn't matter how big the loss was
        #
        # We search treaty_exclusions where:
        #   - It's for this specific treaty
        #   - The exclusion name mentions the event's peril
        #   ILIKE = case-insensitive LIKE in PostgreSQL
        #   %s matches "anything before or after" the peril word
        peril_pattern = f"%{peril}%"

        cursor.execute(
            """
            SELECT exclusion_id, exclusion_name, clause_ref, description
            FROM treaty_exclusions
            WHERE treaty_ref = %s
              AND (
                exclusion_name ILIKE %s
                OR description ILIKE %s
              )
            LIMIT 1
            """,
            (treaty_ref, peril_pattern, peril_pattern),
        )
        exclusion = cursor.fetchone()

        # If we found a matching exclusion, stop here — recovery is NIL
        if exclusion:
            return {
                "status": "success",
                "recoverable_amount": 0.0,
                "eligible": False,
                "reason": "peril_excluded",
                "note": (
                    f"Peril '{peril}' is excluded under {exclusion['clause_ref']}: "
                    f"{exclusion['exclusion_name']}."
                ),
                "calculation_basis": {
                    "event_ref": event_ref,
                    "treaty_ref": treaty_ref,
                    "layer_number": layer_number,
                    "check": "exclusion",
                    "peril": peril,
                    "exclusion_name": exclusion["exclusion_name"],
                    "clause_ref": exclusion["clause_ref"],
                    "result": "excluded",
                },
            }


        # ── STEP 4: Get the layer terms ───────────────────────────────────────
        # Each layer has fixed rules written into the treaty:
        #   attachment_point: the loss must exceed this before this layer pays
        #   layer_limit:      the maximum this layer will ever pay at inception
        #   event_limit:      the maximum per individual event
        cursor.execute(
            """
            SELECT attachment_point, layer_limit, event_limit, reinstatements
            FROM treaty_terms
            WHERE treaty_ref = %s AND layer_number = %s
            """,
            (treaty_ref, layer_number),
        )
        terms = cursor.fetchone()

        if not terms:
            return {
                "status": "not_found",
                "message": f"No terms found for {treaty_ref} layer {layer_number}",
            }

        # Convert to Decimal for accurate money arithmetic
        attachment = Decimal(str(terms["attachment_point"]))
        layer_limit = Decimal(str(terms["layer_limit"]))
        event_limit = Decimal(str(terms["event_limit"]))


        # ── STEP 5: Get available limit from erosion ──────────────────────────
        # This is the most important step for getting the RIGHT answer.
        #
        # Problem: each layer starts the year with a full limit (e.g. £4m).
        # But if a PREVIOUS event already used some of that limit, it's gone.
        #
        # Real example — Layer 2:
        #   Started the year with £4m available.
        #   Storm Ashley (March) used £0.8m.
        #   When storm Cerys (September) arrives, only £3.2m is left.
        #
        # WRONG approach: use treaty_terms.layer_limit → gives £4m → answer £7.9m
        # RIGHT approach: use layer_erosion.current_limit_remaining → £3.2m → £7.1m
        #
        # We find the most recent erosion record that happened BEFORE this event.
        cursor.execute(
            """
            SELECT
                current_limit_remaining,   -- how much is left after prior events
                cumulative_eroded,         -- total used up so far this year
                aggregate_remaining        -- total the layer can pay all year
            FROM layer_erosion
            WHERE treaty_ref = %s
              AND layer_number = %s
              AND event_date < %s          -- only look at events BEFORE this one
            ORDER BY event_date DESC       -- get the most recent one
            LIMIT 1
            """,
            (treaty_ref, layer_number, effective_as_at),
        )
        erosion = cursor.fetchone()

        if erosion:
            # A prior event exists — use what's left after it
            available_limit    = Decimal(str(erosion["current_limit_remaining"]))
            cumulative_eroded  = Decimal(str(erosion["cumulative_eroded"]))
            aggregate_remaining = Decimal(str(erosion["aggregate_remaining"]))
        else:
            # No prior events this year — full limits apply
            # Fall back to treaty_terms for the aggregate limit
            cursor.execute(
                "SELECT aggregate_limit FROM treaty_terms WHERE treaty_ref = %s AND layer_number = %s",
                (treaty_ref, layer_number),
            )
            terms_agg = cursor.fetchone()
            available_limit    = layer_limit
            cumulative_eroded  = Decimal("0")
            aggregate_remaining = Decimal(str(terms_agg["aggregate_limit"])) if terms_agg else layer_limit

        # The effective limit is the SMALLEST of three constraints:
        #   1. current_limit_remaining — what's left of this occurrence limit
        #   2. event_limit             — the per-event cap in the contract
        #   3. aggregate_remaining     — what's left for the whole year
        effective_limit = min(available_limit, event_limit, aggregate_remaining)


        # ── STEP 6: The actual arithmetic ─────────────────────────────────────
        # This is the calculation itself — only 2 lines.
        # Everything above was just checking we're allowed to calculate.
        #
        # loss_above_attachment: how much of the loss sits above the trigger point
        #   e.g. loss £8.4m, attachment £1m → £7.4m above the trigger
        #   (we use max(0, ...) so we never get a negative number)
        #
        # recoverable: how much this layer actually pays
        #   i.e. the loss above the trigger, capped by the available limit
        #   e.g. min(£7.4m, £3.2m) = £3.2m
        loss_above_attachment = max(Decimal("0"), net_retained - attachment)
        recoverable           = min(loss_above_attachment, effective_limit)


        # ── Build the audit trail ─────────────────────────────────────────────
        # The calculation_basis is returned with every result.
        # It shows every number used in the calculation so anyone can check the work.
        # binding_constraint tells you WHY the recovery wasn't higher.
        calculation_basis = {
            "event_ref":                    event_ref,
            "treaty_ref":                   treaty_ref,
            "layer_number":                 layer_number,
            "as_at_date":                   effective_as_at,
            "net_retained_loss":            str(net_retained),
            "attachment_point":             str(attachment),
            "layer_limit_at_inception":     str(layer_limit),
            "cumulative_eroded_before_event": str(cumulative_eroded),
            "current_limit_remaining":      str(available_limit),
            "aggregate_remaining":          str(aggregate_remaining),
            "event_limit":                  str(event_limit),
            "effective_limit_used":         str(effective_limit),
            "loss_above_attachment":        str(loss_above_attachment),
            "recoverable_amount":           str(recoverable),
            # Which constraint actually capped the recovery?
            "binding_constraint": (
                "aggregate_remaining"    if aggregate_remaining < min(available_limit, event_limit)
                else "event_limit"       if event_limit < available_limit
                else "current_limit_remaining"
            ),
        }

        return {
            "status": "success",
            "eligible": True,
            "recoverable_amount": float(recoverable),  # float for JSON serialisation
            "calculation_basis": calculation_basis,
        }

    except Exception:
        log.exception(
            "calculate_xol_recovery failed: event=%s treaty=%s layer=%s",
            event_ref, treaty_ref, layer_number,
        )
        raise

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


# ─────────────────────────────────────────────────────────────────────────────
# FUNCTION 4: calculate_aggregate_position
#
# Purpose: "How much of Layer X is still available as of a given date?"
# Example: "Before Cerys hit, how much was left in Layer 2?"
# Answer:  £3.2m (Ashley used £0.8m earlier in the year)
#
# This is a reporting/diagnostic function. The agent uses it to show
# the current state of each layer before telling you the recovery amount.
# ─────────────────────────────────────────────────────────────────────────────
def calculate_aggregate_position(
    treaty_ref: str,
    layer_number: int,
    as_at_date: str,   # Required — "as of what date do you want to know?"
) -> dict:

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        # Get the most recent erosion record before the requested date
        cursor.execute(
            """
            SELECT
                erosion_ref,
                event_ref,
                event_date,
                amount_eroded,
                cumulative_eroded,
                current_limit_remaining,
                aggregate_limit,
                aggregate_remaining
            FROM layer_erosion
            WHERE treaty_ref  = %s
              AND layer_number = %s
              AND event_date   < %s
            ORDER BY event_date DESC
            LIMIT 1
            """,
            (treaty_ref, layer_number, as_at_date),
        )
        erosion = cursor.fetchone()

        if not erosion:
            # No erosion has happened yet — the layer is completely fresh
            # Go to treaty_terms to get the original limits
            cursor.execute(
                """
                SELECT layer_limit, aggregate_limit
                FROM treaty_terms
                WHERE treaty_ref = %s AND layer_number = %s
                """,
                (treaty_ref, layer_number),
            )
            terms = cursor.fetchone()

            if not terms:
                return {
                    "status": "not_found",
                    "message": f"No terms found for {treaty_ref} layer {layer_number}",
                }

            # Return the inception (starting) limits — nothing has been used yet
            return {
                "status": "success",
                "data": {
                    "treaty_ref":               treaty_ref,
                    "layer_number":             layer_number,
                    "as_at_date":               as_at_date,
                    "cumulative_eroded":        0.0,
                    "current_limit_remaining":  float(terms["layer_limit"]),
                    "aggregate_limit":          float(terms["aggregate_limit"]),
                    "aggregate_remaining":      float(terms["aggregate_limit"]),
                    "prior_events":             0,
                },
            }

        # Return the current state after prior events
        return {
            "status": "success",
            "data": {
                "treaty_ref":               treaty_ref,
                "layer_number":             layer_number,
                "as_at_date":               as_at_date,
                "cumulative_eroded":        float(erosion["cumulative_eroded"]),
                "current_limit_remaining":  float(erosion["current_limit_remaining"]),
                "aggregate_limit":          float(erosion["aggregate_limit"]),
                "aggregate_remaining":      float(erosion["aggregate_remaining"]),
                "most_recent_prior_event":  erosion["event_ref"],
                "most_recent_event_date":   str(erosion["event_date"]),
            },
        }

    except Exception:
        log.exception(
            "calculate_aggregate_position failed: treaty=%s layer=%s as_at=%s",
            treaty_ref, layer_number, as_at_date,
        )
        raise

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


# ─────────────────────────────────────────────────────────────────────────────
# FUNCTION 5: check_reinstatements
#
# Purpose: Has the reinsurer used up their reinstatement allowances?
#
# What is a reinstatement?
#   After a big payout, the reinsurance cover can be "reinstated" (topped up)
#   by paying an extra premium. But there's a limit to how many times you can
#   do this per year.
#
#   e.g. Layer 2 allows 2 reinstatements.
#   If Ashley used 1 and Cerys used another 1, only 0 are left.
#   The next storm would find Layer 2 empty.
# ─────────────────────────────────────────────────────────────────────────────
def check_reinstatements(treaty_ref: str, layer_number: int) -> dict:

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        # Get the most recent erosion record for this layer
        cursor.execute(
            """
            SELECT
                reinstatements_allowed,   -- how many are permitted in the contract
                reinstatements_used,      -- how many have been used so far
                aggregate_remaining,
                current_limit_remaining
            FROM layer_erosion
            WHERE treaty_ref = %s AND layer_number = %s
            ORDER BY event_date DESC
            LIMIT 1
            """,
            (treaty_ref, layer_number),
        )
        row = cursor.fetchone()

        if not row:
            # No erosion yet — look up the original allowance in treaty_terms
            cursor.execute(
                "SELECT reinstatements FROM treaty_terms WHERE treaty_ref = %s AND layer_number = %s",
                (treaty_ref, layer_number),
            )
            terms = cursor.fetchone()

            if not terms:
                return {
                    "status": "not_found",
                    "message": f"No terms for {treaty_ref} layer {layer_number}",
                }

            return {
                "status": "success",
                "data": {
                    "treaty_ref":               treaty_ref,
                    "layer_number":             layer_number,
                    "reinstatements_allowed":   terms["reinstatements"],
                    "reinstatements_used":      0,
                    "reinstatements_remaining": terms["reinstatements"],
                },
            }

        remaining = row["reinstatements_allowed"] - row["reinstatements_used"]

        return {
            "status": "success",
            "data": {
                "treaty_ref":               treaty_ref,
                "layer_number":             layer_number,
                "reinstatements_allowed":   row["reinstatements_allowed"],
                "reinstatements_used":      row["reinstatements_used"],
                "reinstatements_remaining": remaining,
            },
        }

    except Exception:
        log.exception("check_reinstatements failed: treaty=%s layer=%s", treaty_ref, layer_number)
        raise

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
