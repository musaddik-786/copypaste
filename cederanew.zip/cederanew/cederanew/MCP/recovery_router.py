# ─────────────────────────────────────────────────────────────────────────────
# recovery_router.py  —  Recovery MCP Router
#
# This file is the HTTP wrapper around the recovery handler.
# It does THREE things only:
#   1. Defines the URL for each tool  (e.g. POST /calculate_xol_recovery)
#   2. Validates the incoming data    (using Pydantic models)
#   3. Calls the handler function     (which does the real work)
#
# NO business logic lives here. All calculations are in handler.py.
#
# The operation_id on each endpoint is critical.
# FastApiMCP uses it to expose the tool to the AI agent.
# If you forget operation_id, the tool silently disappears — no error,
# it just becomes invisible to the agent. (Real bug we fixed — see DECISIONS.md)
# ─────────────────────────────────────────────────────────────────────────────

import logging
from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from recovery_mcp import handler   # The file with all the real logic

log = logging.getLogger(__name__)

# APIRouter groups all our recovery endpoints together
# It gets included in main.py to become part of the full API
router = APIRouter()


# ─────────────────────────────────────────────────────────────────────────────
# TOOL 1: get_event
# URL: POST /get_event
#
# The agent calls this first to look up a loss event.
# e.g. "Tell me about CAT-2026-004"
# ─────────────────────────────────────────────────────────────────────────────

# Pydantic model defines what data this endpoint accepts
# Field(min_length=1) means the string can't be empty
class GetEventRequest(BaseModel):
    event_ref: str = Field(min_length=1, description="e.g. 'CAT-2026-004'")


# operation_id MUST match what's in main.py include_operations list
@router.post("/get_event", operation_id="get_event")
def get_event(req: GetEventRequest):
    """
    Returns details of a loss event:
    peril, net retained loss, affected policy count, cat programme ref.
    """
    return handler.get_event(req.event_ref)


# ─────────────────────────────────────────────────────────────────────────────
# TOOL 2: list_applicable_treaties
# URL: POST /list_applicable_treaties
#
# The agent calls this to find which treaties were active when the loss happened.
# Only active XoL treaties that cover the event date are returned.
# ─────────────────────────────────────────────────────────────────────────────

class ListApplicableTreatiesRequest(BaseModel):
    event_ref: str = Field(min_length=1, description="e.g. 'CAT-2026-004'")


@router.post("/list_applicable_treaties", operation_id="list_applicable_treaties")
def list_applicable_treaties(req: ListApplicableTreatiesRequest):
    """
    Lists XoL treaties that were active on the event date and could respond.
    """
    return handler.list_applicable_treaties(req.event_ref)


# ─────────────────────────────────────────────────────────────────────────────
# TOOL 3: calculate_xol_recovery  ← THE MAIN TOOL
# URL: POST /calculate_xol_recovery
#
# The agent calls this once per layer to get the recovery amount.
# It checks eligibility and exclusions BEFORE doing the maths.
#
# Run it for Layer 1, Layer 2, Layer 3, then add up the results.
# ─────────────────────────────────────────────────────────────────────────────

class CalculateXolRecoveryRequest(BaseModel):
    event_ref:    str = Field(min_length=1, description="e.g. 'CAT-2026-004'")
    treaty_ref:   str = Field(min_length=1, description="e.g. 'TRT-2026-003'")
    layer_number: int = Field(ge=1,         description="1, 2, or 3")
    as_at_date:   Optional[str] = Field(
        default=None,
        description="ISO date string. Defaults to the event date if not provided."
    )


@router.post("/calculate_xol_recovery", operation_id="calculate_xol_recovery")
def calculate_xol_recovery(req: CalculateXolRecoveryRequest):
    """
    Calculates how much the reinsurer owes for one layer of one treaty.

    Runs checks in this order:
      1. Business Covered  — is this event eligible at all? (cat programme: >=2 policies)
      2. Exclusions        — is this peril excluded by the contract?
      3. Available limit   — how much of this layer is left after prior events?
      4. Arithmetic        — min(loss above attachment, available limit)

    Returns recoverable_amount plus a full calculation_basis audit trail.
    """
    return handler.calculate_xol_recovery(
        req.event_ref,
        req.treaty_ref,
        req.layer_number,
        req.as_at_date,
    )


# ─────────────────────────────────────────────────────────────────────────────
# TOOL 4: calculate_aggregate_position
# URL: POST /calculate_aggregate_position
#
# The agent calls this to show the analyst the current state of a layer.
# e.g. "As of 1 September 2026, Layer 2 has £3.2m remaining"
# ─────────────────────────────────────────────────────────────────────────────

class CalculateAggregatePositionRequest(BaseModel):
    treaty_ref:   str = Field(min_length=1)
    layer_number: int = Field(ge=1)
    as_at_date:   str = Field(min_length=1, description="ISO date e.g. '2026-09-01'")


@router.post("/calculate_aggregate_position", operation_id="calculate_aggregate_position")
def calculate_aggregate_position(req: CalculateAggregatePositionRequest):
    """
    Returns how much of a layer's limit is still available as of a given date.
    Reads from layer_erosion — not treaty_terms — to account for prior events.
    """
    return handler.calculate_aggregate_position(
        req.treaty_ref,
        req.layer_number,
        req.as_at_date,
    )


# ─────────────────────────────────────────────────────────────────────────────
# TOOL 5: check_reinstatements
# URL: POST /check_reinstatements
#
# After a big payout, the layer can be "topped up" again by paying a premium.
# This is called a reinstatement. This tool shows how many are left.
# ─────────────────────────────────────────────────────────────────────────────

class CheckReinstatementsRequest(BaseModel):
    treaty_ref:   str = Field(min_length=1)
    layer_number: int = Field(ge=1)


@router.post("/check_reinstatements", operation_id="check_reinstatements")
def check_reinstatements(req: CheckReinstatementsRequest):
    """
    Returns reinstatement allowances and usage for a layer.
    e.g. Layer 2 allows 2 reinstatements, 1 used, 1 remaining.
    """
    return handler.check_reinstatements(req.treaty_ref, req.layer_number)
